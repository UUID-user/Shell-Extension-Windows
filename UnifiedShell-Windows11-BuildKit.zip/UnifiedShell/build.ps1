<#
.SYNOPSIS
    Self-sufficient Windows 11 x64 build & packaging script for Unified Shell.

.DESCRIPTION
    Produces a single, self-contained Windows x64 executable:
        dist\UnifiedShell.exe

    What this script does automatically:
      1. Verifies Windows 11 (build 22000+) and 64-bit architecture.
      2. Checks for an installed .NET 8.0+ SDK (PATH, Program Files, LocalAppData, or .build\dotnet).
      3. If no suitable .NET SDK is found, downloads Microsoft's official dotnet-install.ps1
         from https://dot.net/v1/dotnet-install.ps1 and installs a portable user-local .NET 8 SDK
         into .build\dotnet\ (requires NO administrator privileges and avoids repeated downloads).
      4. Restores dependencies for src-native\UnifiedShell\UnifiedShell.csproj.
      5. Compiles and publishes Unified Shell in Release configuration (win-x64, self-contained,
         single-file compressed executable with native libraries bundled for self-extract).
      6. Validates the PE64 (AMD64) header and runs built-in functional self-tests (--self-test).
      7. Copies the final binary to dist\UnifiedShell.exe and writes dist\UnifiedShell.exe.sha256.

.PARAMETER Clean
    Removes .build\ intermediate build artifacts before building (preserves cached SDK unless -ForceSdkDownload is set).

.PARAMETER ForceSdkDownload
    Forces a fresh download of the portable .NET 8 SDK into .build\dotnet\.

.PARAMETER SkipSelfTest
    Skips running UnifiedShell.exe --self-test after publishing.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\build.ps1

.EXAMPLE
    .\build.bat
#>

[CmdletBinding()]
param(
    [switch]$Clean,
    [switch]$ForceSdkDownload,
    [switch]$SkipSelfTest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$RootDir       = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectFile   = Join-Path $RootDir 'src-native\UnifiedShell\UnifiedShell.csproj'
$BuildRoot     = Join-Path $RootDir '.build'
$LocalDotnet   = Join-Path $BuildRoot 'dotnet'
$DownloadCache = Join-Path $BuildRoot 'downloads'
$PublishDir    = Join-Path $BuildRoot 'publish-win-x64'
$LogDir        = Join-Path $BuildRoot 'logs'
$DistDir       = Join-Path $RootDir 'dist'
$OutputExe     = Join-Path $DistDir 'UnifiedShell.exe'
$OutputSha     = Join-Path $DistDir 'UnifiedShell.exe.sha256'
$MinWin11Build = 22000

$StartedAt = Get-Date
New-Item -ItemType Directory -Force -Path $BuildRoot, $DownloadCache, $LogDir, $DistDir | Out-Null
$LogFile = Join-Path $LogDir ("build-{0:yyyyMMdd-HHmmss}.log" -f $StartedAt)

function Write-Step   { param([string]$Text) Write-Host "`n==> $Text" -ForegroundColor Cyan }
function Write-Pass   { param([string]$Text) Write-Host "    [OK]   $Text" -ForegroundColor Green }
function Write-Notice { param([string]$Text) Write-Host "    [INFO] $Text" -ForegroundColor Gray }
function Write-Alert  { param([string]$Text) Write-Host "    [WARN] $Text" -ForegroundColor Yellow }

function Stop-Build {
    param([string]$Reason, [string]$Remediation = '', [int]$Code = 1)
    Write-Host "`n    [FAIL] $Reason" -ForegroundColor Red
    if ($Remediation) {
        Write-Host "           $Remediation" -ForegroundColor Yellow
    }
    Write-Host "           Build log: $LogFile`n" -ForegroundColor DarkGray
    try { Stop-Transcript | Out-Null } catch {}
    exit $Code
}

try { Start-Transcript -Path $LogFile -Force | Out-Null } catch {}

Write-Host ""
Write-Host "  Unified Shell - Native Windows 11 x64 Build System" -ForegroundColor White
Write-Host "  Target: dist\UnifiedShell.exe (Self-Contained | Single-File | Release)" -ForegroundColor DarkGray
Write-Host "  Root:   $RootDir" -ForegroundColor DarkGray

# ---------------------------------------------------------------------------
# 1. Verify Operating System & Architecture
# ---------------------------------------------------------------------------
Write-Step "1/7  Checking Windows version and system architecture"

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    Stop-Build "build.ps1 must be executed on Windows 11 x64." "Detected non-Windows platform: $([Environment]::OSVersion.Platform)." 2
}

$OsVersion = [Environment]::OSVersion.Version
if ($OsVersion.Build -lt $MinWin11Build) {
    Stop-Build "Windows 11 (build 22000 or newer) is required. Detected build $($OsVersion.Build)." `
               "Unified Shell targets Windows 11 (including 25H2) and does not support Windows 10." 2
}
Write-Pass "Windows 11 detected (OS build $($OsVersion.Build))"

if (-not [Environment]::Is64BitOperatingSystem) {
    Stop-Build "A 64-bit Windows installation is required." "32-bit x86 operating systems are not supported." 2
}
Write-Pass "64-bit operating system verified ($env:PROCESSOR_ARCHITECTURE)"

if ($PSVersionTable.PSVersion.Major -lt 5) {
    Stop-Build "PowerShell 5.1 or newer is required." "Found PowerShell $($PSVersionTable.PSVersion)." 2
}
Write-Pass "PowerShell $($PSVersionTable.PSVersion)"

if (-not (Test-Path $ProjectFile)) {
    Stop-Build "Native project file not found: $ProjectFile" "Run build.ps1 from the Unified Shell project root." 3
}
Write-Pass "Found project: src-native\UnifiedShell\UnifiedShell.csproj"

# ---------------------------------------------------------------------------
# 2. Clean Intermediate Directories (Optional)
# ---------------------------------------------------------------------------
Write-Step "2/7  Preparing build workspace"

if ($Clean) {
    foreach ($sub in @($PublishDir, (Join-Path $RootDir 'src-native\UnifiedShell\bin'), (Join-Path $RootDir 'src-native\UnifiedShell\obj'))) {
        if (Test-Path $sub) {
            Remove-Item -Path $sub -Recurse -Force
            Write-Notice "Cleaned $sub"
        }
    }
}
if (Test-Path $PublishDir) {
    Remove-Item -Path $PublishDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $PublishDir | Out-Null
Write-Pass "Workspace ready (user configuration and source files preserved)"

# ---------------------------------------------------------------------------
# 3. Locate or Provision Official .NET 8 SDK (No Admin Required)
# ---------------------------------------------------------------------------
Write-Step "3/7  Locating or provisioning .NET 8.0+ SDK"

function Test-DotnetSdk8OrNewer {
    param([string]$DotnetExe)
    if (-not $DotnetExe -or -not (Test-Path $DotnetExe)) { return $false }
    try {
        $sdks = & $DotnetExe --list-sdks 2>$null
        if ($LASTEXITCODE -ne 0 -or -not $sdks) { return $false }
        foreach ($line in $sdks) {
            if ($line -match '^(\d+)\.') {
                if ([int]$Matches[1] -ge 8) { return $true }
            }
        }
    } catch {}
    return $false
}

$DotnetExe = $null
if (-not $ForceSdkDownload) {
    $candidates = @()
    $cmd = Get-Command dotnet -ErrorAction SilentlyContinue
    if ($cmd) { $candidates += $cmd.Source }
    $candidates += (Join-Path $LocalDotnet 'dotnet.exe')
    $candidates += (Join-Path $env:ProgramFiles 'dotnet\dotnet.exe')
    if ($env:LOCALAPPDATA) {
        $candidates += (Join-Path $env:LOCALAPPDATA 'Microsoft\dotnet\dotnet.exe')
    }

    foreach ($cand in ($candidates | Select-Object -Unique)) {
        if (Test-DotnetSdk8OrNewer -DotnetExe $cand) {
            $DotnetExe = $cand
            break
        }
    }
}

if (-not $DotnetExe) {
    Write-Alert "No .NET 8.0+ SDK found on this machine. Provisioning official portable .NET 8 SDK into .build\dotnet (no administrator rights needed)..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

    $InstallScript = Join-Path $DownloadCache 'dotnet-install.ps1'
    $OfficialScriptUrl = 'https://dot.net/v1/dotnet-install.ps1'

    if ($ForceSdkDownload -or -not (Test-Path $InstallScript) -or ((Get-Item $InstallScript).Length -lt 10240)) {
        Write-Notice "Downloading $OfficialScriptUrl"
        try {
            Invoke-WebRequest -Uri $OfficialScriptUrl -OutFile $InstallScript -UseBasicParsing
        } catch {
            Stop-Build "Failed to download dotnet-install.ps1 from $OfficialScriptUrl : $($_.Exception.Message)" `
                       "Check your internet connection or install the .NET 8 SDK manually from https://dotnet.microsoft.com/download/dotnet/8.0" 4
        }
    } else {
        Write-Notice "Using cached installer script: $InstallScript"
    }

    $ScriptHash = (Get-FileHash -Path $InstallScript -Algorithm SHA256).Hash
    Write-Notice "dotnet-install.ps1 SHA-256: $ScriptHash"

    New-Item -ItemType Directory -Force -Path $LocalDotnet | Out-Null
    try {
        & powershell -NoProfile -ExecutionPolicy Bypass -File $InstallScript `
            -Channel '8.0' `
            -Architecture 'x64' `
            -InstallDir $LocalDotnet `
            -NoPath
        if ($LASTEXITCODE -ne 0) {
            throw "dotnet-install.ps1 exited with code $LASTEXITCODE"
        }
    } catch {
        Stop-Build "Portable .NET 8 SDK installation failed: $($_.Exception.Message)" `
                   "Install the .NET 8 SDK x64 from https://dotnet.microsoft.com/download/dotnet/8.0 and rerun build.ps1." 4
    }

    $CandidateLocal = Join-Path $LocalDotnet 'dotnet.exe'
    if (-not (Test-DotnetSdk8OrNewer -DotnetExe $CandidateLocal)) {
        Stop-Build "The .NET 8 SDK could not be verified at $CandidateLocal." `
                   "Delete .build\dotnet and rerun build.ps1 -ForceSdkDownload." 4
    }
    $DotnetExe = $CandidateLocal
}

$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'
$SdkVersion = (& $DotnetExe --version).Trim()
Write-Pass "Using .NET SDK $SdkVersion ($DotnetExe)"

# ---------------------------------------------------------------------------
# 4. Restore Dependencies
# ---------------------------------------------------------------------------
Write-Step "4/7  Restoring .NET Windows Desktop runtime packs"

& $DotnetExe restore $ProjectFile -r win-x64 --verbosity minimal
if ($LASTEXITCODE -ne 0) {
    Stop-Build "dotnet restore failed (exit code $LASTEXITCODE)." `
               "Verify NuGet.org connectivity (https://api.nuget.org/v3/index.json)." 5
}
Write-Pass "Dependencies restored"

# ---------------------------------------------------------------------------
# 5. Build & Publish Self-Contained Single-File Release Executable
# ---------------------------------------------------------------------------
Write-Step "5/7  Publishing self-contained single-file Release executable (win-x64)"

& $DotnetExe publish $ProjectFile `
    --configuration Release `
    --runtime win-x64 `
    --self-contained true `
    --no-restore `
    --output $PublishDir `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:EnableCompressionInSingleFile=true `
    -p:DebugType=none `
    -p:DebugSymbols=false `
    --verbosity minimal

if ($LASTEXITCODE -ne 0) {
    Stop-Build "dotnet publish failed (exit code $LASTEXITCODE)." `
               "Inspect compiler diagnostics above and in $LogFile." 6
}

$PublishedExePath = Join-Path $PublishDir 'UnifiedShell.exe'
if (-not (Test-Path $PublishedExePath)) {
    Stop-Build "Expected build artifact was not created: $PublishedExePath" `
               "Verify AssemblyName in src-native\UnifiedShell\UnifiedShell.csproj." 6
}

$PublishedItem = Get-Item $PublishedExePath
$SizeMb = [math]::Round($PublishedItem.Length / 1MB, 2)
Write-Pass "Published $($PublishedItem.Name) ($SizeMb MB)"

# ---------------------------------------------------------------------------
# 6. Verify PE64 Header & Run Functional Self-Tests
# ---------------------------------------------------------------------------
Write-Step "6/7  Verifying PE64 binary integrity and functional self-tests"

if ($PublishedItem.Length -lt 10MB) {
    Stop-Build "UnifiedShell.exe is unexpectedly small ($SizeMb MB) for a self-contained build." `
               "Ensure --self-contained true was not overridden." 7
}

$Stream = [System.IO.File]::OpenRead($PublishedExePath)
try {
    $Reader = New-Object System.IO.BinaryReader($Stream)
    $DosMagic = $Reader.ReadUInt16()
    if ($DosMagic -ne 0x5A4D) {
        Stop-Build "Invalid DOS MZ header on UnifiedShell.exe." "" 7
    }
    $Stream.Seek(0x3C, [System.IO.SeekOrigin]::Begin) | Out-Null
    $PeOffset = $Reader.ReadInt32()
    $Stream.Seek($PeOffset, [System.IO.SeekOrigin]::Begin) | Out-Null
    $PeSig = $Reader.ReadUInt32()
    $Machine = $Reader.ReadUInt16()
    if ($PeSig -ne 0x00004550 -or $Machine -ne 0x8664) {
        Stop-Build ("Unexpected PE signature (0x{0:X8}) or machine architecture (0x{1:X4}); expected x64 (0x8664)." -f $PeSig, $Machine) "" 7
    }
} finally {
    $Stream.Dispose()
}
Write-Pass "Verified valid PE32+ x86-64 (0x8664) Windows executable"

if (-not $SkipSelfTest) {
    $TestProc = Start-Process -FilePath $PublishedExePath -ArgumentList '--self-test' -Wait -PassThru -WindowStyle Hidden
    if ($TestProc.ExitCode -ne 0) {
        Stop-Build "UnifiedShell.exe --self-test failed with exit code $($TestProc.ExitCode)." `
                   "Run .\dist\UnifiedShell.exe --self-test to inspect failing assertions." 8
    }
    Write-Pass "Built-in functional test suite passed (Calculator, FuzzySearch, Settings, ConfigStore)"
} else {
    Write-Alert "Skipped --self-test (-SkipSelfTest)"
}

# ---------------------------------------------------------------------------
# 7. Stage Final Deliverable to dist\UnifiedShell.exe
# ---------------------------------------------------------------------------
Write-Step "7/7  Staging final deliverable to dist\UnifiedShell.exe"

New-Item -ItemType Directory -Force -Path $DistDir | Out-Null
try {
    Copy-Item -Path $PublishedExePath -Destination $OutputExe -Force
} catch {
    Stop-Build "Could not write $OutputExe : $($_.Exception.Message)" `
               "If UnifiedShell.exe is currently running, quit it from Unified Shell Settings -> Quit Unified Shell and rerun build.ps1." 9
}

$ExeSha256 = (Get-FileHash -Path $OutputExe -Algorithm SHA256).Hash
Set-Content -Path $OutputSha -Value "$ExeSha256  UnifiedShell.exe" -Encoding ASCII

# Clean temporary publish folder while keeping cached SDK for fast subsequent builds
Remove-Item -Path $PublishDir -Recurse -Force -ErrorAction SilentlyContinue

$Elapsed = (Get-Date) - $StartedAt
Write-Pass "Created dist\UnifiedShell.exe ($SizeMb MB)"
Write-Notice "SHA-256: $ExeSha256"

Write-Host ""
Write-Host "  ==================================================================" -ForegroundColor Green
Write-Host "  BUILD SUCCEEDED in $([math]::Round($Elapsed.TotalSeconds, 1))s" -ForegroundColor Green
Write-Host "  Executable : $OutputExe" -ForegroundColor White
Write-Host "  Checksum   : $OutputSha" -ForegroundColor Gray
Write-Host "  Portable   : Create 'dist\portable.flag' to store config beside exe" -ForegroundColor Gray
Write-Host "  ==================================================================" -ForegroundColor Green
Write-Host ""

try { Stop-Transcript | Out-Null } catch {}
exit 0
