using System;
using System.Collections.Generic;
using System.IO;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Search;
using UnifiedShell.Utilities;

namespace UnifiedShell.Tests;

/// <summary>
/// Built-in functional verification suite invoked by <c>UnifiedShell.exe --self-test</c> and <c>build.ps1</c>.
/// Returns exit code 0 when all assertions pass, or 2 if any assertion fails.
/// </summary>
public static class SelfTestRunner
{
    public static int RunAll(TextWriter? output = null)
    {
        var failures = new List<string>();
        int passed = 0;

        void Check(string name, bool condition, string? detail = null)
        {
            if (condition)
            {
                passed++;
                output?.WriteLine($"  [PASS] {name}");
            }
            else
            {
                failures.Add(detail is null ? name : $"{name}: {detail}");
                output?.WriteLine($"  [FAIL] {name} {detail}");
            }
        }

        // 1. CalculatorEngine tests
        Check("Calculator addition & precedence",
            CalculatorEngine.TryEvaluate("12 + 8 * 3", out var r1, out _) && Math.Abs(r1 - 36) < 1e-9, $"got {r1}");
        Check("Calculator parentheses & decimals",
            CalculatorEngine.TryEvaluate("(14.5 + 5.5) / 4", out var r2, out _) && Math.Abs(r2 - 5.0) < 1e-9, $"got {r2}");
        Check("Calculator additive percentage (1200 + 15%)",
            CalculatorEngine.TryEvaluate("1200 + 15%", out var r3, out _) && Math.Abs(r3 - 1380.0) < 1e-9, $"got {r3}");
        Check("Calculator subtractive percentage (200 - 10%)",
            CalculatorEngine.TryEvaluate("200 - 10%", out var r4, out _) && Math.Abs(r4 - 180.0) < 1e-9, $"got {r4}");
        Check("Calculator multiplicative percentage (250 * 20%)",
            CalculatorEngine.TryEvaluate("250 * 20%", out var r5, out _) && Math.Abs(r5 - 50.0) < 1e-9, $"got {r5}");
        Check("Calculator division by zero rejected",
            !CalculatorEngine.TryEvaluate("42 / 0", out _, out var err) && err is not null);

        // 2. FuzzyMatcher tests
        var prefixScore = FuzzyMatcher.Score("calc", "Calculator");
        var subseqScore = FuzzyMatcher.Score("cltr", "Calculator");
        var missScore = FuzzyMatcher.Score("xyzq", "Calculator");
        Check("FuzzyMatcher prefix outranks subsequence", prefixScore is not null && subseqScore is not null && prefixScore > subseqScore);
        Check("FuzzyMatcher non-match returns null", missScore is null);

        // 3. WindowsSettingsIndex URI validation
        Check("WindowsSettingsIndex populated with ms-settings URIs",
            WindowsSettingsIndex.All.Count >= 20 &&
            TrueForAllSettings());

        // 4. ConfigStore atomic persistence, clamping, export & corrupt recovery
        var tempDir = Path.Combine(Path.GetTempPath(), "UnifiedShellTests-" + Guid.NewGuid().ToString("N")[..8]);
        Directory.CreateDirectory(tempDir);
        using var log = AppLog.Create(tempDir);
        try
        {
            var paths = new AppPaths
            {
                Root = tempDir,
                DataDirectory = tempDir,
                ConfigFile = Path.Combine(tempDir, "config.json"),
                NotesDirectory = Path.Combine(tempDir, "notes"),
                AutosaveNoteFile = Path.Combine(tempDir, "notes", "autosave.md"),
                ClipboardFile = Path.Combine(tempDir, "clipboard.json"),
                LogDirectory = tempDir,
                Portable = true,
            };
            var store = new ConfigStore(paths, log);
            var cfg = store.Load();
            Check("ConfigStore default pinned items created", cfg.PinnedItems.Count >= 4);

            cfg.DockHeight = 999; // Should clamp to 54
            cfg.Accent = "teal";
            cfg.LaunchAtSignIn = true;
            Check("ConfigStore atomic save succeeds", store.Save(cfg));

            var reloaded = new ConfigStore(paths, log).Load();
            Check("ConfigStore clamps DockHeight to 54 and persists Accent",
                reloaded.DockHeight == 54 && reloaded.Accent == "teal");

            var exportFile = Path.Combine(tempDir, "exported.json");
            store.ExportToFile(exportFile);
            var exportedJson = File.ReadAllText(exportFile);
            Check("ConfigStore export strips machine-specific LaunchAtSignIn",
                !exportedJson.Contains("\"launchAtSignIn\": true", StringComparison.OrdinalIgnoreCase));

            File.WriteAllText(paths.ConfigFile, "{ corrupt json !!!");
            var recovered = new ConfigStore(paths, log).Load();
            Check("ConfigStore recovers gracefully from corrupt JSON", recovered.Schema == 3);
        }
        finally
        {
            try { Directory.Delete(tempDir, recursive: true); } catch { /* ignore */ }
        }

        output?.WriteLine($"Summary: {passed} passed, {failures.Count} failed.");
        return failures.Count == 0 ? 0 : 2;
    }

    private static bool TrueForAllSettings()
    {
        foreach (var item in WindowsSettingsIndex.All)
        {
            if (!item.Uri.StartsWith("ms-settings:", StringComparison.Ordinal)) return false;
        }
        return true;
    }
}
