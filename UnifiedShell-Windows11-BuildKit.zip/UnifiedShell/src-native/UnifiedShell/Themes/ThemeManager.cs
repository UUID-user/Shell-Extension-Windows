using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using UnifiedShell.Configuration;

namespace UnifiedShell.Themes;

/// <summary>
/// Central design system for Unified Shell's native WPF surfaces.
/// Defines palette tokens, typography, spacing scale, radii, vector icons and reusable control factories.
/// </summary>
public static class ThemeManager
{
    public static FontFamily UiFont { get; } = new("Segoe UI Variable Text, Segoe UI");
    public static FontFamily DisplayFont { get; } = new("Segoe UI Variable Display, Segoe UI");
    public static FontFamily MonoFont { get; } = new("Cascadia Mono, Consolas");

    public static bool IsDark { get; private set; } = true;
    public static Color AccentColor { get; private set; } = ColorFromHex("#5AA6FF");
    public static Color AccentStrongColor { get; private set; } = ColorFromHex("#8EC2FF");
    public static Color AccentForeground { get; private set; } = ColorFromHex("#06121F");

    public static SolidColorBrush DockBackground { get; private set; } = Brush("#D90D1117");
    public static SolidColorBrush PanelBackground { get; private set; } = Brush("#F4161B24");
    public static SolidColorBrush SunkenBackground { get; private set; } = Brush("#FF12161E");
    public static SolidColorBrush ElevatedBackground { get; private set; } = Brush("#FF1F2632");
    public static SolidColorBrush SurfaceSubtle { get; private set; } = Brush("#0AFFFFFF");
    public static SolidColorBrush BorderSubtle { get; private set; } = Brush("#18FFFFFF");
    public static SolidColorBrush BorderStrong { get; private set; } = Brush("#29FFFFFF");
    public static SolidColorBrush HoverBrush { get; private set; } = Brush("#14FFFFFF");
    public static SolidColorBrush ActiveBrush { get; private set; } = Brush("#22FFFFFF");
    public static SolidColorBrush TextPrimary { get; private set; } = Brush("#FFEEF1F6");
    public static SolidColorBrush TextSecondary { get; private set; } = Brush("#FFA5AEBE");
    public static SolidColorBrush TextTertiary { get; private set; } = Brush("#FF77808F");
    public static SolidColorBrush AccentBrush { get; private set; } = Brush("#FF5AA6FF");
    public static SolidColorBrush AccentSoftBrush { get; private set; } = Brush("#265AA6FF");
    public static SolidColorBrush AccentFgBrush { get; private set; } = Brush("#FF06121F");
    public static SolidColorBrush SuccessBrush { get; private set; } = Brush("#FF52C7A4");
    public static SolidColorBrush WarningBrush { get; private set; } = Brush("#FFE6B566");
    public static SolidColorBrush DangerBrush { get; private set; } = Brush("#FFF07D87");

    public static event Action? ThemeChanged;

    public static void Apply(ShellConfig config)
    {
        var dark = config.Theme.ToLowerInvariant() switch
        {
            "light" => false,
            "dark" => true,
            _ => ReadSystemUsesDarkTheme(),
        };
        IsDark = dark;

        (AccentColor, AccentStrongColor, AccentForeground) = (config.Accent.ToLowerInvariant(), dark) switch
        {
            ("violet", true) => (ColorFromHex("#A795FF"), ColorFromHex("#C5B8FF"), ColorFromHex("#0D0820")),
            ("violet", false) => (ColorFromHex("#7452D6"), ColorFromHex("#5B3CB8"), Colors.White),
            ("teal", true) => (ColorFromHex("#48CDB4"), ColorFromHex("#86E6D3"), ColorFromHex("#041613")),
            ("teal", false) => (ColorFromHex("#0B7F6C"), ColorFromHex("#086354"), Colors.White),
            ("amber", true) => (ColorFromHex("#E9B45F"), ColorFromHex("#F5D195"), ColorFromHex("#1A1103")),
            ("amber", false) => (ColorFromHex("#99620A"), ColorFromHex("#7A4E08"), Colors.White),
            (_, false) => (ColorFromHex("#0F6CBD"), ColorFromHex("#0B578F"), Colors.White),
            _ => (ColorFromHex("#5AA6FF"), ColorFromHex("#8EC2FF"), ColorFromHex("#06121F")),
        };

        // Map translucency 0..100 to alpha byte (higher translucency -> slightly lower alpha, still legible).
        var dockAlpha = (byte)Math.Clamp(246 - (int)(config.Translucency * 0.48), 186, 248);
        var panelAlpha = (byte)Math.Clamp(252 - (int)(config.Translucency * 0.24), 222, 253);

        if (dark)
        {
            DockBackground = Frozen(Color.FromArgb(dockAlpha, 13, 17, 23));
            PanelBackground = Frozen(Color.FromArgb(panelAlpha, 22, 27, 36));
            SunkenBackground = Brush("#FF12161E");
            ElevatedBackground = Brush("#FF212834");
            SurfaceSubtle = Brush("#09FFFFFF");
            BorderSubtle = Brush("#18FFFFFF");
            BorderStrong = Brush("#2BFFFFFF");
            HoverBrush = Brush("#13FFFFFF");
            ActiveBrush = Brush("#20FFFFFF");
            TextPrimary = Brush("#FFEEF1F6");
            TextSecondary = Brush("#FFA5AEBE");
            TextTertiary = Brush("#FF77808F");
            SuccessBrush = Brush("#FF52C7A4");
            WarningBrush = Brush("#FFE6B566");
            DangerBrush = Brush("#FFF07D87");
        }
        else
        {
            DockBackground = Frozen(Color.FromArgb(dockAlpha, 246, 249, 253));
            PanelBackground = Frozen(Color.FromArgb(panelAlpha, 251, 252, 254));
            SunkenBackground = Brush("#FFEEF2F7");
            ElevatedBackground = Brush("#FFFFFFFF");
            SurfaceSubtle = Brush("#88FFFFFF");
            BorderSubtle = Brush("#1A101B2B");
            BorderStrong = Brush("#30101B2B");
            HoverBrush = Brush("#10101B2B");
            ActiveBrush = Brush("#1A101B2B");
            TextPrimary = Brush("#FF1A1F27");
            TextSecondary = Brush("#FF5A6575");
            TextTertiary = Brush("#FF8792A2");
            SuccessBrush = Brush("#FF13856B");
            WarningBrush = Brush("#FF98620B");
            DangerBrush = Brush("#FFC0333F");
        }

        AccentBrush = Frozen(AccentColor);
        AccentSoftBrush = Frozen(Color.FromArgb((byte)(dark ? 42 : 30), AccentColor.R, AccentColor.G, AccentColor.B));
        AccentFgBrush = Frozen(AccentForeground);

        ThemeChanged?.Invoke();
    }

    public static bool ReadSystemUsesDarkTheme()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
            if (key?.GetValue("AppsUseLightTheme") is int light) return light == 0;
        }
        catch
        {
            // Default to dark theme.
        }
        return true;
    }

    public static Color ColorFromHex(string hex) => (Color)ColorConverter.ConvertFromString(hex);

    public static SolidColorBrush Brush(string hex)
    {
        var b = new SolidColorBrush(ColorFromHex(hex));
        b.Freeze();
        return b;
    }

    public static SolidColorBrush Frozen(Color c)
    {
        var b = new SolidColorBrush(c);
        b.Freeze();
        return b;
    }

    public static Border CreatePanelShell(UIElement child, double cornerRadius = 10, Thickness? padding = null)
    {
        return new Border
        {
            Background = PanelBackground,
            BorderBrush = BorderStrong,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(cornerRadius),
            Padding = padding ?? new Thickness(0),
            SnapsToDevicePixels = true,
            Child = child,
        };
    }

    public static Button CreateButton(string text, string? iconName = null, bool primary = false, bool subtle = false, bool danger = false, double height = 28)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        var fg = primary ? AccentFgBrush : danger ? DangerBrush : subtle ? TextSecondary : TextPrimary;

        if (!string.IsNullOrEmpty(iconName))
        {
            var icon = VectorIcons.Create(iconName, 13.5, fg);
            icon.Margin = string.IsNullOrEmpty(text) ? new Thickness(0) : new Thickness(0, 0, 6, 0);
            row.Children.Add(icon);
        }

        if (!string.IsNullOrEmpty(text))
        {
            row.Children.Add(new TextBlock
            {
                Text = text,
                FontFamily = UiFont,
                FontSize = 12,
                FontWeight = primary ? FontWeights.SemiBold : FontWeights.Medium,
                Foreground = fg,
                VerticalAlignment = VerticalAlignment.Center,
            });
        }

        var normalBg = primary ? AccentBrush : subtle ? Brushes.Transparent : HoverBrush;
        var normalBorder = primary || subtle ? Brushes.Transparent : BorderSubtle;

        var border = new Border
        {
            Background = normalBg,
            BorderBrush = danger ? Frozen(Color.FromArgb(80, DangerBrush.Color.R, DangerBrush.Color.G, DangerBrush.Color.B)) : normalBorder,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(5),
            Padding = string.IsNullOrEmpty(text) ? new Thickness(6, 0, 6, 0) : new Thickness(10, 0, 10, 0),
            Height = height,
            Child = row,
        };

        var btn = new Button
        {
            Content = border,
            Background = Brushes.Transparent,
            BorderThickness = new Thickness(0),
            Padding = new Thickness(0),
            Cursor = Cursors.Hand,
            FocusVisualStyle = null,
            Template = BareButtonTemplate(),
        };

        btn.MouseEnter += (_, _) =>
        {
            border.Background = primary ? Frozen(AccentStrongColor) : danger ? Frozen(Color.FromArgb(35, DangerBrush.Color.R, DangerBrush.Color.G, DangerBrush.Color.B)) : ActiveBrush;
        };
        btn.MouseLeave += (_, _) =>
        {
            border.Background = normalBg;
        };
        return btn;
    }

    public static Button CreateIconButton(string iconName, string tooltip, double boxSize = 28, double iconSize = 14.5, bool active = false)
    {
        var fg = active ? TextPrimary : TextSecondary;
        var icon = VectorIcons.Create(iconName, iconSize, fg);
        var border = new Border
        {
            Width = boxSize,
            Height = boxSize,
            CornerRadius = new CornerRadius(5),
            Background = active ? ActiveBrush : Brushes.Transparent,
            BorderBrush = active ? BorderSubtle : Brushes.Transparent,
            BorderThickness = new Thickness(1),
            Child = icon,
        };

        var btn = new Button
        {
            Content = border,
            ToolTip = tooltip,
            Cursor = Cursors.Hand,
            FocusVisualStyle = null,
            Template = BareButtonTemplate(),
        };
        btn.MouseEnter += (_, _) => border.Background = active ? ActiveBrush : HoverBrush;
        btn.MouseLeave += (_, _) => border.Background = active ? ActiveBrush : Brushes.Transparent;
        return btn;
    }

    public static TextBox CreateTextBox(string placeholder = "", double height = 28, bool mono = false)
    {
        var box = new TextBox
        {
            Height = height,
            Padding = new Thickness(8, 4, 8, 4),
            VerticalContentAlignment = VerticalAlignment.Center,
            FontFamily = mono ? MonoFont : UiFont,
            FontSize = 12,
            Foreground = TextPrimary,
            CaretBrush = AccentBrush,
            SelectionBrush = AccentBrush,
            Background = SunkenBackground,
            BorderBrush = BorderStrong,
            BorderThickness = new Thickness(1),
            Tag = placeholder,
        };
        return box;
    }

    public static CheckBox CreateToggle(bool isChecked, Action<bool> onChanged)
    {
        var box = new CheckBox
        {
            IsChecked = isChecked,
            Cursor = Cursors.Hand,
            VerticalAlignment = VerticalAlignment.Center,
        };
        box.Checked += (_, _) => onChanged(true);
        box.Unchecked += (_, _) => onChanged(false);
        return box;
    }

    public static ContextMenu CreateStyledMenu()
    {
        return new ContextMenu
        {
            Background = PanelBackground,
            Foreground = TextPrimary,
            BorderBrush = BorderStrong,
            BorderThickness = new Thickness(1),
            Padding = new Thickness(4),
            FontFamily = UiFont,
            FontSize = 12,
        };
    }

    public static MenuItem CreateMenuItem(string header, Action onClick, string? inputGesture = null, bool isEnabled = true)
    {
        var item = new MenuItem
        {
            Header = header,
            Foreground = TextPrimary,
            InputGestureText = inputGesture ?? string.Empty,
            IsEnabled = isEnabled,
            Padding = new Thickness(6, 4, 10, 4),
        };
        item.Click += (_, _) => onClick();
        return item;
    }

    public static ControlTemplate BareButtonTemplate()
    {
        var template = new ControlTemplate(typeof(Button));
        var presenter = new FrameworkElementFactory(typeof(ContentPresenter));
        presenter.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
        presenter.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Stretch);
        template.VisualTree = presenter;
        return template;
    }
}

/// <summary>
/// Crisp 24x24 vector geometry icons matching Unified Shell's iconography.
/// </summary>
public static class VectorIcons
{
    private static readonly Dictionary<string, string> Paths = new(StringComparer.OrdinalIgnoreCase)
    {
        ["logo"] = "M4,6 H20 M4,12 H14.5 M4,18 H9.5",
        ["search"] = "M11,4 A7,7 0 1 1 10.99,4 M16.2,16.2 L20,20",
        ["folder"] = "M3,7.5 A1.5,1.5 0 0 1 4.5,6 H8.7 L10.5,8.1 H19.5 A1.5,1.5 0 0 1 21,9.6 V18 A2,2 0 0 1 19,20 H5 A2,2 0 0 1 3,18 Z",
        ["terminal"] = "M3,5 H21 V19 H3 Z M7,9.5 L9.8,12 L7,14.5 M12.5,15 H16.5",
        ["globe"] = "M12,3.5 A8.5,8.5 0 1 1 11.99,3.5 M3.5,12 H20.5 M12,3.5 C14.5,6 15.5,9 15.5,12 C15.5,15 14.5,18 12,20.5 C9.5,18 8.5,15 8.5,12 C8.5,9 9.5,6 12,3.5",
        ["calculator"] = "M5,3 H19 V21 H5 Z M8,6.5 H16 V9.5 H8 Z M8.5,13 H9.5 M11.5,13 H12.5 M14.5,13 H15.5 M8.5,17 H9.5 M11.5,17 H12.5 M14.5,17 H15.5",
        ["notes"] = "M14,3 H7 A2,2 0 0 0 5,5 V19 A2,2 0 0 0 7,21 H17 A2,2 0 0 0 19,19 V8 Z M14,3 V8 H19 M8.5,12.5 H15.5 M8.5,16.5 H13.5",
        ["calendar"] = "M4,5 H20 V20 H4 Z M8,3 V6.5 M16,3 V6.5 M4,10 H20 M8.5,14 H9.5 M12,14 H13 M15.5,14 H16.5",
        ["timer"] = "M12,6 A7.5,7.5 0 1 1 11.99,6 M12,10 V13.5 L14.5,15 M9,2.5 H15 M12,2.5 V5.5",
        ["stopwatch"] = "M12,6 A7.5,7.5 0 1 1 11.99,6 M12,9.5 V13.7 M9.8,2.5 H14.2 M12,2.5 V5.5 M18.5,6.2 L20,4.7",
        ["clipboard"] = "M9,4.5 H7 A2,2 0 0 0 5,6.5 V19.5 A2,2 0 0 0 7,21.5 H17 A2,2 0 0 0 19,19.5 V6.5 A2,2 0 0 0 17,4.5 H15 M9,2.5 H15 V6 H9 Z M8.5,11.5 H15.5 M8.5,15.5 H13.5",
        ["gauge"] = "M4.5,18.5 A9,9 0 1 1 19.5,18.5 M12,14.5 L16,9.8 M12,13.5 A1.5,1.5 0 1 1 11.99,13.5",
        ["settings"] = "M12,9 A3,3 0 1 1 11.99,9 M12,2.8 V5.2 M12,18.8 V21.2 M2.8,12 H5.2 M18.8,12 H21.2 M5.5,5.5 L7.2,7.2 M16.8,16.8 L18.5,18.5 M18.5,5.5 L16.8,7.2 M7.2,16.8 L5.5,18.5",
        ["wifi"] = "M3,9 A13.5,13.5 0 0 1 21,9 M6.2,12.5 A8.8,8.8 0 0 1 17.8,12.5 M9.5,16 A4,4 0 0 1 14.5,16 M12,19.2 L12.1,19.2",
        ["wifiOff"] = "M3,3 L21,21 M6.2,12.5 A8.8,8.8 0 0 1 17.8,12.5 M9.5,16 A4,4 0 0 1 14.5,16",
        ["volume"] = "M11,5 L6.8,8.5 H3.5 V15.5 H6.8 L11,19 Z M15,9 A4.2,4.2 0 0 1 15,15 M17.8,6.5 A8,8 0 0 1 17.8,17.5",
        ["volumeMute"] = "M11,5 L6.8,8.5 H3.5 V15.5 H6.8 L11,19 Z M15.5,9.5 L20.5,14.5 M20.5,9.5 L15.5,14.5",
        ["battery"] = "M2.5,7.5 H19.5 V16.5 H2.5 Z M21.5,10.2 V13.8 M5,10 H14.5 V14 H5 Z",
        ["power"] = "M12,2.8 V11.5 M7,5.4 A8.4,8.4 0 1 0 17,5.4",
        ["cpu"] = "M6,6 H18 V18 H6 Z M9.5,9.5 H14.5 V14.5 H9.5 Z M9.5,2.5 V6 M14.5,2.5 V6 M9.5,18 V21.5 M14.5,18 V21.5 M2.5,9.5 H6 M2.5,14.5 H6 M18,9.5 H21.5 M18,14.5 H21.5",
        ["gpu"] = "M3,6 H19 V18 H3 Z M6.2,9.2 H10.4 V14.8 H6.2 Z M12.4,9.2 H16.6 V14.8 H12.4 Z M1,10.5 H3 M1,14.5 H3 M19,10.5 H21.5",
        ["memory"] = "M3,7 H21 V16 H3 Z M6,16 V19 M10,16 V19 M14,16 V19 M18,16 V19 M7,10.2 V13 M12,10.2 V13 M17,10.2 V13",
        ["plus"] = "M12,5 V19 M5,12 H19",
        ["close"] = "M6,6 L18,18 M18,6 L6,18",
        ["check"] = "M4.5,12.5 L9.5,17.5 L19.5,6.5",
        ["copy"] = "M9,9 H20 V20 H9 Z M15,9 V5 H4 V16 H9",
        ["trash"] = "M4,6.5 H20 M9.5,6.5 V4 H14.5 V6.5 M6.5,6.5 L7.5,20 H16.5 L17.5,6.5 M10.2,10.5 V16.5 M13.8,10.5 V16.5",
        ["pin"] = "M9,3.5 L15,9.5 M14.5,3.5 L20.5,9.5 L17.5,10.5 L14,14 L14.5,18 L11.5,21 L8,17.5 L3,12.5 L6,9.5 L10,10 Z M4,20 L8,16",
        ["play"] = "M7.5,4.8 V19.2 L19.5,12 Z",
        ["pause"] = "M8.5,5 V19 M15.5,5 V19",
        ["reset"] = "M4,12.5 A8,8 0 1 0 6.5,6.5 M3.5,5 V10.5 H9",
        ["flag"] = "M5,21 V3.5 M5,4.5 H15.5 L13.5,8 L15.5,11.5 H5",
        ["download"] = "M12,3.5 V14.5 M7.5,10.5 L12,15 L16.5,10.5 M4,18.5 V20.2 H20 V18.5",
        ["upload"] = "M12,15 V3.5 M7.5,8 L12,3.5 L16.5,8 M4,18.5 V20.2 H20 V18.5",
        ["chevronLeft"] = "M14.5,6 L8.5,12 L14.5,18",
        ["chevronRight"] = "M9.5,6 L15.5,12 L9.5,18",
        ["external"] = "M13.5,4.5 H19.5 V10.5 M19.5,4.5 L11,13 M17.5,14 V19.5 H4.5 V6.5 H10",
        ["info"] = "M12,3 A9,9 0 1 1 11.99,3 M12,11 V16.5 M12,7.5 L12.05,7.5",
        ["save"] = "M4.5,3.5 H16.5 L19.5,6.5 V20.5 H4.5 Z M8,3.5 V9 H15 V3.5 M8,20.5 V13.5 H16 V20.5",
    };

    public static FrameworkElement Create(string name, double size, Brush stroke, double thickness = 1.8)
    {
        if (!Paths.TryGetValue(name, out var data)) data = Paths["info"];
        var path = new Path
        {
            Data = Geometry.Parse(data),
            Stroke = stroke,
            StrokeThickness = name.Equals("logo", StringComparison.OrdinalIgnoreCase) ? 2.5 : thickness,
            StrokeStartLineCap = PenLineCap.Round,
            StrokeEndLineCap = PenLineCap.Round,
            StrokeLineJoin = PenLineJoin.Round,
            Stretch = Stretch.Uniform,
            Width = size,
            Height = size,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
        };
        return path;
    }
}
