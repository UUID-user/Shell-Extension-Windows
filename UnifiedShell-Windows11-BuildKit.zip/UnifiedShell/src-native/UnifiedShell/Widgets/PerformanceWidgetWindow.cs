using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Themes;

namespace UnifiedShell.Widgets;

/// <summary>
/// Compact CPU, GPU and RAM monitoring panel.
/// Stops sampling completely when hidden to guarantee zero unnecessary background polling.
/// </summary>
public sealed class PerformanceWidgetWindow : Window
{
    private readonly ConfigStore _store;
    private readonly MetricsProvider _metrics;
    private readonly Action _openPerformanceSettings;
    private readonly DispatcherTimer _timer;

    private TextBlock _cpuVal = null!;
    private TextBlock _cpuMeta = null!;
    private Border _cpuBar = null!;
    private StackPanel _cpuSection = null!;

    private TextBlock _ramVal = null!;
    private TextBlock _ramMeta = null!;
    private Border _ramBar = null!;
    private StackPanel _ramSection = null!;

    private TextBlock _gpuVal = null!;
    private TextBlock _gpuMeta = null!;
    private Border _gpuBar = null!;
    private StackPanel _gpuSection = null!;

    private TextBlock _intervalBadge = null!;

    public PerformanceWidgetWindow(ConfigStore store, MetricsProvider metrics, Action openPerformanceSettings)
    {
        _store = store;
        _metrics = metrics;
        _openPerformanceSettings = openPerformanceSettings;

        Title = "Unified Shell Performance";
        Width = 280;
        SizeToContent = SizeToContent.Height;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        Topmost = true;
        ShowInTaskbar = false;
        ShowActivated = false;

        _timer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(_store.Current.MetricsIntervalMs),
        };
        _timer.Tick += (_, _) => RefreshReadings();

        BuildLayout();
        ThemeManager.ThemeChanged += () => { BuildLayout(); if (IsVisible) RefreshReadings(); };
    }

    public void ApplyConfiguration(bool suppressedByFullscreen = false)
    {
        var cfg = _store.Current;
        _timer.Interval = TimeSpan.FromMilliseconds(Math.Clamp(cfg.MetricsIntervalMs, 500, 10000));
        Width = cfg.MetricsCompact ? 250 : 284;

        if (!cfg.MonitorVisible || suppressedByFullscreen)
        {
            _timer.Stop();
            if (IsVisible) Hide();
            return;
        }

        BuildLayout();
        PositionOnMonitor();
        if (!IsVisible)
        {
            Show();
            NativeMethods.ApplyWindowChrome(this, ThemeManager.IsDark, toolWindow: true, roundCorners: true);
        }
        RefreshReadings();
        if (!_timer.IsEnabled) _timer.Start();
    }

    public void PositionOnMonitor()
    {
        var cfg = _store.Current;
        var mon = DisplayManager.Resolve(cfg.MetricsMonitor);
        UpdateLayout();
        var actualH = ActualHeight > 20 ? ActualHeight : 185;
        var dockOffset = cfg.DockEnabled ? cfg.DockHeight + 8 : 10;

        Left = cfg.MetricsPosition switch
        {
            "dock-left" or "bottom-left" => mon.WorkDipLeft + 10,
            _ => mon.WorkDipLeft + mon.WorkDipWidth - Width - 10,
        };

        if (cfg.MetricsPosition is "bottom-left" or "bottom-right")
        {
            var bottomPad = cfg.DockEnabled && cfg.DockPosition == "bottom" ? dockOffset : 10;
            Top = mon.WorkDipBottom - actualH - bottomPad;
        }
        else
        {
            var topPad = cfg.DockEnabled && cfg.DockPosition == "top" ? dockOffset : 10;
            Top = mon.WorkDipTop + topPad;
        }
    }

    private void BuildLayout()
    {
        var cfg = _store.Current;
        var root = new StackPanel();

        // Header
        var header = new DockPanel { Height = 32, Margin = new Thickness(10, 2, 6, 0) };
        var titleRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        titleRow.Children.Add(VectorIcons.Create("gauge", 13.5, ThemeManager.TextSecondary));
        titleRow.Children.Add(new TextBlock
        {
            Text = "Performance",
            FontFamily = ThemeManager.UiFont,
            FontSize = 11.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            Margin = new Thickness(6, 0, 6, 0),
            VerticalAlignment = VerticalAlignment.Center,
        });
        header.Children.Add(titleRow);

        var actions = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var compactBtn = ThemeManager.CreateIconButton("logo", cfg.MetricsCompact ? "Detailed view" : "Compact view", 22, 11.5);
        compactBtn.Click += (_, _) =>
        {
            _store.Current.MetricsCompact = !_store.Current.MetricsCompact;
            _store.Save();
        };
        var settingsBtn = ThemeManager.CreateIconButton("settings", "Performance settings", 22, 12);
        settingsBtn.Click += (_, _) => _openPerformanceSettings();
        var closeBtn = ThemeManager.CreateIconButton("close", "Hide performance monitor", 22, 11.5);
        closeBtn.Click += (_, _) =>
        {
            _store.Current.MonitorVisible = false;
            _store.Save();
        };
        actions.Children.Add(compactBtn);
        actions.Children.Add(settingsBtn);
        actions.Children.Add(closeBtn);
        DockPanel.SetDock(actions, System.Windows.Controls.Dock.Right);
        header.Children.Insert(0, actions);
        root.Children.Add(header);
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        _cpuSection = CreateMetricRow("cpu", "CPU", cfg.MetricsCompact, out _cpuVal, out _cpuBar, out _cpuMeta);
        _cpuSection.Visibility = cfg.MonitorCpu ? Visibility.Visible : Visibility.Collapsed;
        root.Children.Add(_cpuSection);

        _gpuSection = CreateMetricRow("gpu", "GPU", cfg.MetricsCompact, out _gpuVal, out _gpuBar, out _gpuMeta);
        _gpuSection.Visibility = cfg.MonitorGpu ? Visibility.Visible : Visibility.Collapsed;
        root.Children.Add(_gpuSection);

        _ramSection = CreateMetricRow("memory", "RAM", cfg.MetricsCompact, out _ramVal, out _ramBar, out _ramMeta);
        _ramSection.Visibility = cfg.MonitorRam ? Visibility.Visible : Visibility.Collapsed;
        root.Children.Add(_ramSection);

        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        var footer = new DockPanel { Margin = new Thickness(10, 4, 10, 5) };
        _intervalBadge = new TextBlock
        {
            Text = $"Every {cfg.MetricsIntervalMs / 1000.0:0.#}s · Win32 / PDH / DXGI",
            FontSize = 9.5,
            Foreground = ThemeManager.TextTertiary,
        };
        footer.Children.Add(_intervalBadge);
        root.Children.Add(footer);

        Content = ThemeManager.CreatePanelShell(root, cornerRadius: 10);
    }

    private static StackPanel CreateMetricRow(string icon, string label, bool compact, out TextBlock valueText, out Border fillBar, out TextBlock metaText)
    {
        var panel = new StackPanel { Margin = new Thickness(10, compact ? 5 : 7, 10, compact ? 5 : 7) };
        var top = new DockPanel();
        var left = new StackPanel { Orientation = Orientation.Horizontal };
        left.Children.Add(VectorIcons.Create(icon, 12.5, ThemeManager.TextTertiary));
        left.Children.Add(new TextBlock
        {
            Text = label,
            FontSize = 11,
            FontWeight = FontWeights.Medium,
            Foreground = ThemeManager.TextSecondary,
            Margin = new Thickness(5, 0, 0, 0),
        });

        valueText = new TextBlock
        {
            Text = "0%",
            FontFamily = ThemeManager.MonoFont,
            FontSize = 11.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            HorizontalAlignment = HorizontalAlignment.Right,
        };
        DockPanel.SetDock(valueText, System.Windows.Controls.Dock.Right);
        top.Children.Add(valueText);
        top.Children.Add(left);
        panel.Children.Add(top);

        fillBar = new Border
        {
            Height = compact ? 2.5 : 3.5,
            CornerRadius = new CornerRadius(2),
            Background = ThemeManager.AccentBrush,
            HorizontalAlignment = HorizontalAlignment.Left,
            Width = 4,
        };
        var track = new Border
        {
            Height = compact ? 2.5 : 3.5,
            CornerRadius = new CornerRadius(2),
            Background = ThemeManager.HoverBrush,
            Margin = new Thickness(0, 4, 0, 0),
            Child = fillBar,
        };
        panel.Children.Add(track);

        metaText = new TextBlock
        {
            FontSize = 9.5,
            Foreground = ThemeManager.TextTertiary,
            Margin = new Thickness(0, 3, 0, 0),
            TextTrimming = TextTrimming.CharacterEllipsis,
            Visibility = compact ? Visibility.Collapsed : Visibility.Visible,
        };
        panel.Children.Add(metaText);
        return panel;
    }

    private void RefreshReadings()
    {
        var cfg = _store.Current;
        var snap = _metrics.Sample(cfg.MonitorCpu, cfg.MonitorGpu, cfg.MonitorRam);
        var maxTrackWidth = Math.Max(40, Width - 22);

        if (cfg.MonitorCpu)
        {
            _cpuVal.Text = $"{snap.CpuPercent:0.0}%";
            _cpuBar.Width = Math.Max(3, maxTrackWidth * (snap.CpuPercent / 100.0));
            _cpuBar.Background = snap.CpuPercent > 85 ? ThemeManager.WarningBrush : ThemeManager.AccentBrush;
            var temp = snap.CpuTemperatureC is not null ? $"{snap.CpuTemperatureC:0}°C" : "Temp —";
            _cpuMeta.Text = $"{snap.LogicalProcessors} logical processors · {temp}";
        }

        if (cfg.MonitorGpu)
        {
            var pct = snap.GpuPercent ?? 0;
            _gpuVal.Text = snap.GpuPercent is not null ? $"{pct:0.0}%" : "—";
            _gpuBar.Width = Math.Max(3, maxTrackWidth * (pct / 100.0));
            var vram = snap.GpuDedicatedUsedBytes is not null && snap.GpuDedicatedTotalBytes is > 0
                ? $"VRAM {FormatGiB(snap.GpuDedicatedUsedBytes.Value)} / {FormatGiB(snap.GpuDedicatedTotalBytes.Value)}"
                : snap.GpuDedicatedTotalBytes is > 0
                    ? $"VRAM {FormatGiB(snap.GpuDedicatedTotalBytes.Value)}"
                    : "Shared memory";
            var temp = snap.GpuTemperatureC is not null ? $"{snap.GpuTemperatureC:0}°C" : "Temp —";
            _gpuMeta.Text = $"{snap.GpuAdapterName} · {vram} · {temp}";
        }

        if (cfg.MonitorRam)
        {
            _ramVal.Text = $"{snap.MemoryPercent:0.0}%";
            _ramBar.Width = Math.Max(3, maxTrackWidth * (snap.MemoryPercent / 100.0));
            _ramBar.Background = snap.MemoryPercent > 88 ? ThemeManager.WarningBrush : ThemeManager.AccentBrush;
            _ramMeta.Text = $"{FormatGiB(snap.UsedMemoryBytes)} used · {FormatGiB(snap.AvailableMemoryBytes)} avail of {FormatGiB(snap.TotalMemoryBytes)}";
        }
    }

    private static string FormatGiB(ulong bytes) => $"{bytes / (1024.0 * 1024.0 * 1024.0):0.0} GB";
}
