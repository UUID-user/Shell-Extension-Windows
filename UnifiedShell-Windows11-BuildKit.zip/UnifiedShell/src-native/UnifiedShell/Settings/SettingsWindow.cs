using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Search;
using UnifiedShell.Themes;
using UnifiedShell.Utilities;

namespace UnifiedShell.Settings;

/// <summary>
/// Categorised, native-styled Settings interface for Unified Shell.
/// All changes apply immediately and persist atomically to disk.
/// </summary>
public sealed class SettingsWindow : Window
{
    private readonly AppPaths _paths;
    private readonly ConfigStore _store;
    private readonly EverythingClient _everything;
    private readonly ClipboardService _clipboard;
    private readonly AppLog _log;
    private readonly Action _quitApplication;

    private string _activeCategory = "general";
    private bool _recordingShortcut;
    private StackPanel _navHost = null!;
    private StackPanel _pageHost = null!;
    private TextBlock _pageTitle = null!;
    private TextBlock _pageSubtitle = null!;

    private static readonly (string Id, string Label, string Icon, string Description)[] Categories =
    {
        ("general", "General", "settings", "Startup registration, background behaviour and session preferences"),
        ("appearance", "Appearance", "logo", "Theme, accent colour, translucency and dock dimensions"),
        ("dock", "Dock", "folder", "Placement, auto-hide, multi-monitor target and pinned shortcuts"),
        ("search", "Search", "search", "Global activation shortcut, result limits and Everything integration"),
        ("performance", "Performance", "gauge", "Sampling interval, widget placement and hardware sensors"),
        ("utilities", "Utilities", "clipboard", "Clipboard history, Markdown notepad and timer preferences"),
        ("advanced", "Advanced", "download", "Logging, diagnostics, configuration export/import and reset"),
        ("about", "About", "info", "Architecture, Explorer coexistence and documented limitations"),
    };

    public SettingsWindow(
        AppPaths paths,
        ConfigStore store,
        EverythingClient everything,
        ClipboardService clipboard,
        AppLog log,
        Action quitApplication)
    {
        _paths = paths;
        _store = store;
        _everything = everything;
        _clipboard = clipboard;
        _log = log;
        _quitApplication = quitApplication;

        Title = "Unified Shell Settings";
        Width = 860;
        Height = 590;
        MinWidth = 680;
        MinHeight = 460;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.CanResizeWithGrip;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        ShowInTaskbar = true;

        BuildChrome();
        PreviewKeyDown += OnWindowPreviewKeyDown;
        Closing += (_, e) =>
        {
            if (_store.Current.MinimiseToBackground)
            {
                e.Cancel = true;
                Hide();
            }
        };
        ThemeManager.ThemeChanged += () => { BuildChrome(); };
    }

    public void OpenCategory(string? category = null)
    {
        if (!string.IsNullOrWhiteSpace(category)) _activeCategory = category;
        BuildChrome();
        var mon = DisplayManager.Resolve(_store.Current.DockMonitor);
        if (!IsVisible)
        {
            Left = mon.WorkDipLeft + (mon.WorkDipWidth - Width) / 2;
            Top = mon.WorkDipTop + (mon.WorkDipHeight - Height) / 2;
        }
        Show();
        NativeMethods.ApplyWindowChrome(this, ThemeManager.IsDark, toolWindow: false, roundCorners: true);
        Activate();
    }

    private void BuildChrome()
    {
        var outer = new Grid();
        outer.RowDefinitions.Add(new RowDefinition { Height = new GridLength(36) });
        outer.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        // Titlebar
        var titleBar = new DockPanel { Background = ThemeManager.SurfaceSubtle };
        titleBar.MouseLeftButtonDown += (_, e) => { if (e.ButtonState == MouseButtonState.Pressed) DragMove(); };

        var closeBtn = ThemeManager.CreateIconButton("close", "Close settings", 30, 12.5);
        closeBtn.Margin = new Thickness(0, 0, 4, 0);
        closeBtn.Click += (_, _) => Hide();
        DockPanel.SetDock(closeBtn, System.Windows.Controls.Dock.Right);
        titleBar.Children.Add(closeBtn);

        var tLeft = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 0, 0) };
        tLeft.Children.Add(VectorIcons.Create("logo", 14, ThemeManager.AccentBrush));
        tLeft.Children.Add(new TextBlock
        {
            Text = "Unified Shell Settings",
            FontSize = 12,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            Margin = new Thickness(8, 0, 0, 0),
        });
        titleBar.Children.Add(tLeft);
        Grid.SetRow(titleBar, 0);
        outer.Children.Add(titleBar);

        // Main two-pane body
        var body = new Grid();
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(204) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1) });
        body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        // Sidebar
        var sideGrid = new DockPanel { Background = ThemeManager.SunkenBackground };
        var sideFooter = new StackPanel { Margin = new Thickness(12, 8, 12, 10) };
        sideFooter.Children.Add(new TextBlock
        {
            Text = _paths.Portable ? "Portable mode (./data)" : "Per-user (%LOCALAPPDATA%)",
            FontSize = 10,
            Foreground = ThemeManager.TextTertiary,
            Margin = new Thickness(0, 0, 0, 6),
        });
        var quitBtn = ThemeManager.CreateButton("Quit Unified Shell", "power", danger: true, height: 26);
        quitBtn.Click += (_, _) => _quitApplication();
        sideFooter.Children.Add(quitBtn);
        DockPanel.SetDock(sideFooter, System.Windows.Controls.Dock.Bottom);
        sideGrid.Children.Add(sideFooter);

        _navHost = new StackPanel { Margin = new Thickness(8, 10, 8, 8) };
        sideGrid.Children.Add(_navHost);
        Grid.SetColumn(sideGrid, 0);
        body.Children.Add(sideGrid);

        var vSep = new Border { Background = ThemeManager.BorderSubtle };
        Grid.SetColumn(vSep, 1);
        body.Children.Add(vSep);

        // Content pane
        var contentDock = new DockPanel();
        var contentHead = new StackPanel { Margin = new Thickness(22, 16, 22, 12) };
        _pageTitle = new TextBlock
        {
            FontFamily = ThemeManager.DisplayFont,
            FontSize = 17,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
        };
        _pageSubtitle = new TextBlock
        {
            FontSize = 11.5,
            Foreground = ThemeManager.TextTertiary,
            Margin = new Thickness(0, 2, 0, 0),
        };
        contentHead.Children.Add(_pageTitle);
        contentHead.Children.Add(_pageSubtitle);
        DockPanel.SetDock(contentHead, System.Windows.Controls.Dock.Top);
        contentDock.Children.Add(contentHead);

        var headLine = new Border { Height = 1, Background = ThemeManager.BorderSubtle };
        DockPanel.SetDock(headLine, System.Windows.Controls.Dock.Top);
        contentDock.Children.Add(headLine);

        _pageHost = new StackPanel { Margin = new Thickness(22, 14, 22, 22) };
        contentDock.Children.Add(new ScrollViewer
        {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = _pageHost,
        });

        Grid.SetColumn(contentDock, 2);
        body.Children.Add(contentDock);

        Grid.SetRow(body, 1);
        outer.Children.Add(body);

        Content = ThemeManager.CreatePanelShell(outer, cornerRadius: 10);
        RenderNav();
        RenderActivePage();
    }

    private void RenderNav()
    {
        _navHost.Children.Clear();
        foreach (var cat in Categories)
        {
            var captured = cat.Id;
            var active = _activeCategory == captured;
            var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            row.Children.Add(VectorIcons.Create(cat.Icon, 13.5, active ? ThemeManager.AccentBrush : ThemeManager.TextSecondary));
            row.Children.Add(new TextBlock
            {
                Text = cat.Label,
                FontSize = 12,
                FontWeight = active ? FontWeights.SemiBold : FontWeights.Normal,
                Foreground = active ? ThemeManager.TextPrimary : ThemeManager.TextSecondary,
                Margin = new Thickness(9, 0, 0, 0),
            });

            var itemBorder = new Border
            {
                Height = 30,
                Padding = new Thickness(10, 0, 10, 0),
                Margin = new Thickness(0, 1, 0, 1),
                CornerRadius = new CornerRadius(5),
                Background = active ? ThemeManager.ActiveBrush : Brushes.Transparent,
                Cursor = Cursors.Hand,
                Child = row,
            };
            itemBorder.MouseEnter += (_, _) => { if (_activeCategory != captured) itemBorder.Background = ThemeManager.HoverBrush; };
            itemBorder.MouseLeave += (_, _) => { if (_activeCategory != captured) itemBorder.Background = Brushes.Transparent; };
            itemBorder.MouseLeftButtonUp += (_, _) =>
            {
                _activeCategory = captured;
                _recordingShortcut = false;
                RenderNav();
                RenderActivePage();
            };
            _navHost.Children.Add(itemBorder);
        }
    }

    private void RenderActivePage()
    {
        _pageHost.Children.Clear();
        var meta = Categories.FirstOrDefault(c => c.Id == _activeCategory);
        _pageTitle.Text = meta.Label ?? "General";
        _pageSubtitle.Text = meta.Description ?? string.Empty;

        var cfg = _store.Current;

        switch (_activeCategory)
        {
            case "general":
                AddGroup("Windows Startup",
                    Row("Start Unified Shell with Windows", "Registers a per-user HKCU Run entry. Never modifies Explorer or system shell keys.",
                        ThemeManager.CreateToggle(StartupManager.IsEnabled(), on =>
                        {
                            if (StartupManager.SetEnabled(on, _paths.Portable, _log))
                            {
                                cfg.LaunchAtSignIn = on;
                                _store.Save();
                            }
                        })),
                    Row("Minimise windows to background", "Closing Settings or Notepad hides the window while keeping the top dock active.",
                        ThemeManager.CreateToggle(cfg.MinimiseToBackground, on => { cfg.MinimiseToBackground = on; _store.Save(); })),
                    Row("Startup behaviour", "Choose whether Universal Search opens immediately at launch.",
                        ChoiceButtons(cfg.StartupBehaviour, new[] { ("desktop", "Desktop only"), ("launcher", "Open Search") }, v => { cfg.StartupBehaviour = v; _store.Save(); RenderActivePage(); })));
                break;

            case "appearance":
                AddGroup("Theme & Colour",
                    Row("Theme mode", "System follows Windows 11 Personalisation (AppsUseLightTheme) live.",
                        ChoiceButtons(cfg.Theme, new[] { ("system", "System"), ("dark", "Dark"), ("light", "Light") }, v =>
                        {
                            cfg.Theme = v;
                            ThemeManager.Apply(cfg);
                            _store.Save();
                        })),
                    Row("Accent colour", "Restrained highlight used for active controls, indicators and selection.",
                        ChoiceButtons(cfg.Accent, new[] { ("azure", "Azure"), ("violet", "Violet"), ("teal", "Teal"), ("amber", "Amber") }, v =>
                        {
                            cfg.Accent = v;
                            ThemeManager.Apply(cfg);
                            _store.Save();
                        })),
                    SliderRow("Background translucency", "Higher values increase translucency; lower values render more opaquely.",
                        cfg.Translucency, 0, 100, "%", v =>
                        {
                            cfg.Translucency = v;
                            ThemeManager.Apply(cfg);
                            _store.Save();
                        }));
                AddGroup("Dock Dimensions",
                    SliderRow("Dock height", "Compact vertical height in DIPs (34–54 px).", cfg.DockHeight, 34, 54, " px", v => { cfg.DockHeight = v; _store.Save(); }),
                    SliderRow("Icon size", "Pinned application and utility icon size (20–32 px).", cfg.IconSize, 20, 32, " px", v => { cfg.IconSize = v; _store.Save(); }),
                    SliderRow("Item spacing", "Horizontal spacing between dock shortcuts (2–10 px).", cfg.ItemSpacing, 2, 10, " px", v => { cfg.ItemSpacing = v; _store.Save(); }));
                break;

            case "dock":
                var monitors = DisplayManager.GetMonitors();
                var monOptions = new List<(string, string)> { ("primary", "Primary display") };
                foreach (var m in monitors) monOptions.Add((m.DeviceId, m.Label));

                AddGroup("Dock Behaviour",
                    Row("Enable Top Dock", "Native Windows taskbar and system tray remain operational at all times.",
                        ThemeManager.CreateToggle(cfg.DockEnabled, on => { cfg.DockEnabled = on; _store.Save(); })),
                    Row("Edge position", "Top edge (recommended) or bottom edge above the Windows taskbar.",
                        ChoiceButtons(cfg.DockPosition, new[] { ("top", "Top"), ("bottom", "Bottom") }, v => { cfg.DockPosition = v; _store.Save(); RenderActivePage(); })),
                    Row("Auto-hide dock", "Collapses to a 3 px screen-edge reveal strip until hovered.",
                        ThemeManager.CreateToggle(cfg.AutoHide, on => { cfg.AutoHide = on; _store.Save(); })),
                    Row("Target monitor", "DPI-aware placement across connected displays.",
                        ComboSelector(cfg.DockMonitor, monOptions, v => { cfg.DockMonitor = v; _store.Save(); })));

                BuildPinnedItemsEditor(cfg);
                break;

            case "search":
                var ev = _everything.Detect(cfg);
                var shortcutBtn = ThemeManager.CreateButton(
                    _recordingShortcut ? "Press key combo (e.g. Alt+Space)…" : cfg.SearchShortcut,
                    "search",
                    primary: _recordingShortcut,
                    height: 28);
                shortcutBtn.Click += (_, _) =>
                {
                    _recordingShortcut = !_recordingShortcut;
                    RenderActivePage();
                };

                AddGroup("Activation & Limits",
                    Row("Global keyboard shortcut", "Registered via Win32 RegisterHotKey. Click to record a new combination.", shortcutBtn),
                    SliderRow("Maximum search results", "Caps displayed items to keep search response under 50 ms.", cfg.ResultLimit, 4, 20, "", v => { cfg.ResultLimit = v; _store.Save(); }),
                    Row("Include Windows 11 Settings", "Matches system settings and opens them via ms-settings: URIs.",
                        ThemeManager.CreateToggle(cfg.SearchSettings, on => { cfg.SearchSettings = on; _store.Save(); })),
                    Row("Remember recent searches", "Stores up to 8 recent queries locally.",
                        ThemeManager.CreateToggle(cfg.ShowRecentSearches, on => { cfg.ShowRecentSearches = on; _store.Save(); })));

                var evBtnPanel = new StackPanel { Orientation = Orientation.Horizontal };
                var browseEv = ThemeManager.CreateButton("Locate Everything…", "folder", height: 26);
                browseEv.Margin = new Thickness(0, 0, 6, 0);
                browseEv.Click += (_, _) =>
                {
                    var dlg = new OpenFileDialog { Title = "Locate Everything.exe or es.exe", Filter = "Everything (Everything*.exe;es.exe)|Everything*.exe;es.exe" };
                    if (dlg.ShowDialog(this) == true)
                    {
                        cfg.CustomEverythingPath = dlg.FileName;
                        _store.Save();
                        RenderActivePage();
                    }
                };
                var dlEv = ThemeManager.CreateButton("Official Website", "external", height: 26);
                dlEv.Click += (_, _) => ShellLauncher.Open(EverythingClient.OfficialDownloadUrl, null, _log);
                evBtnPanel.Children.Add(browseEv);
                evBtnPanel.Children.Add(dlEv);

                AddGroup("Everything File Search (Voidtools)",
                    Row("Enable Everything file integration", ev.Summary,
                        ThemeManager.CreateToggle(cfg.SearchFiles, on => { cfg.SearchFiles = on; _store.Save(); })),
                    Row("Everything installation", "Unified Shell uses Everything's existing index and never silently downloads it.", evBtnPanel));
                break;

            case "performance":
                var perfMonOptions = new List<(string, string)> { ("primary", "Primary display") };
                foreach (var m in DisplayManager.GetMonitors()) perfMonOptions.Add((m.DeviceId, m.Label));

                AddGroup("Widget Display",
                    Row("Show performance monitor", "Stopping visibility stops the background sampling timer completely (0% idle CPU).",
                        ThemeManager.CreateToggle(cfg.MonitorVisible, on => { cfg.MonitorVisible = on; _store.Save(); })),
                    Row("Compact mode", "Hides secondary adapter and capacity lines.",
                        ThemeManager.CreateToggle(cfg.MetricsCompact, on => { cfg.MetricsCompact = on; _store.Save(); })),
                    Row("Update interval", "Longer intervals reduce background wakeups.",
                        ChoiceButtons(cfg.MetricsIntervalMs.ToString(), new[] { ("1000", "1 s"), ("2000", "2 s"), ("5000", "5 s") }, v =>
                        {
                            cfg.MetricsIntervalMs = int.Parse(v);
                            _store.Save();
                            RenderActivePage();
                        })),
                    Row("Screen corner", "Position relative to the selected monitor's work area.",
                        ComboSelector(cfg.MetricsPosition, new[]
                        {
                            ("dock-right", "Top / Dock Right"),
                            ("dock-left", "Top / Dock Left"),
                            ("bottom-right", "Bottom Right"),
                            ("bottom-left", "Bottom Left"),
                        }, v => { cfg.MetricsPosition = v; _store.Save(); })),
                    Row("Target monitor", "Assign the performance widget to any connected display.",
                        ComboSelector(cfg.MetricsMonitor, perfMonOptions, v => { cfg.MetricsMonitor = v; _store.Save(); })));

                AddGroup("Hardware Counters",
                    Row("CPU usage", "Sampled via Win32 GetSystemTimes kernel/user deltas.",
                        ThemeManager.CreateToggle(cfg.MonitorCpu, on => { cfg.MonitorCpu = on; _store.Save(); })),
                    Row("GPU utilisation & VRAM", "Sampled via PDH GPU Engine / GPU Adapter Memory and DXGI.",
                        ThemeManager.CreateToggle(cfg.MonitorGpu, on => { cfg.MonitorGpu = on; _store.Save(); })),
                    Row("RAM usage", "Sampled via Win32 GlobalMemoryStatusEx.",
                        ThemeManager.CreateToggle(cfg.MonitorRam, on => { cfg.MonitorRam = on; _store.Save(); })));
                break;

            case "utilities":
                var clearClipBtn = ThemeManager.CreateButton("Clear unpinned", "trash", height: 26);
                clearClipBtn.Click += (_, _) => { _clipboard.ClearUnpinned(); RenderActivePage(); };

                AddGroup("Clipboard History",
                    Row("Enable clipboard history", "Event-driven WM_CLIPBOARDUPDATE listener; respects password-manager exclusion flags.",
                        ThemeManager.CreateToggle(cfg.ClipboardEnabled, on => { cfg.ClipboardEnabled = on; _store.Save(); })),
                    SliderRow("Maximum entries", "Pinned items are preserved when old entries roll off.", cfg.ClipboardLimit, 5, 100, "", v => { cfg.ClipboardLimit = v; _store.Save(); }),
                    Row("Capture copied images", "Stores compact PNG thumbnails locally.",
                        ThemeManager.CreateToggle(cfg.ClipboardImages, on => { cfg.ClipboardImages = on; _store.Save(); })),
                    Row($"Stored items ({_clipboard.Entries.Count})", "Stored locally in clipboard.json.", clearClipBtn));

                AddGroup("Notepad & Timer",
                    Row("Notepad automatic draft saving", $"Saves recovery drafts to {_paths.AutosaveNoteFile}.",
                        ThemeManager.CreateToggle(cfg.NotepadAutosave, on => { cfg.NotepadAutosave = on; _store.Save(); })),
                    Row("Timer completion chime", "Plays system notification chime when countdown reaches 00:00.",
                        ThemeManager.CreateToggle(cfg.TimerChime, on => { cfg.TimerChime = on; _store.Save(); })),
                    SliderRow("Default timer preset", "Initial countdown duration in minutes.", cfg.TimerPresetMinutes, 1, 90, " min", v => { cfg.TimerPresetMinutes = v; _store.Save(); }));
                break;

            case "advanced":
                var diagBtn = ThemeManager.CreateButton("Copy Diagnostics", "copy", height: 26);
                diagBtn.Click += (_, _) =>
                {
                    using var proc = Process.GetCurrentProcess();
                    var report = new StringBuilder()
                        .AppendLine("Unified Shell Diagnostics")
                        .AppendLine($"Version: 1.0.0 (win-x64, .NET {Environment.Version})")
                        .AppendLine($"OS: {Environment.OSVersion}")
                        .AppendLine($"Working Set RAM: {proc.WorkingSet64 / (1024.0 * 1024.0):0.1} MB")
                        .AppendLine($"Private Memory: {proc.PrivateMemorySize64 / (1024.0 * 1024.0):0.1} MB")
                        .AppendLine($"Portable Mode: {_paths.Portable}")
                        .AppendLine($"Config File: {_paths.ConfigFile}")
                        .AppendLine($"Log File: {_log.LogFile}")
                        .ToString();
                    try { Clipboard.SetText(report); } catch { /* ignore */ }
                };

                var exportBtn = ThemeManager.CreateButton("Export JSON…", "download", height: 26);
                exportBtn.Click += (_, _) =>
                {
                    var dlg = new SaveFileDialog { Title = "Export Unified Shell Configuration", FileName = "unified-shell-config.json", Filter = "JSON (*.json)|*.json" };
                    if (dlg.ShowDialog(this) == true) _store.ExportToFile(dlg.FileName);
                };

                var importBtn = ThemeManager.CreateButton("Import JSON…", "upload", height: 26);
                importBtn.Click += (_, _) =>
                {
                    var dlg = new OpenFileDialog { Title = "Import Unified Shell Configuration", Filter = "JSON (*.json)|*.json" };
                    if (dlg.ShowDialog(this) == true)
                    {
                        try
                        {
                            var loaded = _store.ImportFromFile(dlg.FileName);
                            ThemeManager.Apply(loaded);
                            RenderActivePage();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(this, $"Could not import configuration:\n{ex.Message}", "Unified Shell", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                };

                var resetBtn = ThemeManager.CreateButton("Reset All Settings", "reset", danger: true, height: 26);
                resetBtn.Click += (_, _) =>
                {
                    if (MessageBox.Show(this, "Reset all Unified Shell settings and pinned dock items to factory defaults?", "Reset Settings", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        var fresh = _store.Reset();
                        ThemeManager.Apply(fresh);
                        RenderActivePage();
                    }
                };

                AddGroup("Diagnostics & Logging",
                    Row("Verbose file logging", $"Writes rotating logs (1 MB max) to {_log.LogFile}.",
                        ThemeManager.CreateToggle(cfg.Logging, on => { cfg.Logging = on; _store.Save(); })),
                    Row("Runtime memory & environment", "Inspect real WorkingSet64 memory consumption and paths.", diagBtn));

                AddGroup("Configuration Portability",
                    Row("Export configuration", "Saves appearance, dock pins and preferences to JSON (excludes notes & clipboard).", exportBtn),
                    Row("Import configuration", "Loads a previously exported JSON configuration file.", importBtn),
                    Row("Reset to defaults", "Restores default configuration without deleting saved notes.", resetBtn));
                break;

            case "about":
                using (var self = Process.GetCurrentProcess())
                {
                    var ramMb = self.WorkingSet64 / (1024.0 * 1024.0);
                    AddGroup("Unified Shell · Windows 11 25H2 Companion",
                        Row("Version & Architecture", "1.0.0 · Windows x64 · Single-process native .NET 8 WPF + Win32",
                            new TextBlock { Text = $"RAM: {ramMb:0.1} MB", FontFamily = ThemeManager.MonoFont, FontSize = 11.5, Foreground = ThemeManager.SuccessBrush }),
                        Row("Explorer Coexistence", "explorer.exe, the native Windows taskbar, Start Menu and original system tray remain untouched.",
                            new TextBlock { Text = "Verified", FontSize = 11, Foreground = ThemeManager.SuccessBrush }),
                        Row("Known Limitations",
                            "1. CPU/GPU temperatures require kernel drivers (WinRing0/PawnIO) on Windows; Unified Shell runs strictly user-mode and shows '—' rather than inventing numbers.\n" +
                            "2. Windows 11 25H2 isolates third-party tray menus inside Explorer's XAML Island; Unified Shell mirrors Core Audio, Power, Network and session tray apps without injecting into explorer.exe.\n" +
                            "3. Whole-disk file search delegates to Everything (Voidtools) when installed and never builds a redundant background disk indexer.",
                            new TextBlock()));
                }
                break;
        }
    }

    private void BuildPinnedItemsEditor(ShellConfig cfg)
    {
        var box = new StackPanel();
        for (int i = 0; i < cfg.PinnedItems.Count; i++)
        {
            var idx = i;
            var item = cfg.PinnedItems[i];
            var dp = new DockPanel { Margin = new Thickness(12, 7, 12, 7) };

            var actions = new StackPanel { Orientation = Orientation.Horizontal };
            var up = ThemeManager.CreateIconButton("chevronLeft", "Move earlier", 24, 12);
            up.IsEnabled = idx > 0;
            up.Click += (_, _) =>
            {
                (cfg.PinnedItems[idx - 1], cfg.PinnedItems[idx]) = (cfg.PinnedItems[idx], cfg.PinnedItems[idx - 1]);
                _store.Save();
                RenderActivePage();
            };
            var down = ThemeManager.CreateIconButton("chevronRight", "Move later", 24, 12);
            down.IsEnabled = idx < cfg.PinnedItems.Count - 1;
            down.Click += (_, _) =>
            {
                (cfg.PinnedItems[idx + 1], cfg.PinnedItems[idx]) = (cfg.PinnedItems[idx], cfg.PinnedItems[idx + 1]);
                _store.Save();
                RenderActivePage();
            };
            var del = ThemeManager.CreateIconButton("trash", "Remove from dock", 24, 12);
            del.Click += (_, _) =>
            {
                cfg.PinnedItems.RemoveAt(idx);
                _store.Save();
                RenderActivePage();
            };
            actions.Children.Add(up);
            actions.Children.Add(down);
            actions.Children.Add(del);
            DockPanel.SetDock(actions, System.Windows.Controls.Dock.Right);
            dp.Children.Add(actions);

            var info = new StackPanel();
            info.Children.Add(new TextBlock { Text = item.Label, FontSize = 12, FontWeight = FontWeights.Medium, Foreground = ThemeManager.TextPrimary });
            info.Children.Add(new TextBlock { Text = $"{item.Kind.ToUpperInvariant()} · {item.Target}", FontSize = 10.5, Foreground = ThemeManager.TextTertiary, TextTrimming = TextTrimming.CharacterEllipsis });
            dp.Children.Add(info);

            if (i > 0) box.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
            box.Children.Add(dp);
        }

        var addBar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(12, 8, 12, 8) };
        var addApp = ThemeManager.CreateButton("Add Application…", "plus", height: 26);
        addApp.Margin = new Thickness(0, 0, 6, 0);
        addApp.Click += (_, _) =>
        {
            var dlg = new OpenFileDialog { Title = "Add Application Shortcut", Filter = "Applications (*.exe;*.lnk)|*.exe;*.lnk|All files (*.*)|*.*" };
            if (dlg.ShowDialog(this) == true)
            {
                cfg.PinnedItems.Add(new DockShortcutItem { Label = Path.GetFileNameWithoutExtension(dlg.FileName), Target = dlg.FileName, Kind = "app" });
                _store.Save();
                RenderActivePage();
            }
        };
        var addDir = ThemeManager.CreateButton("Add Folder…", "folder", height: 26);
        addDir.Click += (_, _) =>
        {
            var dlg = new OpenFolderDialog { Title = "Add Folder Shortcut" };
            if (dlg.ShowDialog(this) == true)
            {
                var name = Path.GetFileName(dlg.FolderName.TrimEnd(Path.DirectorySeparatorChar));
                cfg.PinnedItems.Add(new DockShortcutItem { Label = string.IsNullOrWhiteSpace(name) ? dlg.FolderName : name, Target = dlg.FolderName, Kind = "folder" });
                _store.Save();
                RenderActivePage();
            }
        };
        addBar.Children.Add(addApp);
        addBar.Children.Add(addDir);
        box.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        box.Children.Add(addBar);

        AddCustomGroup("Pinned Shortcuts", box);
    }

    private void AddGroup(string title, params UIElement[] rows)
    {
        var stack = new StackPanel();
        for (int i = 0; i < rows.Length; i++)
        {
            if (i > 0) stack.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
            stack.Children.Add(rows[i]);
        }
        AddCustomGroup(title, stack);
    }

    private void AddCustomGroup(string title, UIElement body)
    {
        _pageHost.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 11.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            Margin = new Thickness(0, 0, 0, 6),
        });
        _pageHost.Children.Add(new Border
        {
            Background = ThemeManager.SurfaceSubtle,
            BorderBrush = ThemeManager.BorderSubtle,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(8),
            Margin = new Thickness(0, 0, 0, 16),
            Child = body,
        });
    }

    private static UIElement Row(string name, string description, UIElement control)
    {
        var grid = new Grid { Margin = new Thickness(14, 10, 14, 10) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var copy = new StackPanel { Margin = new Thickness(0, 0, 16, 0), VerticalAlignment = VerticalAlignment.Center };
        copy.Children.Add(new TextBlock { Text = name, FontSize = 12.5, FontWeight = FontWeights.Medium, Foreground = ThemeManager.TextPrimary });
        if (!string.IsNullOrWhiteSpace(description))
        {
            copy.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 11,
                Foreground = ThemeManager.TextTertiary,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 2, 0, 0),
            });
        }
        Grid.SetColumn(copy, 0);
        grid.Children.Add(copy);

        if (control is FrameworkElement fe) fe.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumn(control, 1);
        grid.Children.Add(control);
        return grid;
    }

    private static UIElement SliderRow(string name, string description, int value, int min, int max, string suffix, Action<int> onChanged)
    {
        var row = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        var label = new TextBlock
        {
            Text = $"{value}{suffix}",
            FontFamily = ThemeManager.MonoFont,
            FontSize = 11.5,
            Foreground = ThemeManager.TextSecondary,
            Width = 52,
            TextAlignment = TextAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
        };
        var slider = new Slider
        {
            Minimum = min,
            Maximum = max,
            Value = value,
            Width = 126,
            IsSnapToTickEnabled = true,
            TickFrequency = 1,
            VerticalAlignment = VerticalAlignment.Center,
        };
        slider.ValueChanged += (_, e) =>
        {
            var v = (int)Math.Round(e.NewValue);
            label.Text = $"{v}{suffix}";
            onChanged(v);
        };
        row.Children.Add(slider);
        row.Children.Add(label);
        return Row(name, description, row);
    }

    private static UIElement ChoiceButtons(string current, IEnumerable<(string Value, string Label)> options, Action<string> onPick)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var (val, lbl) in options)
        {
            var captured = val;
            var active = string.Equals(current, captured, StringComparison.OrdinalIgnoreCase);
            var b = ThemeManager.CreateButton(lbl, null, primary: active, height: 25);
            b.Margin = new Thickness(3, 0, 0, 0);
            b.Click += (_, _) => onPick(captured);
            panel.Children.Add(b);
        }
        return panel;
    }

    private static UIElement ComboSelector(string current, IEnumerable<(string Value, string Label)> options, Action<string> onPick)
    {
        var opts = options.ToList();
        var combo = new ComboBox
        {
            Width = 220,
            Height = 27,
            FontFamily = ThemeManager.UiFont,
            FontSize = 11.5,
        };
        int selected = 0;
        for (int i = 0; i < opts.Count; i++)
        {
            combo.Items.Add(new ComboBoxItem { Content = opts[i].Label, Tag = opts[i].Value });
            if (string.Equals(opts[i].Value, current, StringComparison.OrdinalIgnoreCase)) selected = i;
        }
        combo.SelectedIndex = selected;
        combo.SelectionChanged += (_, _) =>
        {
            if (combo.SelectedItem is ComboBoxItem item && item.Tag is string v) onPick(v);
        };
        return combo;
    }

    private void OnWindowPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (_recordingShortcut)
        {
            e.Handled = true;
            if (e.Key == Key.Escape)
            {
                _recordingShortcut = false;
                RenderActivePage();
                return;
            }
            var key = e.Key == Key.System ? e.SystemKey : e.Key;
            if (key is Key.LeftAlt or Key.RightAlt or Key.LeftCtrl or Key.RightCtrl or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin)
            {
                return;
            }

            var mods = Keyboard.Modifiers;
            if (mods == ModifierKeys.None) return;

            var parts = new List<string>();
            if ((mods & ModifierKeys.Control) != 0) parts.Add("Ctrl");
            if ((mods & ModifierKeys.Alt) != 0) parts.Add("Alt");
            if ((mods & ModifierKeys.Shift) != 0) parts.Add("Shift");
            parts.Add(key == Key.Space ? "Space" : key.ToString());

            _store.Current.SearchShortcut = string.Join("+", parts);
            _recordingShortcut = false;
            _store.Save();
            RenderActivePage();
            return;
        }

        if (e.Key == Key.Escape)
        {
            e.Handled = true;
            Hide();
        }
    }
}
