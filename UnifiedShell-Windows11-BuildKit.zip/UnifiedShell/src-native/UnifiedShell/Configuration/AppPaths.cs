using System;
using System.IO;
using UnifiedShell.Core;

namespace UnifiedShell.Configuration;

/// <summary>
/// Resolves portable or per-user storage paths.
/// Placing a <c>portable.flag</c> file beside UnifiedShell.exe (or passing <c>--portable</c>)
/// stores all configuration, notes, clipboard history and logs in <c>.\data\</c> next to the executable.
/// Otherwise <c>%LOCALAPPDATA%\UnifiedShell\</c> is used.
/// </summary>
public sealed class AppPaths
{
    public required string Root { get; init; }
    public required string ConfigFile { get; init; }
    public required string DataDirectory { get; init; }
    public required string NotesDirectory { get; init; }
    public required string AutosaveNoteFile { get; init; }
    public required string ClipboardFile { get; init; }
    public required string LogDirectory { get; init; }
    public bool Portable { get; init; }
    public string? ExeDirectory { get; init; }

    public static AppPaths Resolve(string[] args, AppLog logger)
    {
        var exeDirectory = Path.GetDirectoryName(Environment.ProcessPath);
        var portableRequested =
            Array.Exists(args, argument => argument.Equals("--portable", StringComparison.OrdinalIgnoreCase)) ||
            (exeDirectory is not null && File.Exists(Path.Combine(exeDirectory, "portable.flag")));

        if (portableRequested && exeDirectory is not null)
        {
            try
            {
                var data = Path.Combine(exeDirectory, "data");
                Directory.CreateDirectory(data);
                var probe = Path.Combine(data, ".write-test");
                File.WriteAllText(probe, "ok");
                File.Delete(probe);
                var portablePaths = Build(exeDirectory, data, portable: true, exeDirectory);
                logger.RedirectDirectory(portablePaths.LogDirectory);
                return portablePaths;
            }
            catch (Exception exception)
            {
                logger.Warn($"Portable directory is not writable ({exception.Message}); falling back to per-user storage.");
            }
        }

        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(local))
        {
            local = Path.Combine(exeDirectory ?? ".", "data");
        }

        var root = Path.Combine(local, "UnifiedShell");
        Directory.CreateDirectory(root);
        var userPaths = Build(root, root, portable: false, exeDirectory);
        logger.RedirectDirectory(userPaths.LogDirectory);
        return userPaths;
    }

    private static AppPaths Build(string root, string dataDirectory, bool portable, string? exeDirectory)
    {
        var logs = Path.Combine(dataDirectory, "logs");
        var notes = Path.Combine(dataDirectory, "notes");
        Directory.CreateDirectory(logs);
        Directory.CreateDirectory(notes);
        return new AppPaths
        {
            Root = root,
            DataDirectory = dataDirectory,
            ConfigFile = Path.Combine(dataDirectory, "config.json"),
            NotesDirectory = notes,
            AutosaveNoteFile = Path.Combine(notes, "autosave.md"),
            ClipboardFile = Path.Combine(dataDirectory, "clipboard.json"),
            LogDirectory = logs,
            Portable = portable,
            ExeDirectory = exeDirectory,
        };
    }
}
