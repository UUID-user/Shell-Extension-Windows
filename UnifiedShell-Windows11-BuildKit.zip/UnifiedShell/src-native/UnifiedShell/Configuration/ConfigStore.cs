using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using UnifiedShell.Core;

namespace UnifiedShell.Configuration;

public sealed class DockShortcutItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..10];
    public string Label { get; set; } = string.Empty;
    public string Target { get; set; } = string.Empty;
    public string? Arguments { get; set; }
    public string Kind { get; set; } = "app"; // "app" | "folder" | "uri"
    public string? IconGlyph { get; set; }
}

public sealed class ShellConfig
{
    public int Schema { get; set; } = 3;

    // General
    public bool LaunchAtSignIn { get; set; }
    public bool MinimiseToBackground { get; set; } = true;
    public string StartupBehaviour { get; set; } = "desktop"; // "desktop" | "launcher"
    public string Language { get; set; } = "en-GB";

    // Appearance
    public string Theme { get; set; } = "dark"; // "system" | "dark" | "light"
    public string Accent { get; set; } = "azure"; // "azure" | "violet" | "teal" | "amber"
    public int Translucency { get; set; } = 76; // 0..100
    public int DockHeight { get; set; } = 40; // 34..54
    public int IconSize { get; set; } = 24; // 20..32
    public int ItemSpacing { get; set; } = 4; // 2..10

    // Dock
    public bool DockEnabled { get; set; } = true;
    public bool AutoHide { get; set; }
    public string DockPosition { get; set; } = "top"; // "top" | "bottom"
    public string DockMonitor { get; set; } = "primary";
    public List<DockShortcutItem> PinnedItems { get; set; } = CreateDefaultPinned();

    // Search
    public string SearchShortcut { get; set; } = "Alt+Space";
    public int ResultLimit { get; set; } = 9;
    public bool SearchSettings { get; set; } = true;
    public bool SearchFiles { get; set; } = true;
    public bool ShowRecentSearches { get; set; } = true;
    public string? CustomEverythingPath { get; set; }
    public List<string> RecentSearches { get; set; } = new();

    // Performance
    public bool MonitorVisible { get; set; } = true;
    public string MetricsPosition { get; set; } = "dock-right"; // "dock-right" | "dock-left" | "bottom-right" | "bottom-left"
    public string MetricsMonitor { get; set; } = "primary";
    public bool MetricsCompact { get; set; }
    public int MetricsIntervalMs { get; set; } = 2000;
    public bool MonitorCpu { get; set; } = true;
    public bool MonitorGpu { get; set; } = true;
    public bool MonitorRam { get; set; } = true;

    // Utilities
    public bool ClipboardEnabled { get; set; } = true;
    public int ClipboardLimit { get; set; } = 25;
    public bool ClipboardImages { get; set; } = true;
    public bool NotepadAutosave { get; set; } = true;
    public string? LastNotepadFilePath { get; set; }
    public bool TimerChime { get; set; } = true;
    public int TimerPresetMinutes { get; set; } = 25;

    // Advanced
    public bool Logging { get; set; }

    public static List<DockShortcutItem> CreateDefaultPinned()
    {
        var userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var documents = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        return new List<DockShortcutItem>
        {
            new() { Id = "pin-explorer", Label = "File Explorer", Target = "explorer.exe", Kind = "app", IconGlyph = "folder" },
            new() { Id = "pin-terminal", Label = "Windows Terminal", Target = "wt.exe", Kind = "app", IconGlyph = "terminal" },
            new() { Id = "pin-browser", Label = "Microsoft Edge", Target = "msedge.exe", Kind = "app", IconGlyph = "globe" },
            new() { Id = "pin-docs", Label = "Documents", Target = string.IsNullOrWhiteSpace(documents) ? userProfile : documents, Kind = "folder", IconGlyph = "folder" },
            new() { Id = "pin-downloads", Label = "Downloads", Target = Path.Combine(userProfile, "Downloads"), Kind = "folder", IconGlyph = "download" },
        };
    }

    public void ClampValues()
    {
        Translucency = Math.Clamp(Translucency, 0, 100);
        DockHeight = Math.Clamp(DockHeight, 34, 54);
        IconSize = Math.Clamp(IconSize, 20, 32);
        ItemSpacing = Math.Clamp(ItemSpacing, 2, 10);
        ResultLimit = Math.Clamp(ResultLimit, 4, 20);
        MetricsIntervalMs = Math.Clamp(MetricsIntervalMs, 500, 10000);
        ClipboardLimit = Math.Clamp(ClipboardLimit, 5, 100);
        TimerPresetMinutes = Math.Clamp(TimerPresetMinutes, 1, 360);
        PinnedItems ??= CreateDefaultPinned();
        RecentSearches ??= new List<string>();
        if (string.IsNullOrWhiteSpace(SearchShortcut)) SearchShortcut = "Alt+Space";
    }
}

public sealed class ConfigStore
{
    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
    };

    private readonly AppPaths _paths;
    private readonly AppLog _log;
    private readonly object _gate = new();

    public event Action<ShellConfig>? Changed;

    public ConfigStore(AppPaths paths, AppLog log)
    {
        _paths = paths;
        _log = log;
    }

    public ShellConfig Current { get; private set; } = new();

    public ShellConfig Load()
    {
        lock (_gate)
        {
            try
            {
                if (File.Exists(_paths.ConfigFile))
                {
                    var json = File.ReadAllText(_paths.ConfigFile);
                    var parsed = JsonSerializer.Deserialize<ShellConfig>(json, JsonOptions);
                    if (parsed is not null)
                    {
                        parsed.ClampValues();
                        Current = parsed;
                        _log.SetVerbose(parsed.Logging);
                        _log.Info($"Configuration loaded from {_paths.ConfigFile}");
                        return parsed;
                    }
                }
            }
            catch (Exception exception)
            {
                _log.Error("Configuration file was unreadable; backing up and restoring defaults", exception);
                try
                {
                    var backup = $"{_paths.ConfigFile}.corrupt-{DateTime.Now:yyyyMMdd-HHmmss}";
                    File.Copy(_paths.ConfigFile, backup, overwrite: true);
                }
                catch
                {
                    // Backup is best effort.
                }
            }

            Current = new ShellConfig();
            Save(Current, raiseEvent: false);
            return Current;
        }
    }

    public bool Save(ShellConfig? config = null, bool raiseEvent = true)
    {
        ShellConfig snapshot;
        lock (_gate)
        {
            snapshot = config ?? Current;
            snapshot.ClampValues();
            try
            {
                var dir = Path.GetDirectoryName(_paths.ConfigFile);
                if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                var temp = _paths.ConfigFile + ".tmp";
                File.WriteAllText(temp, JsonSerializer.Serialize(snapshot, JsonOptions));
                File.Move(temp, _paths.ConfigFile, overwrite: true);
                Current = snapshot;
                _log.SetVerbose(snapshot.Logging);
            }
            catch (Exception exception)
            {
                _log.Error("Could not persist configuration", exception);
                return false;
            }
        }

        if (raiseEvent) Changed?.Invoke(snapshot);
        return true;
    }

    public ShellConfig Reset()
    {
        var fresh = new ShellConfig();
        Save(fresh, raiseEvent: true);
        return fresh;
    }

    public void ExportToFile(string filePath)
    {
        var clone = JsonSerializer.Deserialize<ShellConfig>(JsonSerializer.Serialize(Current, JsonOptions), JsonOptions) ?? new ShellConfig();
        // Machine-specific paths and sign-in hooks do not transfer across machines.
        clone.LaunchAtSignIn = false;
        clone.CustomEverythingPath = null;
        File.WriteAllText(filePath, JsonSerializer.Serialize(clone, JsonOptions));
    }

    public ShellConfig ImportFromFile(string filePath)
    {
        var raw = File.ReadAllText(filePath);
        var imported = JsonSerializer.Deserialize<ShellConfig>(raw, JsonOptions)
                       ?? throw new InvalidDataException("Invalid Unified Shell configuration JSON.");
        imported.LaunchAtSignIn = Current.LaunchAtSignIn;
        imported.ClampValues();
        Save(imported, raiseEvent: true);
        return imported;
    }
}
