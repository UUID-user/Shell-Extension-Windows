using System;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Interop;

namespace UnifiedShell;

public static class Program
{
    private const string MutexName = @"Local\UnifiedShell.PrimaryInstance.v1";

    [STAThread]
    public static void Main(string[] args)
    {
        if (Array.Exists(args, a => a.Equals("--self-test", StringComparison.OrdinalIgnoreCase)))
        {
            Environment.ExitCode = Tests.SelfTestRunner.RunAll();
            return;
        }

        using var singleInstance = new Mutex(initiallyOwned: true, MutexName, out var createdNew);
        if (!createdNew)
        {
            ActivateExistingInstance();
            return;
        }

        var log = AppLog.Create();
        log.Info("Unified Shell 1.0.0 starting (win-x64)");

        ShellController? controller = null;
        try
        {
            var paths = AppPaths.Resolve(args, log);
            var store = new ConfigStore(paths, log);
            store.Load();

            var app = new Application
            {
                ShutdownMode = ShutdownMode.OnExplicitShutdown,
            };
            app.DispatcherUnhandledException += (_, e) =>
            {
                log.Error("Unhandled UI exception", e.Exception);
                e.Handled = true;
            };

            controller = new ShellController(paths, store, log);
            app.Startup += (_, _) => controller.Start();
            app.Exit += (_, _) => controller.Dispose();
            app.Run();
        }
        catch (Exception exception)
        {
            log.Error("Fatal startup exception", exception);
            MessageBox.Show(
                $"Unified Shell encountered a fatal error and could not start.\n\n{exception.Message}\n\nLog file:\n{log.LogFile}",
                "Unified Shell",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Environment.ExitCode = 1;
        }
        finally
        {
            controller?.Dispose();
            log.Info("Unified Shell exited cleanly");
            log.Dispose();
            try
            {
                singleInstance.ReleaseMutex();
            }
            catch (ApplicationException)
            {
                // Ignore if mutex was not owned.
            }
        }
    }

    private static void ActivateExistingInstance()
    {
        try
        {
            var selfPid = Environment.ProcessId;
            foreach (var proc in Process.GetProcessesByName("UnifiedShell"))
            {
                using (proc)
                {
                    if (proc.Id == selfPid || proc.MainWindowHandle == IntPtr.Zero) continue;
                    NativeMethods.ShowWindow(proc.MainWindowHandle, NativeMethods.SW_RESTORE);
                    NativeMethods.SetForegroundWindow(proc.MainWindowHandle);
                    break;
                }
            }
        }
        catch
        {
            // Activation is best effort.
        }
    }
}
