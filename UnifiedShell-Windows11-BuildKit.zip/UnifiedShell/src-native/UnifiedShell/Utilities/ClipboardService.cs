using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Media.Imaging;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Interop;

namespace UnifiedShell.Utilities;

public sealed class ClipboardItemRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..12];
    public string Kind { get; set; } = "text"; // "text" | "image"
    public string Text { get; set; } = string.Empty;
    public string? ImageBase64Png { get; set; }
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.Now;
    public bool Pinned { get; set; }
}

/// <summary>
/// Event-driven local clipboard history service triggered by WM_CLIPBOARDUPDATE.
/// Respects Windows clipboard privacy formats (ExcludeClipboardContentFromMonitorProcessing
/// and CanIncludeInClipboardHistory) used by password managers.
/// </summary>
public sealed class ClipboardService
{
    private readonly AppPaths _paths;
    private readonly ConfigStore _store;
    private readonly AppLog _log;
    private readonly uint _fmtExcludeMonitor;
    private readonly uint _fmtCanIncludeHistory;
    private readonly List<ClipboardItemRecord> _entries = new();
    private bool _suppressSelfCopy;

    public event Action? Changed;

    public ClipboardService(AppPaths paths, ConfigStore store, AppLog log)
    {
        _paths = paths;
        _store = store;
        _log = log;
        _fmtExcludeMonitor = NativeMethods.RegisterClipboardFormatW("ExcludeClipboardContentFromMonitorProcessing");
        _fmtCanIncludeHistory = NativeMethods.RegisterClipboardFormatW("CanIncludeInClipboardHistory");
        LoadFromDisk();
    }

    public IReadOnlyList<ClipboardItemRecord> Entries => _entries;

    public void OnClipboardUpdated()
    {
        if (_suppressSelfCopy || !_store.Current.ClipboardEnabled) return;

        try
        {
            // Respect Windows clipboard privacy hints set by password managers & credential prompts.
            if (_fmtExcludeMonitor != 0 && NativeMethods.IsClipboardFormatAvailable(_fmtExcludeMonitor))
            {
                _log.Info("Skipped clipboard item marked ExcludeClipboardContentFromMonitorProcessing");
                return;
            }
            if (_fmtCanIncludeHistory != 0 && NativeMethods.IsClipboardFormatAvailable(_fmtCanIncludeHistory))
            {
                try
                {
                    if (Clipboard.GetData("CanIncludeInClipboardHistory") is MemoryStream ms && ms.Length >= 4)
                    {
                        var flag = BitConverter.ToInt32(ms.ToArray(), 0);
                        if (flag == 0) return;
                    }
                }
                catch { /* Continue if unreadable */ }
            }

            if (Clipboard.ContainsText())
            {
                var text = Clipboard.GetText();
                if (string.IsNullOrWhiteSpace(text)) return;
                var trimmed = text.Length > 24000 ? text[..24000] : text;

                var existing = _entries.FirstOrDefault(e => e.Kind == "text" && e.Text == trimmed);
                if (existing is not null)
                {
                    existing.CreatedAt = DateTimeOffset.Now;
                    _entries.Remove(existing);
                    _entries.Insert(0, existing);
                }
                else
                {
                    _entries.Insert(0, new ClipboardItemRecord { Kind = "text", Text = trimmed });
                }

                TrimAndPersist();
                Changed?.Invoke();
                return;
            }

            if (_store.Current.ClipboardImages && Clipboard.ContainsImage())
            {
                var bmp = Clipboard.GetImage();
                if (bmp is null) return;
                var pngBase64 = EncodeThumbnailPng(bmp, maxWidth: 360);
                if (pngBase64 is null) return;

                _entries.Insert(0, new ClipboardItemRecord
                {
                    Kind = "image",
                    Text = $"Image ({bmp.PixelWidth}×{bmp.PixelHeight})",
                    ImageBase64Png = pngBase64,
                });
                TrimAndPersist();
                Changed?.Invoke();
            }
        }
        catch (Exception ex)
        {
            // Another process may briefly hold the clipboard open; ignore quietly.
            _log.Info($"Clipboard read skipped: {ex.Message}");
        }
    }

    public bool CopyToClipboard(ClipboardItemRecord item)
    {
        try
        {
            _suppressSelfCopy = true;
            if (item.Kind == "image" && !string.IsNullOrEmpty(item.ImageBase64Png))
            {
                var bytes = Convert.FromBase64String(item.ImageBase64Png);
                using var ms = new MemoryStream(bytes);
                var decoder = new PngBitmapDecoder(ms, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                if (decoder.Frames.Count > 0) Clipboard.SetImage(decoder.Frames[0]);
            }
            else
            {
                Clipboard.SetText(item.Text);
            }
            return true;
        }
        catch (Exception ex)
        {
            _log.Warn($"Clipboard write failed: {ex.Message}");
            return false;
        }
        finally
        {
            _suppressSelfCopy = false;
        }
    }

    public void TogglePin(string id)
    {
        var item = _entries.FirstOrDefault(e => e.Id == id);
        if (item is null) return;
        item.Pinned = !item.Pinned;
        TrimAndPersist();
        Changed?.Invoke();
    }

    public void Delete(string id)
    {
        if (_entries.RemoveAll(e => e.Id == id) > 0)
        {
            SaveToDisk();
            Changed?.Invoke();
        }
    }

    public void ClearUnpinned()
    {
        _entries.RemoveAll(e => !e.Pinned);
        SaveToDisk();
        Changed?.Invoke();
    }

    private void TrimAndPersist()
    {
        var limit = Math.Clamp(_store.Current.ClipboardLimit, 5, 100);
        var pinned = _entries.Where(e => e.Pinned).ToList();
        var unpinned = _entries.Where(e => !e.Pinned).Take(Math.Max(1, limit - pinned.Count)).ToList();
        _entries.Clear();
        _entries.AddRange(pinned.Concat(unpinned).OrderByDescending(e => e.Pinned).ThenByDescending(e => e.CreatedAt));
        SaveToDisk();
    }

    private void LoadFromDisk()
    {
        try
        {
            if (!File.Exists(_paths.ClipboardFile)) return;
            var json = File.ReadAllText(_paths.ClipboardFile);
            var loaded = JsonSerializer.Deserialize<List<ClipboardItemRecord>>(json, ConfigStore.JsonOptions);
            if (loaded is not null)
            {
                _entries.Clear();
                _entries.AddRange(loaded);
            }
        }
        catch (Exception ex)
        {
            _log.Warn($"Could not load saved clipboard history: {ex.Message}");
        }
    }

    private void SaveToDisk()
    {
        try
        {
            // Persist text entries and pinned items; avoid multi-megabyte image blobs on disk.
            var serialisable = _entries
                .Where(e => e.Kind == "text" || e.Pinned)
                .Take(100)
                .ToList();
            File.WriteAllText(_paths.ClipboardFile, JsonSerializer.Serialize(serialisable, ConfigStore.JsonOptions));
        }
        catch (Exception ex)
        {
            _log.Warn($"Could not save clipboard history: {ex.Message}");
        }
    }

    private static string? EncodeThumbnailPng(BitmapSource source, int maxWidth)
    {
        try
        {
            BitmapSource target = source;
            if (source.PixelWidth > maxWidth)
            {
                var scale = (double)maxWidth / source.PixelWidth;
                target = new TransformedBitmap(source, new System.Windows.Media.ScaleTransform(scale, scale));
            }
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(target));
            using var ms = new MemoryStream();
            encoder.Save(ms);
            return ms.Length <= 512_000 ? Convert.ToBase64String(ms.ToArray()) : null;
        }
        catch
        {
            return null;
        }
    }
}
