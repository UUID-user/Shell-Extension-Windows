using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Search;
using UnifiedShell.Themes;

namespace UnifiedShell.Utilities;

/// <summary>
/// Recursive-descent arithmetic evaluator supporting +, -, *, /, parentheses, decimals and percentages.
/// Additive percentages follow standard desktop calculator conventions: 200 + 10% = 220.
/// </summary>
public static class CalculatorEngine
{
    private readonly record struct CalcVal(double Value, bool IsPercent);

    public static bool TryEvaluate(string raw, out double result, out string? error)
    {
        result = 0;
        error = null;
        var src = (raw ?? string.Empty)
            .Replace("×", "*")
            .Replace("÷", "/")
            .Replace("−", "-")
            .Replace(",", "")
            .Replace(" ", "");

        if (src.Length == 0)
        {
            error = "Empty expression";
            return false;
        }

        int pos = 0;
        try
        {
            var val = ParseAddSub(src, ref pos);
            if (pos < src.Length)
            {
                error = $"Unexpected '{src[pos]}'";
                return false;
            }
            if (double.IsNaN(val.Value) || double.IsInfinity(val.Value))
            {
                error = "Out of range";
                return false;
            }
            result = val.Value;
            return true;
        }
        catch (DivideByZeroException)
        {
            error = "Cannot divide by zero";
            return false;
        }
        catch (FormatException ex)
        {
            error = ex.Message;
            return false;
        }
    }

    private static CalcVal ParseAddSub(string s, ref int p)
    {
        var left = ParseMulDiv(s, ref p);
        while (p < s.Length && (s[p] == '+' || s[p] == '-'))
        {
            char op = s[p++];
            var right = ParseMulDiv(s, ref p);
            double v = op == '+'
                ? (right.IsPercent ? left.Value + left.Value * right.Value : left.Value + right.Value)
                : (right.IsPercent ? left.Value - left.Value * right.Value : left.Value - right.Value);
            left = new CalcVal(v, false);
        }
        return left;
    }

    private static CalcVal ParseMulDiv(string s, ref int p)
    {
        var left = ParseUnary(s, ref p);
        while (p < s.Length && (s[p] == '*' || s[p] == '/'))
        {
            char op = s[p++];
            var right = ParseUnary(s, ref p);
            if (op == '*') left = new CalcVal(left.Value * right.Value, false);
            else
            {
                if (right.Value == 0) throw new DivideByZeroException();
                left = new CalcVal(left.Value / right.Value, false);
            }
        }
        return left;
    }

    private static CalcVal ParseUnary(string s, ref int p)
    {
        if (p < s.Length && s[p] == '+') { p++; return ParseUnary(s, ref p); }
        if (p < s.Length && s[p] == '-')
        {
            p++;
            var inner = ParseUnary(s, ref p);
            return new CalcVal(-inner.Value, inner.IsPercent);
        }
        return ParsePrimary(s, ref p);
    }

    private static CalcVal ParsePrimary(string s, ref int p)
    {
        if (p < s.Length && s[p] == '(')
        {
            p++;
            var inner = ParseAddSub(s, ref p);
            if (p >= s.Length || s[p] != ')') throw new FormatException("Missing ')'");
            p++;
            if (p < s.Length && s[p] == '%') { p++; return new CalcVal(inner.Value / 100.0, true); }
            return new CalcVal(inner.Value, false);
        }

        int start = p;
        while (p < s.Length && (char.IsDigit(s[p]) || s[p] == '.')) p++;
        if (start == p) throw new FormatException("Invalid number");
        if (!double.TryParse(s[start..p], NumberStyles.Float, CultureInfo.InvariantCulture, out var num))
        {
            throw new FormatException("Invalid number");
        }
        if (p < s.Length && s[p] == '%') { p++; return new CalcVal(num / 100.0, true); }
        return new CalcVal(num, false);
    }

    public static string Format(double v)
    {
        if (Math.Abs(v) < 1e-12) return "0";
        if (Math.Abs(v) >= 1e12 || Math.Abs(v) < 1e-6) return v.ToString("0.######e+0", CultureInfo.InvariantCulture);
        return Math.Round(v, 10).ToString("#,0.##########", CultureInfo.InvariantCulture);
    }
}

/// <summary>
/// Accurate monotonic countdown timer independent of UI frame rates.
/// </summary>
public sealed class TimerController
{
    private readonly ConfigStore _store;
    private readonly DispatcherTimer _uiTick;
    private long _endTimestamp;
    private TimeSpan _total;
    private TimeSpan _remaining;

    public bool IsRunning { get; private set; }
    public bool Completed { get; private set; }
    public TimeSpan Total => _total;
    public TimeSpan Remaining => IsRunning
        ? TimeSpan.FromSeconds(Math.Max(0, (_endTimestamp - Stopwatch.GetTimestamp()) / (double)Stopwatch.Frequency))
        : _remaining;

    public event Action? Updated;

    public TimerController(ConfigStore store)
    {
        _store = store;
        _total = TimeSpan.FromMinutes(Math.Clamp(store.Current.TimerPresetMinutes, 1, 360));
        _remaining = _total;
        _uiTick = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
        _uiTick.Tick += (_, _) =>
        {
            if (IsRunning && Remaining <= TimeSpan.Zero)
            {
                IsRunning = false;
                _remaining = TimeSpan.Zero;
                Completed = true;
                _uiTick.Stop();
                if (_store.Current.TimerChime) SystemSounds.Asterisk.Play();
            }
            Updated?.Invoke();
        };
    }

    public void SetDuration(TimeSpan duration)
    {
        IsRunning = false;
        Completed = false;
        _uiTick.Stop();
        _total = TimeSpan.FromSeconds(Math.Clamp(duration.TotalSeconds, 5, 6 * 3600));
        _remaining = _total;
        Updated?.Invoke();
    }

    public void StartOrResume()
    {
        if (IsRunning) return;
        if (_remaining <= TimeSpan.Zero) _remaining = _total;
        Completed = false;
        _endTimestamp = Stopwatch.GetTimestamp() + (long)(_remaining.TotalSeconds * Stopwatch.Frequency);
        IsRunning = true;
        _uiTick.Start();
        Updated?.Invoke();
    }

    public void Pause()
    {
        if (!IsRunning) return;
        _remaining = Remaining;
        IsRunning = false;
        _uiTick.Stop();
        Updated?.Invoke();
    }

    public void Reset()
    {
        IsRunning = false;
        Completed = false;
        _uiTick.Stop();
        _remaining = _total;
        Updated?.Invoke();
    }
}

/// <summary>
/// Monotonic high-resolution stopwatch with lap recording.
/// </summary>
public sealed class StopwatchController
{
    private readonly Stopwatch _sw = new();
    private readonly DispatcherTimer _uiTick;
    private readonly List<TimeSpan> _laps = new();

    public bool IsRunning => _sw.IsRunning;
    public TimeSpan Elapsed => _sw.Elapsed;
    public IReadOnlyList<TimeSpan> Laps => _laps;
    public event Action? Updated;

    public StopwatchController()
    {
        _uiTick = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(50) };
        _uiTick.Tick += (_, _) => Updated?.Invoke();
    }

    public void Start()
    {
        if (_sw.IsRunning) return;
        _sw.Start();
        _uiTick.Start();
        Updated?.Invoke();
    }

    public void Pause()
    {
        if (!_sw.IsRunning) return;
        _sw.Stop();
        _uiTick.Stop();
        Updated?.Invoke();
    }

    public void Reset()
    {
        _sw.Reset();
        _laps.Clear();
        _uiTick.Stop();
        Updated?.Invoke();
    }

    public void RecordLap()
    {
        if (_sw.Elapsed <= TimeSpan.Zero) return;
        _laps.Insert(0, _sw.Elapsed);
        if (_laps.Count > 50) _laps.RemoveAt(_laps.Count - 1);
        Updated?.Invoke();
    }
}

/// <summary>
/// Base lightweight popover window anchored to the Top Dock.
/// Automatically dismisses on Esc or deactivation unless pinned/modal.
/// </summary>
public abstract class DockPopoverWindow : Window
{
    public string PanelId { get; }

    protected DockPopoverWindow(string panelId, double width)
    {
        PanelId = panelId;
        Width = width;
        SizeToContent = SizeToContent.Height;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        Topmost = true;
        ShowInTaskbar = false;

        Deactivated += (_, _) => { if (IsVisible) Hide(); };
        PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape)
            {
                e.Handled = true;
                Hide();
            }
        };
    }

    public void ShowAnchored(MonitorDescriptor monitor, ShellConfig config, string horizontalAlign = "center")
    {
        RebuildContent();
        UpdateLayout();
        var estHeight = ActualHeight > 30 ? ActualHeight : 340;

        Left = horizontalAlign switch
        {
            "left" => monitor.WorkDipLeft + 8,
            "right" => monitor.WorkDipLeft + monitor.WorkDipWidth - Width - 8,
            _ => monitor.WorkDipLeft + (monitor.WorkDipWidth - Width) / 2,
        };

        if (config.DockPosition == "bottom")
        {
            Top = monitor.WorkDipBottom - config.DockHeight - estHeight - 8;
        }
        else
        {
            Top = monitor.WorkDipTop + config.DockHeight + 6;
        }

        Show();
        NativeMethods.ApplyWindowChrome(this, ThemeManager.IsDark, toolWindow: true, roundCorners: true);
        Activate();
    }

    protected abstract void RebuildContent();

    protected DockPanel CreateHeader(string icon, string title, string subtitle)
    {
        var bar = new DockPanel { Height = 44, Margin = new Thickness(12, 2, 6, 2) };
        var close = ThemeManager.CreateIconButton("close", "Close", 26, 12);
        close.Click += (_, _) => Hide();
        DockPanel.SetDock(close, System.Windows.Controls.Dock.Right);
        bar.Children.Add(close);

        var left = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        left.Children.Add(VectorIcons.Create(icon, 15, ThemeManager.AccentBrush));
        var titles = new StackPanel { Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
        titles.Children.Add(new TextBlock { Text = title, FontSize = 12.5, FontWeight = FontWeights.SemiBold, Foreground = ThemeManager.TextPrimary });
        titles.Children.Add(new TextBlock { Text = subtitle, FontSize = 10, Foreground = ThemeManager.TextTertiary });
        left.Children.Add(titles);
        bar.Children.Add(left);
        return bar;
    }
}

public sealed class CalculatorPopup : DockPopoverWindow
{
    private string _expr = string.Empty;
    private string? _evaluated;
    private string? _error;
    private readonly List<(string Expr, string Res)> _history = new();
    private TextBlock _subDisplay = null!;
    private TextBlock _mainDisplay = null!;

    public CalculatorPopup() : base("calculator", 296)
    {
        PreviewTextInput += OnTextInput;
        PreviewKeyDown += OnCalcKeyDown;
    }

    protected override void RebuildContent()
    {
        var root = new StackPanel();
        root.Children.Add(CreateHeader("calculator", "Calculator", "Keyboard ready · % aware"));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        var screenStack = new StackPanel();
        _subDisplay = new TextBlock
        {
            FontSize = 10.5,
            FontFamily = ThemeManager.MonoFont,
            Foreground = ThemeManager.TextTertiary,
            TextAlignment = TextAlignment.Right,
            Height = 16,
        };
        _mainDisplay = new TextBlock
        {
            FontSize = 23,
            FontFamily = ThemeManager.MonoFont,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            TextAlignment = TextAlignment.Right,
            TextTrimming = TextTrimming.CharacterEllipsis,
        };
        screenStack.Children.Add(_subDisplay);
        screenStack.Children.Add(_mainDisplay);

        root.Children.Add(new Border
        {
            Margin = new Thickness(10, 10, 10, 6),
            Padding = new Thickness(10, 8, 10, 8),
            CornerRadius = new CornerRadius(6),
            Background = ThemeManager.SunkenBackground,
            BorderBrush = ThemeManager.BorderSubtle,
            BorderThickness = new Thickness(1),
            Child = screenStack,
        });

        var keys = new[]
        {
            ("C", "clear"), ("⌫", "back"), ("(", "("), (")", ")"),
            ("7", "7"), ("8", "8"), ("9", "9"), ("÷", "/"),
            ("4", "4"), ("5", "5"), ("6", "6"), ("×", "*"),
            ("1", "1"), ("2", "2"), ("3", "3"), ("−", "-"),
            ("%", "%"), ("0", "0"), (".", "."), ("+", "+"),
        };

        var grid = new UniformGrid { Columns = 4, Margin = new Thickness(8, 2, 8, 4) };
        foreach (var (label, token) in keys)
        {
            var captured = token;
            var isOp = token is "/" or "*" or "-" or "+";
            var b = ThemeManager.CreateButton(label, null, primary: false, height: 34);
            b.Margin = new Thickness(2);
            if (isOp && b.Content is Border bd) bd.Background = ThemeManager.AccentSoftBrush;
            b.Click += (_, _) => Press(captured);
            grid.Children.Add(b);
        }
        root.Children.Add(grid);

        var bottomRow = new Grid { Margin = new Thickness(10, 0, 10, 10) };
        bottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        bottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        var copyBtn = ThemeManager.CreateButton("Copy", "copy", height: 32);
        copyBtn.Margin = new Thickness(0, 0, 6, 0);
        copyBtn.Click += (_, _) =>
        {
            var val = _evaluated ?? (_expr.Length > 0 ? _expr : "0");
            try { Clipboard.SetText(val); } catch { /* ignore */ }
        };
        Grid.SetColumn(copyBtn, 0);
        bottomRow.Children.Add(copyBtn);

        var eqBtn = ThemeManager.CreateButton("=", null, primary: true, height: 32);
        eqBtn.Click += (_, _) => Press("=");
        Grid.SetColumn(eqBtn, 1);
        bottomRow.Children.Add(eqBtn);
        root.Children.Add(bottomRow);

        if (_history.Count > 0)
        {
            root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
            var histPanel = new StackPanel { Margin = new Thickness(10, 4, 10, 8) };
            foreach (var (e, r) in _history.Take(3))
            {
                var captured = r.Replace(",", "");
                var row = new DockPanel { Margin = new Thickness(0, 2, 0, 2), Cursor = Cursors.Hand };
                var resTb = new TextBlock { Text = r, FontFamily = ThemeManager.MonoFont, FontSize = 11, FontWeight = FontWeights.Medium, Foreground = ThemeManager.TextPrimary };
                DockPanel.SetDock(resTb, System.Windows.Controls.Dock.Right);
                row.Children.Add(resTb);
                row.Children.Add(new TextBlock { Text = e, FontFamily = ThemeManager.MonoFont, FontSize = 10.5, Foreground = ThemeManager.TextTertiary });
                row.MouseLeftButtonUp += (_, _) => { _expr = captured; _evaluated = r; RefreshScreen(); };
                histPanel.Children.Add(row);
            }
            root.Children.Add(histPanel);
        }

        Content = ThemeManager.CreatePanelShell(root);
        RefreshScreen();
    }

    private void Press(string token)
    {
        _error = null;
        if (token == "clear") { _expr = string.Empty; _evaluated = null; }
        else if (token == "back") { _evaluated = null; if (_expr.Length > 0) _expr = _expr[..^1]; }
        else if (token == "=")
        {
            if (string.IsNullOrWhiteSpace(_expr)) return;
            if (CalculatorEngine.TryEvaluate(_expr, out var res, out var err))
            {
                var formatted = CalculatorEngine.Format(res);
                _history.Insert(0, (_expr, formatted));
                _evaluated = formatted;
                _expr = formatted.Replace(",", "");
                RebuildContent();
                return;
            }
            _error = err;
        }
        else
        {
            var isOp = token is "+" or "-" or "*" or "/" or "%";
            if (_evaluated is not null && !isOp) _expr = token;
            else _expr += token;
            _evaluated = null;
        }
        RefreshScreen();
    }

    private void RefreshScreen()
    {
        if (_error is not null)
        {
            _subDisplay.Text = _expr;
            _mainDisplay.Text = _error;
            _mainDisplay.Foreground = ThemeManager.DangerBrush;
            return;
        }
        _mainDisplay.Foreground = ThemeManager.TextPrimary;
        _mainDisplay.Text = _evaluated ?? (_expr.Length > 0 ? _expr : "0");
        if (_evaluated is null && _expr.Length > 0 && CalculatorEngine.TryEvaluate(_expr, out var live, out _))
        {
            _subDisplay.Text = "= " + CalculatorEngine.Format(live);
        }
        else
        {
            _subDisplay.Text = string.Empty;
        }
    }

    private void OnTextInput(object sender, TextCompositionEventArgs e)
    {
        foreach (char c in e.Text)
        {
            if (char.IsDigit(c) || c is '.' or '+' or '-' or '*' or '/' or '%' or '(' or ')')
            {
                Press(c.ToString());
                e.Handled = true;
            }
            else if (c == '=')
            {
                Press("=");
                e.Handled = true;
            }
        }
    }

    private void OnCalcKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) { e.Handled = true; Press("="); }
        else if (e.Key == Key.Back) { e.Handled = true; Press("back"); }
        else if (e.Key == Key.Delete) { e.Handled = true; Press("clear"); }
    }
}

public sealed class CalendarPopup : DockPopoverWindow
{
    private DateTime _monthCursor = new(DateTime.Today.Year, DateTime.Today.Month, 1);
    private DateTime _selectedDate = DateTime.Today;

    public CalendarPopup() : base("calendar", 308) { }

    protected override void RebuildContent()
    {
        var today = DateTime.Today;
        var root = new StackPanel();
        root.Children.Add(CreateHeader("calendar", "Calendar", today.ToString("dddd, d MMMM yyyy", CultureInfo.InvariantCulture)));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        var nav = new DockPanel { Margin = new Thickness(12, 8, 10, 6) };
        var navBtns = new StackPanel { Orientation = Orientation.Horizontal };
        var todayBtn = ThemeManager.CreateButton("Today", null, subtle: true, height: 22);
        todayBtn.Click += (_, _) => { _monthCursor = new DateTime(today.Year, today.Month, 1); _selectedDate = today; RebuildContent(); };
        var prevBtn = ThemeManager.CreateIconButton("chevronLeft", "Previous month", 24, 13);
        prevBtn.Click += (_, _) => { _monthCursor = _monthCursor.AddMonths(-1); RebuildContent(); };
        var nextBtn = ThemeManager.CreateIconButton("chevronRight", "Next month", 24, 13);
        nextBtn.Click += (_, _) => { _monthCursor = _monthCursor.AddMonths(1); RebuildContent(); };
        navBtns.Children.Add(todayBtn);
        navBtns.Children.Add(prevBtn);
        navBtns.Children.Add(nextBtn);
        DockPanel.SetDock(navBtns, System.Windows.Controls.Dock.Right);
        nav.Children.Add(navBtns);
        nav.Children.Add(new TextBlock
        {
            Text = _monthCursor.ToString("MMMM yyyy", CultureInfo.InvariantCulture),
            FontSize = 13,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            VerticalAlignment = VerticalAlignment.Center,
        });
        root.Children.Add(nav);

        var weekHead = new UniformGrid { Columns = 7, Margin = new Thickness(10, 0, 10, 2) };
        foreach (var wd in new[] { "Mo", "Tu", "We", "Th", "Fr", "Sa", "Su" })
        {
            weekHead.Children.Add(new TextBlock
            {
                Text = wd,
                FontSize = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = ThemeManager.TextTertiary,
                TextAlignment = TextAlignment.Center,
            });
        }
        root.Children.Add(weekHead);

        var offset = ((int)_monthCursor.DayOfWeek + 6) % 7;
        var gridStart = _monthCursor.AddDays(-offset);
        var daysGrid = new UniformGrid { Columns = 7, Rows = 6, Margin = new Thickness(10, 2, 10, 8) };

        for (int i = 0; i < 42; i++)
        {
            var date = gridStart.AddDays(i);
            var outside = date.Month != _monthCursor.Month;
            var isToday = date == today;
            var isSelected = date == _selectedDate;

            var cell = new Border
            {
                Height = 29,
                Margin = new Thickness(1),
                CornerRadius = new CornerRadius(5),
                Background = isSelected ? ThemeManager.AccentBrush : Brushes.Transparent,
                BorderBrush = isToday ? ThemeManager.AccentBrush : Brushes.Transparent,
                BorderThickness = new Thickness(1),
                Cursor = Cursors.Hand,
                Child = new TextBlock
                {
                    Text = date.Day.ToString(),
                    FontSize = 11.5,
                    FontWeight = isSelected || isToday ? FontWeights.SemiBold : FontWeights.Normal,
                    Foreground = isSelected ? ThemeManager.AccentFgBrush : outside ? ThemeManager.TextTertiary : ThemeManager.TextPrimary,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                },
            };
            cell.MouseLeftButtonUp += (_, _) =>
            {
                _selectedDate = date;
                _monthCursor = new DateTime(date.Year, date.Month, 1);
                RebuildContent();
            };
            daysGrid.Children.Add(cell);
        }
        root.Children.Add(daysGrid);

        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        var isoWeek = ISOWeek.GetWeekOfYear(_selectedDate);
        root.Children.Add(new TextBlock
        {
            Text = $"{_selectedDate:dddd, d MMMM yyyy}  ·  ISO Week {isoWeek}  ·  Day {_selectedDate.DayOfYear}",
            FontSize = 10.5,
            Foreground = ThemeManager.TextSecondary,
            Margin = new Thickness(12, 8, 12, 10),
        });

        Content = ThemeManager.CreatePanelShell(root);
    }
}

public sealed class TimerPopup : DockPopoverWindow
{
    private readonly TimerController _timer;
    private TextBlock _timeText = null!;
    private TextBlock _stateText = null!;
    private TextBox _customMinBox = null!;

    public TimerPopup(TimerController timer) : base("timer", 296)
    {
        _timer = timer;
        _timer.Updated += () =>
        {
            if (!IsVisible || _timeText is null) return;
            RefreshDisplay();
        };
    }

    protected override void RebuildContent()
    {
        var root = new StackPanel();
        root.Children.Add(CreateHeader("timer", "Timer", "Monotonic timestamp countdown"));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        _timeText = new TextBlock
        {
            FontFamily = ThemeManager.MonoFont,
            FontSize = 30,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 14, 0, 2),
        };
        _stateText = new TextBlock
        {
            FontSize = 10.5,
            Foreground = ThemeManager.TextTertiary,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 10),
        };
        root.Children.Add(_timeText);
        root.Children.Add(_stateText);

        var presets = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(10, 0, 10, 8) };
        foreach (var min in new[] { 1, 5, 10, 15, 25, 45 })
        {
            var captured = min;
            var active = Math.Abs(_timer.Total.TotalMinutes - min) < 0.01;
            var b = ThemeManager.CreateButton($"{min}m", null, primary: active, height: 24);
            b.Margin = new Thickness(2);
            b.Click += (_, _) => { _timer.SetDuration(TimeSpan.FromMinutes(captured)); RebuildContent(); };
            presets.Children.Add(b);
        }
        root.Children.Add(presets);

        var customRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(10, 0, 10, 10) };
        _customMinBox = ThemeManager.CreateTextBox("min", height: 26, mono: true);
        _customMinBox.Width = 58;
        _customMinBox.Text = ((int)Math.Round(_timer.Total.TotalMinutes)).ToString();
        var setBtn = ThemeManager.CreateButton("Set minutes", null, height: 26);
        setBtn.Margin = new Thickness(6, 0, 0, 0);
        setBtn.Click += (_, _) =>
        {
            if (double.TryParse(_customMinBox.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out var m) && m > 0)
            {
                _timer.SetDuration(TimeSpan.FromMinutes(Math.Clamp(m, 0.25, 360)));
                RebuildContent();
            }
        };
        customRow.Children.Add(_customMinBox);
        customRow.Children.Add(setBtn);
        root.Children.Add(customRow);

        var controls = new UniformGrid { Columns = 2, Margin = new Thickness(10, 0, 10, 12) };
        var startPause = ThemeManager.CreateButton(
            _timer.IsRunning ? "Pause" : (_timer.Remaining < _timer.Total && _timer.Remaining > TimeSpan.Zero ? "Resume" : "Start"),
            _timer.IsRunning ? "pause" : "play",
            primary: true,
            height: 30);
        startPause.Margin = new Thickness(0, 0, 4, 0);
        startPause.Click += (_, _) =>
        {
            if (_timer.IsRunning) _timer.Pause();
            else _timer.StartOrResume();
            RebuildContent();
        };

        var reset = ThemeManager.CreateButton("Reset", "reset", height: 30);
        reset.Margin = new Thickness(4, 0, 0, 0);
        reset.Click += (_, _) => { _timer.Reset(); RebuildContent(); };

        controls.Children.Add(startPause);
        controls.Children.Add(reset);
        root.Children.Add(controls);

        Content = ThemeManager.CreatePanelShell(root);
        RefreshDisplay();
    }

    private void RefreshDisplay()
    {
        var r = _timer.Remaining;
        _timeText.Text = r.TotalHours >= 1 ? $"{(int)r.TotalHours}:{r.Minutes:D2}:{r.Seconds:D2}" : $"{r.Minutes:D2}:{r.Seconds:D2}";
        _stateText.Text = _timer.Completed ? "Timer complete" : _timer.IsRunning ? "Counting down" : "Ready";
        _stateText.Foreground = _timer.Completed ? ThemeManager.SuccessBrush : ThemeManager.TextTertiary;
    }
}

public sealed class StopwatchPopup : DockPopoverWindow
{
    private readonly StopwatchController _sw;
    private TextBlock _elapsedText = null!;
    private StackPanel _lapsPanel = null!;
    private int _renderedLapCount = -1;

    public StopwatchPopup(StopwatchController sw) : base("stopwatch", 304)
    {
        _sw = sw;
        _sw.Updated += () =>
        {
            if (!IsVisible || _elapsedText is null) return;
            var e = _sw.Elapsed;
            _elapsedText.Text = e.TotalHours >= 1
                ? $"{(int)e.TotalHours}:{e.Minutes:D2}:{e.Seconds:D2}.{e.Milliseconds / 10:D2}"
                : $"{e.Minutes:D2}:{e.Seconds:D2}.{e.Milliseconds / 10:D2}";
            if (_renderedLapCount != _sw.Laps.Count) RebuildLaps();
        };
    }

    protected override void RebuildContent()
    {
        var root = new StackPanel();
        root.Children.Add(CreateHeader("stopwatch", "Stopwatch", "High-resolution monotonic timer"));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        var e = _sw.Elapsed;
        _elapsedText = new TextBlock
        {
            Text = $"{e.Minutes:D2}:{e.Seconds:D2}.{e.Milliseconds / 10:D2}",
            FontFamily = ThemeManager.MonoFont,
            FontSize = 30,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 14, 0, 12),
        };
        root.Children.Add(_elapsedText);

        var row = new Grid { Margin = new Thickness(10, 0, 10, 10) };
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var runBtn = ThemeManager.CreateButton(_sw.IsRunning ? "Pause" : (e > TimeSpan.Zero ? "Resume" : "Start"), _sw.IsRunning ? "pause" : "play", primary: true, height: 30);
        runBtn.Margin = new Thickness(0, 0, 4, 0);
        runBtn.Click += (_, _) => { if (_sw.IsRunning) _sw.Pause(); else _sw.Start(); RebuildContent(); };
        Grid.SetColumn(runBtn, 0);
        row.Children.Add(runBtn);

        var lapBtn = ThemeManager.CreateButton("Lap", "flag", height: 30);
        lapBtn.Margin = new Thickness(2, 0, 4, 0);
        lapBtn.Click += (_, _) => { _sw.RecordLap(); RebuildLaps(); };
        Grid.SetColumn(lapBtn, 1);
        row.Children.Add(lapBtn);

        var rstBtn = ThemeManager.CreateButton("", "reset", height: 30);
        rstBtn.ToolTip = "Reset stopwatch";
        rstBtn.Click += (_, _) => { _sw.Reset(); RebuildContent(); };
        Grid.SetColumn(rstBtn, 2);
        row.Children.Add(rstBtn);
        root.Children.Add(row);

        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        _lapsPanel = new StackPanel { Margin = new Thickness(12, 6, 12, 8) };
        root.Children.Add(new ScrollViewer { MaxHeight = 156, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _lapsPanel });

        Content = ThemeManager.CreatePanelShell(root);
        RebuildLaps();
    }

    private void RebuildLaps()
    {
        if (_lapsPanel is null) return;
        _lapsPanel.Children.Clear();
        _renderedLapCount = _sw.Laps.Count;

        if (_sw.Laps.Count == 0)
        {
            _lapsPanel.Children.Add(new TextBlock
            {
                Text = "Press Lap while running to record split and total times.",
                FontSize = 10.5,
                Foreground = ThemeManager.TextTertiary,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 8, 0, 8),
            });
            return;
        }

        for (int i = 0; i < _sw.Laps.Count; i++)
        {
            var total = _sw.Laps[i];
            var prev = i + 1 < _sw.Laps.Count ? _sw.Laps[i + 1] : TimeSpan.Zero;
            var split = total - prev;
            var lapNum = _sw.Laps.Count - i;

            var dp = new DockPanel { Margin = new Thickness(0, 2, 0, 2) };
            var totTb = new TextBlock
            {
                Text = $"{total.Minutes:D2}:{total.Seconds:D2}.{total.Milliseconds / 100}",
                FontFamily = ThemeManager.MonoFont,
                FontSize = 11,
                Foreground = ThemeManager.TextPrimary,
                Width = 72,
                TextAlignment = TextAlignment.Right,
            };
            DockPanel.SetDock(totTb, System.Windows.Controls.Dock.Right);
            dp.Children.Add(totTb);

            var spTb = new TextBlock
            {
                Text = $"+{split.Minutes:D2}:{split.Seconds:D2}.{split.Milliseconds / 100}",
                FontFamily = ThemeManager.MonoFont,
                FontSize = 11,
                Foreground = ThemeManager.TextSecondary,
                TextAlignment = TextAlignment.Right,
            };
            DockPanel.SetDock(spTb, System.Windows.Controls.Dock.Right);
            dp.Children.Add(spTb);

            dp.Children.Add(new TextBlock
            {
                Text = $"#{lapNum}",
                FontFamily = ThemeManager.MonoFont,
                FontSize = 10.5,
                Foreground = ThemeManager.TextTertiary,
            });
            _lapsPanel.Children.Add(dp);
        }
    }
}

public sealed class ClipboardPopup : DockPopoverWindow
{
    private readonly ClipboardService _clipboard;
    private readonly ConfigStore _store;
    private string _filter = string.Empty;

    public ClipboardPopup(ClipboardService clipboard, ConfigStore store) : base("clipboard", 360)
    {
        _clipboard = clipboard;
        _store = store;
        _clipboard.Changed += () => { if (IsVisible) RebuildContent(); };
    }

    protected override void RebuildContent()
    {
        var cfg = _store.Current;
        var root = new StackPanel();
        root.Children.Add(CreateHeader("clipboard", "Clipboard History", $"{_clipboard.Entries.Count} of {cfg.ClipboardLimit} local entries"));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        var topBar = new DockPanel { Margin = new Thickness(10, 8, 10, 6) };
        var toggle = ThemeManager.CreateToggle(cfg.ClipboardEnabled, enabled =>
        {
            _store.Current.ClipboardEnabled = enabled;
            _store.Save();
            RebuildContent();
        });
        toggle.ToolTip = "Enable or disable clipboard capture";
        toggle.Margin = new Thickness(8, 0, 0, 0);
        DockPanel.SetDock(toggle, System.Windows.Controls.Dock.Right);
        topBar.Children.Add(toggle);

        var filterBox = ThemeManager.CreateTextBox("Filter entries…", height: 26);
        filterBox.Text = _filter;
        filterBox.TextChanged += (_, _) =>
        {
            _filter = filterBox.Text;
            RebuildContent();
        };
        topBar.Children.Add(filterBox);
        root.Children.Add(topBar);

        var listHost = new StackPanel { Margin = new Thickness(8, 0, 8, 6) };
        var items = _clipboard.Entries
            .Where(e => string.IsNullOrWhiteSpace(_filter) || e.Text.Contains(_filter, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (items.Count == 0)
        {
            listHost.Children.Add(new TextBlock
            {
                Text = cfg.ClipboardEnabled
                    ? "Copy text or images anywhere in Windows to populate local history."
                    : "Clipboard history capture is currently disabled.",
                FontSize = 11,
                Foreground = ThemeManager.TextTertiary,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(14, 22, 14, 22),
            });
        }
        else
        {
            foreach (var entry in items)
            {
                var captured = entry;
                var row = new Grid { Margin = new Thickness(0, 2, 0, 2) };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var leftStack = new StackPanel { Cursor = Cursors.Hand };
                if (captured.Kind == "image" && !string.IsNullOrEmpty(captured.ImageBase64Png))
                {
                    try
                    {
                        var bytes = Convert.FromBase64String(captured.ImageBase64Png);
                        using var ms = new MemoryStream(bytes);
                        var bmp = new BitmapImage();
                        bmp.BeginInit();
                        bmp.CacheOption = BitmapCacheOption.OnLoad;
                        bmp.StreamSource = ms;
                        bmp.EndInit();
                        bmp.Freeze();
                        leftStack.Children.Add(new Image { Source = bmp, MaxHeight = 64, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 3) });
                    }
                    catch { /* fallback to text label */ }
                }

                var previewLine = captured.Text.Replace("\r", " ").Replace("\n", " ↵ ");
                if (previewLine.Length > 110) previewLine = previewLine[..110] + "…";
                leftStack.Children.Add(new TextBlock
                {
                    Text = previewLine,
                    FontSize = 11.5,
                    Foreground = ThemeManager.TextPrimary,
                    TextWrapping = TextWrapping.Wrap,
                });
                leftStack.Children.Add(new TextBlock
                {
                    Text = $"{captured.CreatedAt:HH:mm}" + (captured.Pinned ? " · Pinned" : ""),
                    FontSize = 9.5,
                    Foreground = captured.Pinned ? ThemeManager.AccentBrush : ThemeManager.TextTertiary,
                });
                leftStack.MouseLeftButtonUp += (_, _) =>
                {
                    _clipboard.CopyToClipboard(captured);
                    Hide();
                };
                Grid.SetColumn(leftStack, 0);
                row.Children.Add(leftStack);

                var btns = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                var pinBtn = ThemeManager.CreateIconButton("pin", captured.Pinned ? "Unpin" : "Pin", 24, 12, active: captured.Pinned);
                pinBtn.Click += (_, _) => _clipboard.TogglePin(captured.Id);
                var delBtn = ThemeManager.CreateIconButton("trash", "Delete entry", 24, 12);
                delBtn.Click += (_, _) => _clipboard.Delete(captured.Id);
                btns.Children.Add(pinBtn);
                btns.Children.Add(delBtn);
                Grid.SetColumn(btns, 1);
                row.Children.Add(btns);

                listHost.Children.Add(new Border
                {
                    Padding = new Thickness(8, 6, 6, 6),
                    CornerRadius = new CornerRadius(5),
                    Background = ThemeManager.SurfaceSubtle,
                    BorderBrush = ThemeManager.BorderSubtle,
                    BorderThickness = new Thickness(1),
                    Margin = new Thickness(0, 0, 0, 3),
                    Child = row,
                });
            }
        }

        root.Children.Add(new ScrollViewer { MaxHeight = 310, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = listHost });
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        var footer = new DockPanel { Margin = new Thickness(10, 6, 10, 8) };
        var clearBtn = ThemeManager.CreateButton("Clear unpinned", "trash", subtle: true, height: 24);
        clearBtn.Click += (_, _) => _clipboard.ClearUnpinned();
        DockPanel.SetDock(clearBtn, System.Windows.Controls.Dock.Right);
        footer.Children.Add(clearBtn);
        footer.Children.Add(new TextBlock
        {
            Text = "Local storage only · password-manager exclusions respected",
            FontSize = 9.5,
            Foreground = ThemeManager.TextTertiary,
            VerticalAlignment = VerticalAlignment.Center,
        });
        root.Children.Add(footer);

        Content = ThemeManager.CreatePanelShell(root);
    }
}

public sealed class TrayMirrorPopup : DockPopoverWindow
{
    private readonly AppLog _log;

    public TrayMirrorPopup(AppLog log) : base("tray", 332)
    {
        _log = log;
    }

    protected override void RebuildContent()
    {
        var status = SystemStatusService.Query();
        var apps = SystemTrayMirrorService.QueryActiveItems();

        var root = new StackPanel();
        root.Children.Add(CreateHeader("wifi", "Mirrored System Tray", "Native Windows tray remains operational"));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        // Master volume row (Core Audio)
        var volPanel = new StackPanel { Margin = new Thickness(12, 10, 12, 8) };
        var volHead = new DockPanel();
        var volVal = new TextBlock
        {
            Text = status.IsMuted ? "Muted" : $"{status.VolumePercent}%",
            FontFamily = ThemeManager.MonoFont,
            FontSize = 11,
            Foreground = ThemeManager.TextSecondary,
        };
        DockPanel.SetDock(volVal, System.Windows.Controls.Dock.Right);
        volHead.Children.Add(volVal);
        volHead.Children.Add(new TextBlock { Text = "Master Audio Output", FontSize = 11, FontWeight = FontWeights.Medium, Foreground = ThemeManager.TextPrimary });
        volPanel.Children.Add(volHead);

        var sliderRow = new DockPanel { Margin = new Thickness(0, 6, 0, 0) };
        var muteBtn = ThemeManager.CreateIconButton(status.IsMuted ? "volumeMute" : "volume", "Toggle mute", 26, 13.5);
        muteBtn.Click += (_, _) => { SystemStatusService.ToggleMute(); RebuildContent(); };
        sliderRow.Children.Add(muteBtn);

        var slider = new Slider
        {
            Minimum = 0,
            Maximum = 100,
            Value = status.VolumePercent,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(8, 0, 0, 0),
        };
        slider.ValueChanged += (_, e) =>
        {
            var pct = (int)Math.Round(e.NewValue);
            SystemStatusService.SetMasterVolume(pct);
            volVal.Text = $"{pct}%";
        };
        sliderRow.Children.Add(slider);
        volPanel.Children.Add(sliderRow);
        root.Children.Add(volPanel);

        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        // Status & native Windows flyout openers
        var statusStack = new StackPanel { Margin = new Thickness(12, 8, 12, 8) };
        statusStack.Children.Add(new TextBlock
        {
            Text = $"Network: {status.NetworkDescription}",
            FontSize = 11,
            Foreground = ThemeManager.TextSecondary,
            Margin = new Thickness(0, 0, 0, 3),
        });
        var powerText = status.BatteryPercent is not null
            ? $"Battery: {status.BatteryPercent}% ({(status.IsCharging ? "Charging" : status.OnAcPower ? "Plugged in" : "On battery")})"
            : "Power: AC Desktop Power";
        statusStack.Children.Add(new TextBlock
        {
            Text = powerText,
            FontSize = 11,
            Foreground = ThemeManager.TextSecondary,
            Margin = new Thickness(0, 0, 0, 6),
        });

        var quickWrap = new WrapPanel();
        foreach (var (lbl, uri) in new[]
                 {
                     ("Sound", "ms-settings:sound"),
                     ("Network", "ms-settings:network-status"),
                     ("Power", "ms-settings:powersleep"),
                     ("Taskbar & Tray", "ms-settings:taskbar"),
                 })
        {
            var captured = uri;
            var b = ThemeManager.CreateButton(lbl, "external", height: 24);
            b.Margin = new Thickness(0, 0, 5, 4);
            b.Click += (_, _) => { ShellLauncher.Open(captured, null, _log); Hide(); };
            quickWrap.Children.Add(b);
        }
        statusStack.Children.Add(quickWrap);
        root.Children.Add(statusStack);

        // Active tray/background items
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        root.Children.Add(new TextBlock
        {
            Text = "ACTIVE SESSION & TRAY PROCESSES",
            FontSize = 9.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextTertiary,
            Margin = new Thickness(12, 8, 12, 4),
        });

        var appWrap = new StackPanel { Margin = new Thickness(10, 0, 10, 6) };
        foreach (var app in apps.Take(7))
        {
            var captured = app;
            var row = new DockPanel { Height = 28, Margin = new Thickness(2, 1, 2, 1), Cursor = Cursors.Hand };
            if (captured.Icon is not null)
            {
                row.Children.Add(new Image { Source = captured.Icon, Width = 16, Height = 16, Margin = new Thickness(4, 0, 8, 0) });
            }
            row.Children.Add(new TextBlock
            {
                Text = captured.Name,
                FontSize = 11.5,
                Foreground = ThemeManager.TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
            });
            var rowBorder = new Border { CornerRadius = new CornerRadius(4), Background = Brushes.Transparent, Child = row };
            rowBorder.MouseEnter += (_, _) => rowBorder.Background = ThemeManager.HoverBrush;
            rowBorder.MouseLeave += (_, _) => rowBorder.Background = Brushes.Transparent;
            rowBorder.MouseLeftButtonUp += (_, _) =>
            {
                SystemTrayMirrorService.ActivateOrLaunch(captured, _log);
                Hide();
            };
            appWrap.Children.Add(rowBorder);
        }
        root.Children.Add(new ScrollViewer { MaxHeight = 165, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = appWrap });

        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        root.Children.Add(new TextBlock
        {
            Text = "Windows 11 25H2 isolates third-party Shell_NotifyIcon context menus inside Explorer's XAML Island; Unified Shell avoids DLL injection and leaves the native tray active.",
            FontSize = 9.5,
            Foreground = ThemeManager.TextTertiary,
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(12, 6, 12, 8),
        });

        Content = ThemeManager.CreatePanelShell(root);
    }
}

public sealed class AddDockItemPopup : DockPopoverWindow
{
    private readonly ConfigStore _store;
    private readonly AppIndexer _indexer;
    private string _filter = string.Empty;

    public AddDockItemPopup(ConfigStore store, AppIndexer indexer) : base("add", 348)
    {
        _store = store;
        _indexer = indexer;
    }

    protected override void RebuildContent()
    {
        var root = new StackPanel();
        root.Children.Add(CreateHeader("plus", "Add to Dock", "Pin installed apps or custom shortcuts"));
        root.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        var customRow = new UniformGrid { Columns = 2, Margin = new Thickness(10, 8, 10, 6) };
        var addExe = ThemeManager.CreateButton("Custom App (.exe)…", "plus", height: 27);
        addExe.Margin = new Thickness(0, 0, 3, 0);
        addExe.Click += (_, _) => BrowseForExecutable();

        var addFolder = ThemeManager.CreateButton("Folder Shortcut…", "folder", height: 27);
        addFolder.Margin = new Thickness(3, 0, 0, 0);
        addFolder.Click += (_, _) => BrowseForFolder();

        customRow.Children.Add(addExe);
        customRow.Children.Add(addFolder);
        root.Children.Add(customRow);

        var filterBox = ThemeManager.CreateTextBox("Filter installed applications…", height: 27);
        filterBox.Margin = new Thickness(10, 0, 10, 6);
        filterBox.Text = _filter;
        filterBox.TextChanged += (_, _) =>
        {
            _filter = filterBox.Text;
            RebuildContent();
        };
        root.Children.Add(filterBox);

        var list = new StackPanel { Margin = new Thickness(8, 0, 8, 8) };
        var apps = _indexer.Snapshot()
            .Where(a => string.IsNullOrWhiteSpace(_filter) || a.Name.Contains(_filter, StringComparison.OrdinalIgnoreCase))
            .Take(40);

        foreach (var app in apps)
        {
            var captured = app;
            var alreadyPinned = _store.Current.PinnedItems.Any(p => p.Target.Equals(captured.TargetPath, StringComparison.OrdinalIgnoreCase));

            var dp = new DockPanel { Height = 32, Margin = new Thickness(4, 1, 4, 1) };
            var pinBtn = ThemeManager.CreateButton(alreadyPinned ? "Pinned" : "Pin", alreadyPinned ? "check" : "plus", primary: !alreadyPinned, height: 23);
            pinBtn.Click += (_, _) =>
            {
                if (alreadyPinned)
                {
                    _store.Current.PinnedItems.RemoveAll(p => p.Target.Equals(captured.TargetPath, StringComparison.OrdinalIgnoreCase));
                }
                else
                {
                    _store.Current.PinnedItems.Add(new DockShortcutItem
                    {
                        Label = captured.Name,
                        Target = captured.TargetPath,
                        Kind = "app",
                    });
                }
                _store.Save();
                RebuildContent();
            };
            DockPanel.SetDock(pinBtn, System.Windows.Controls.Dock.Right);
            dp.Children.Add(pinBtn);

            var ico = captured.GetIcon();
            if (ico is not null)
            {
                dp.Children.Add(new Image { Source = ico, Width = 18, Height = 18, Margin = new Thickness(0, 0, 8, 0) });
            }
            dp.Children.Add(new TextBlock
            {
                Text = captured.Name,
                FontSize = 11.5,
                Foreground = ThemeManager.TextPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
            });
            list.Children.Add(dp);
        }

        root.Children.Add(new ScrollViewer { MaxHeight = 250, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = list });
        Content = ThemeManager.CreatePanelShell(root);
    }

    private void BrowseForExecutable()
    {
        var dlg = new OpenFileDialog
        {
            Title = "Choose Application or Shortcut",
            Filter = "Programs & Shortcuts (*.exe;*.lnk;*.bat;*.cmd)|*.exe;*.lnk;*.bat;*.cmd|All files (*.*)|*.*",
        };
        if (dlg.ShowDialog(this) != true) return;
        _store.Current.PinnedItems.Add(new DockShortcutItem
        {
            Label = Path.GetFileNameWithoutExtension(dlg.FileName),
            Target = dlg.FileName,
            Kind = "app",
        });
        _store.Save();
        RebuildContent();
    }

    private void BrowseForFolder()
    {
        var dlg = new OpenFolderDialog { Title = "Choose Folder Shortcut" };
        if (dlg.ShowDialog(this) != true) return;
        var name = Path.GetFileName(dlg.FolderName.TrimEnd(Path.DirectorySeparatorChar));
        _store.Current.PinnedItems.Add(new DockShortcutItem
        {
            Label = string.IsNullOrWhiteSpace(name) ? dlg.FolderName : name,
            Target = dlg.FolderName,
            Kind = "folder",
            IconGlyph = "folder",
        });
        _store.Save();
        RebuildContent();
    }
}
