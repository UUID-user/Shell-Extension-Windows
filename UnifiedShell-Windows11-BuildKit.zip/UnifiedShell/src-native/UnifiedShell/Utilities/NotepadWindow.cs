using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Themes;

namespace UnifiedShell.Utilities;

/// <summary>
/// Custom, lightweight Markdown notepad integrated into Unified Shell.
/// Supports plain-text editing, Markdown preview with fenced code block syntax highlighting,
/// Open / Save / Save As, keyboard shortcuts, and automatic draft recovery.
/// </summary>
public sealed class NotepadWindow : Window
{
    private readonly AppPaths _paths;
    private readonly ConfigStore _store;
    private readonly AppLog _log;
    private readonly DispatcherTimer _autosaveTimer;

    private TextBox _editor = null!;
    private FlowDocumentScrollViewer _preview = null!;
    private TextBlock _fileLabel = null!;
    private TextBlock _statusLabel = null!;
    private ColumnDefinition _editCol = null!;
    private ColumnDefinition _previewCol = null!;
    private Border _splitDivider = null!;

    private string? _currentFilePath;
    private bool _dirty;
    private string _viewMode = "split"; // "edit" | "split" | "preview"
    private bool _loading;

    private static readonly Regex KeywordRegex = new(
        @"\b(using|namespace|class|struct|record|interface|public|private|internal|protected|static|readonly|sealed|void|int|string|bool|double|var|const|let|function|return|if|else|for|foreach|while|async|await|try|catch|finally|new|true|false|null)\b",
        RegexOptions.Compiled);

    public NotepadWindow(AppPaths paths, ConfigStore store, AppLog log)
    {
        _paths = paths;
        _store = store;
        _log = log;

        Title = "Unified Shell Notepad";
        Width = 720;
        Height = 520;
        MinWidth = 440;
        MinHeight = 320;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.CanResizeWithGrip;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        Topmost = true;
        ShowInTaskbar = true;

        _autosaveTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(950) };
        _autosaveTimer.Tick += (_, _) =>
        {
            _autosaveTimer.Stop();
            PerformAutosave();
        };

        BuildLayout();
        LoadInitialDraft();
        PreviewKeyDown += OnKeyDown;
        Closing += OnWindowClosing;
        ThemeManager.ThemeChanged += () =>
        {
            var text = _editor?.Text ?? string.Empty;
            BuildLayout();
            _loading = true;
            _editor!.Text = text;
            _loading = false;
            UpdateHeaderAndPreview();
        };
    }

    public void ToggleOrFocus()
    {
        if (IsVisible)
        {
            Hide();
            return;
        }
        var mon = DisplayManager.Resolve(_store.Current.DockMonitor);
        if (Left == 0 && Top == 0)
        {
            Left = mon.WorkDipLeft + (mon.WorkDipWidth - Width) / 2;
            Top = mon.WorkDipTop + Math.Max(54, (mon.WorkDipHeight - Height) / 3);
        }
        Show();
        NativeMethods.ApplyWindowChrome(this, ThemeManager.IsDark, toolWindow: false, roundCorners: true);
        Activate();
        _editor.Focus();
    }

    private void BuildLayout()
    {
        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(36) });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(36) });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });

        // 1. Frameless title bar (draggable)
        var titleBar = new DockPanel { Background = ThemeManager.SurfaceSubtle };
        titleBar.MouseLeftButtonDown += (_, e) => { if (e.ButtonState == MouseButtonState.Pressed) DragMove(); };

        var closeBtn = ThemeManager.CreateIconButton("close", "Close notepad", 30, 12.5);
        closeBtn.Margin = new Thickness(0, 0, 4, 0);
        closeBtn.Click += (_, _) => Hide();
        DockPanel.SetDock(closeBtn, System.Windows.Controls.Dock.Right);
        titleBar.Children.Add(closeBtn);

        var titleLeft = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(12, 0, 0, 0) };
        titleLeft.Children.Add(VectorIcons.Create("notes", 14, ThemeManager.AccentBrush));
        _fileLabel = new TextBlock
        {
            Text = "autosave.md",
            FontFamily = ThemeManager.UiFont,
            FontSize = 12,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            Margin = new Thickness(8, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Center,
        };
        titleLeft.Children.Add(_fileLabel);
        titleBar.Children.Add(titleLeft);
        Grid.SetRow(titleBar, 0);
        root.Children.Add(titleBar);

        // 2. Minimal file & view bar (no bloated formatting toolbar)
        var bar = new DockPanel
        {
            Margin = new Thickness(10, 4, 10, 4),
        };
        var leftBtns = new StackPanel { Orientation = Orientation.Horizontal };
        var newBtn = ThemeManager.CreateButton("New", null, subtle: true, height: 26);
        newBtn.Click += (_, _) => NewDocument();
        var openBtn = ThemeManager.CreateButton("Open", "folder", subtle: true, height: 26);
        openBtn.Click += (_, _) => OpenDocument();
        var saveBtn = ThemeManager.CreateButton("Save", "save", subtle: true, height: 26);
        saveBtn.Click += (_, _) => SaveDocument(saveAs: false);
        var saveAsBtn = ThemeManager.CreateButton("Save As", "download", subtle: true, height: 26);
        saveAsBtn.Click += (_, _) => SaveDocument(saveAs: true);

        leftBtns.Children.Add(newBtn);
        leftBtns.Children.Add(openBtn);
        leftBtns.Children.Add(saveBtn);
        leftBtns.Children.Add(saveAsBtn);

        var modeBtns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        foreach (var (id, label) in new[] { ("edit", "Edit"), ("split", "Split"), ("preview", "Preview") })
        {
            var captured = id;
            var b = ThemeManager.CreateButton(label, null, primary: _viewMode == captured, subtle: _viewMode != captured, height: 24);
            b.Margin = new Thickness(2, 0, 0, 0);
            b.Click += (_, _) => SetViewMode(captured);
            modeBtns.Children.Add(b);
        }
        DockPanel.SetDock(modeBtns, System.Windows.Controls.Dock.Right);
        bar.Children.Add(modeBtns);
        bar.Children.Add(leftBtns);
        Grid.SetRow(bar, 1);
        root.Children.Add(bar);

        // 3. Split editor + Markdown preview
        var body = new Grid { Margin = new Thickness(0, 2, 0, 0) };
        _editCol = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
        var divCol = new ColumnDefinition { Width = GridLength.Auto };
        _previewCol = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
        body.ColumnDefinitions.Add(_editCol);
        body.ColumnDefinitions.Add(divCol);
        body.ColumnDefinitions.Add(_previewCol);

        _editor = new TextBox
        {
            AcceptsReturn = true,
            AcceptsTab = true,
            TextWrapping = TextWrapping.Wrap,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Background = ThemeManager.SunkenBackground,
            Foreground = ThemeManager.TextPrimary,
            CaretBrush = ThemeManager.AccentBrush,
            BorderThickness = new Thickness(0, 1, 0, 1),
            BorderBrush = ThemeManager.BorderSubtle,
            Padding = new Thickness(12, 10, 12, 10),
            FontFamily = ThemeManager.MonoFont,
            FontSize = 12.5,
        };
        _editor.TextChanged += (_, _) =>
        {
            if (_loading) return;
            _dirty = true;
            UpdateHeaderAndPreview();
            if (_store.Current.NotepadAutosave)
            {
                _autosaveTimer.Stop();
                _autosaveTimer.Start();
            }
        };
        Grid.SetColumn(_editor, 0);
        body.Children.Add(_editor);

        _splitDivider = new Border { Width = 1, Background = ThemeManager.BorderSubtle };
        Grid.SetColumn(_splitDivider, 1);
        body.Children.Add(_splitDivider);

        _preview = new FlowDocumentScrollViewer
        {
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Background = Brushes.Transparent,
            BorderThickness = new Thickness(0, 1, 0, 1),
            BorderBrush = ThemeManager.BorderSubtle,
            IsToolBarVisible = false,
            Document = new FlowDocument(),
        };
        Grid.SetColumn(_preview, 2);
        body.Children.Add(_preview);

        Grid.SetRow(body, 2);
        root.Children.Add(body);

        // 4. Status bar
        var status = new DockPanel { Margin = new Thickness(12, 0, 12, 0), VerticalAlignment = VerticalAlignment.Center };
        _statusLabel = new TextBlock
        {
            FontSize = 10.5,
            Foreground = ThemeManager.TextTertiary,
            VerticalAlignment = VerticalAlignment.Center,
        };
        status.Children.Add(_statusLabel);
        status.Children.Add(new TextBlock
        {
            Text = "Ctrl+S Save  ·  Ctrl+O Open  ·  Ctrl+N New",
            FontSize = 10.5,
            Foreground = ThemeManager.TextTertiary,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
        });
        Grid.SetRow(status, 3);
        root.Children.Add(status);

        Content = ThemeManager.CreatePanelShell(root, cornerRadius: 10);
        ApplyViewColumns();
    }

    private void SetViewMode(string mode)
    {
        _viewMode = mode;
        var text = _editor.Text;
        BuildLayout();
        _loading = true;
        _editor.Text = text;
        _loading = false;
        UpdateHeaderAndPreview();
    }

    private void ApplyViewColumns()
    {
        _editCol.Width = _viewMode == "preview" ? new GridLength(0) : new GridLength(1, GridUnitType.Star);
        _previewCol.Width = _viewMode == "edit" ? new GridLength(0) : new GridLength(1, GridUnitType.Star);
        _splitDivider.Visibility = _viewMode == "split" ? Visibility.Visible : Visibility.Collapsed;
    }

    private void LoadInitialDraft()
    {
        _loading = true;
        try
        {
            var lastPath = _store.Current.LastNotepadFilePath;
            if (!string.IsNullOrWhiteSpace(lastPath) && File.Exists(lastPath))
            {
                _currentFilePath = lastPath;
                _editor.Text = File.ReadAllText(lastPath, Encoding.UTF8);
            }
            else if (File.Exists(_paths.AutosaveNoteFile))
            {
                _editor.Text = File.ReadAllText(_paths.AutosaveNoteFile, Encoding.UTF8);
            }
            else
            {
                _editor.Text = DefaultStarterMarkdown;
                File.WriteAllText(_paths.AutosaveNoteFile, _editor.Text, Encoding.UTF8);
            }
            _dirty = false;
        }
        catch (Exception ex)
        {
            _log.Warn($"Notepad initial load fallback: {ex.Message}");
            _editor.Text = DefaultStarterMarkdown;
        }
        finally
        {
            _loading = false;
            UpdateHeaderAndPreview();
        }
    }

    private void PerformAutosave()
    {
        try
        {
            File.WriteAllText(_paths.AutosaveNoteFile, _editor.Text, Encoding.UTF8);
            if (_currentFilePath is not null && File.Exists(_currentFilePath))
            {
                File.WriteAllText(_currentFilePath, _editor.Text, Encoding.UTF8);
            }
            _dirty = false;
            UpdateStatusText(savedJustNow: true);
        }
        catch (Exception ex)
        {
            _log.Warn($"Notepad autosave failed: {ex.Message}");
        }
    }

    private void NewDocument()
    {
        PerformAutosave();
        _currentFilePath = null;
        _store.Current.LastNotepadFilePath = null;
        _store.Save(raiseEvent: false);
        _loading = true;
        _editor.Text = "# Untitled Note\n\n";
        _loading = false;
        _dirty = true;
        UpdateHeaderAndPreview();
        _editor.Focus();
        _editor.CaretIndex = _editor.Text.Length;
    }

    private void OpenDocument()
    {
        var dlg = new OpenFileDialog
        {
            Title = "Open Markdown or Text File",
            Filter = "Markdown & Text (*.md;*.markdown;*.txt;*.log;*.json;*.cs;*.ps1)|*.md;*.markdown;*.txt;*.log;*.json;*.cs;*.ps1|All files (*.*)|*.*",
        };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            _loading = true;
            _editor.Text = File.ReadAllText(dlg.FileName, Encoding.UTF8);
            _currentFilePath = dlg.FileName;
            _store.Current.LastNotepadFilePath = dlg.FileName;
            _store.Save(raiseEvent: false);
            _dirty = false;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"Could not open file:\n{ex.Message}", "Unified Shell Notepad", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            _loading = false;
            UpdateHeaderAndPreview();
        }
    }

    private void SaveDocument(bool saveAs)
    {
        var path = _currentFilePath;
        if (saveAs || string.IsNullOrWhiteSpace(path))
        {
            var dlg = new SaveFileDialog
            {
                Title = "Save Markdown Note",
                FileName = path is not null ? Path.GetFileName(path) : "note.md",
                DefaultExt = ".md",
                Filter = "Markdown (*.md)|*.md|Plain Text (*.txt)|*.txt|All files (*.*)|*.*",
            };
            if (dlg.ShowDialog(this) != true) return;
            path = dlg.FileName;
        }

        try
        {
            File.WriteAllText(path, _editor.Text, Encoding.UTF8);
            File.WriteAllText(_paths.AutosaveNoteFile, _editor.Text, Encoding.UTF8);
            _currentFilePath = path;
            _store.Current.LastNotepadFilePath = path;
            _store.Save(raiseEvent: false);
            _dirty = false;
            UpdateHeaderAndPreview();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, $"Could not save file:\n{ex.Message}", "Unified Shell Notepad", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void UpdateHeaderAndPreview()
    {
        var displayName = _currentFilePath is not null ? Path.GetFileName(_currentFilePath) : "Draft (autosave.md)";
        _fileLabel.Text = _dirty ? $"{displayName} •" : displayName;
        UpdateStatusText(savedJustNow: false);
        if (_viewMode != "edit")
        {
            _preview.Document = RenderMarkdown(_editor.Text);
        }
    }

    private void UpdateStatusText(bool savedJustNow)
    {
        var text = _editor?.Text ?? string.Empty;
        var lines = string.IsNullOrEmpty(text) ? 1 : text.Split('\n').Length;
        var words = string.IsNullOrWhiteSpace(text) ? 0 : Regex.Matches(text, @"\S+").Count;
        var state = savedJustNow ? "Saved" : _dirty ? (_store.Current.NotepadAutosave ? "Autosaving…" : "Unsaved") : "Saved locally";
        _statusLabel.Text = $"{words} words  ·  {lines} lines  ·  {text.Length} chars  ·  {state}";
    }

    private static FlowDocument RenderMarkdown(string source)
    {
        var doc = new FlowDocument
        {
            FontFamily = ThemeManager.UiFont,
            FontSize = 12.5,
            Foreground = ThemeManager.TextPrimary,
            PagePadding = new Thickness(14, 10, 14, 12),
        };

        var lines = source.Replace("\r\n", "\n").Split('\n');
        int i = 0;
        while (i < lines.Length)
        {
            var line = lines[i];
            var trimmed = line.Trim();

            if (string.IsNullOrEmpty(trimmed))
            {
                i++;
                continue;
            }

            // Fenced code block with syntax highlighting
            if (trimmed.StartsWith("```", StringComparison.Ordinal))
            {
                var lang = trimmed[3..].Trim();
                var codeLines = new StringBuilder();
                i++;
                while (i < lines.Length && !lines[i].Trim().StartsWith("```", StringComparison.Ordinal))
                {
                    codeLines.AppendLine(lines[i]);
                    i++;
                }
                i++;

                var codePara = new Paragraph
                {
                    FontFamily = ThemeManager.MonoFont,
                    FontSize = 11.5,
                    Background = ThemeManager.SunkenBackground,
                    BorderBrush = ThemeManager.BorderSubtle,
                    BorderThickness = new Thickness(1),
                    Padding = new Thickness(10, 8, 10, 8),
                    Margin = new Thickness(0, 0, 0, 10),
                };
                if (!string.IsNullOrEmpty(lang))
                {
                    codePara.Inlines.Add(new Run($"[{lang}]\n") { Foreground = ThemeManager.TextTertiary, FontSize = 10 });
                }
                AppendHighlightedCode(codePara.Inlines, codeLines.ToString().TrimEnd('\r', '\n'));
                doc.Blocks.Add(codePara);
                continue;
            }

            if (trimmed.StartsWith("# ", StringComparison.Ordinal))
            {
                doc.Blocks.Add(new Paragraph(BuildInline(trimmed[2..]))
                {
                    FontFamily = ThemeManager.DisplayFont,
                    FontSize = 18.5,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(0, 4, 0, 8),
                });
                i++;
                continue;
            }
            if (trimmed.StartsWith("## ", StringComparison.Ordinal))
            {
                doc.Blocks.Add(new Paragraph(BuildInline(trimmed[3..]))
                {
                    FontFamily = ThemeManager.DisplayFont,
                    FontSize = 15,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(0, 8, 0, 6),
                });
                i++;
                continue;
            }
            if (trimmed.StartsWith("### ", StringComparison.Ordinal))
            {
                doc.Blocks.Add(new Paragraph(BuildInline(trimmed[4..]))
                {
                    FontFamily = ThemeManager.DisplayFont,
                    FontSize = 13.5,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(0, 6, 0, 4),
                });
                i++;
                continue;
            }

            if (trimmed.StartsWith("> ", StringComparison.Ordinal))
            {
                doc.Blocks.Add(new Paragraph(BuildInline(trimmed[2..]))
                {
                    Foreground = ThemeManager.TextSecondary,
                    BorderBrush = ThemeManager.AccentBrush,
                    BorderThickness = new Thickness(2, 0, 0, 0),
                    Padding = new Thickness(10, 2, 0, 2),
                    Margin = new Thickness(0, 0, 0, 8),
                });
                i++;
                continue;
            }

            if (trimmed is "---" or "***")
            {
                doc.Blocks.Add(new Paragraph
                {
                    BorderBrush = ThemeManager.BorderSubtle,
                    BorderThickness = new Thickness(0, 1, 0, 0),
                    Margin = new Thickness(0, 8, 0, 8),
                });
                i++;
                continue;
            }

            if (trimmed.StartsWith("- ", StringComparison.Ordinal) || trimmed.StartsWith("* ", StringComparison.Ordinal))
            {
                var list = new List { MarkerStyle = TextMarkerStyle.Disc, Padding = new Thickness(18, 0, 0, 0), Margin = new Thickness(0, 0, 0, 8) };
                while (i < lines.Length)
                {
                    var t = lines[i].Trim();
                    if (!t.StartsWith("- ", StringComparison.Ordinal) && !t.StartsWith("* ", StringComparison.Ordinal)) break;
                    var itemText = t[2..].Trim();
                    if (itemText.StartsWith("[x] ", StringComparison.OrdinalIgnoreCase)) itemText = "☑ " + itemText[4..];
                    else if (itemText.StartsWith("[ ] ", StringComparison.Ordinal)) itemText = "☐ " + itemText[4..];
                    list.ListItems.Add(new ListItem(new Paragraph(BuildInline(itemText)) { Margin = new Thickness(0, 1, 0, 2) }));
                    i++;
                }
                doc.Blocks.Add(list);
                continue;
            }

            doc.Blocks.Add(new Paragraph(BuildInline(trimmed)) { Margin = new Thickness(0, 0, 0, 8), LineHeight = 19 });
            i++;
        }

        return doc;
    }

    private static Span BuildInline(string text)
    {
        var span = new Span();
        var tokens = Regex.Split(text, @"(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)");
        foreach (var tok in tokens)
        {
            if (string.IsNullOrEmpty(tok)) continue;
            if (tok.StartsWith('`') && tok.EndsWith('`') && tok.Length > 2)
            {
                span.Inlines.Add(new Run(tok[1..^1])
                {
                    FontFamily = ThemeManager.MonoFont,
                    FontSize = 11.5,
                    Background = ThemeManager.HoverBrush,
                });
            }
            else if (tok.StartsWith("**", StringComparison.Ordinal) && tok.EndsWith("**", StringComparison.Ordinal) && tok.Length > 4)
            {
                span.Inlines.Add(new Bold(new Run(tok[2..^2])));
            }
            else if (tok.StartsWith('*') && tok.EndsWith('*') && tok.Length > 2)
            {
                span.Inlines.Add(new Italic(new Run(tok[1..^1])));
            }
            else
            {
                span.Inlines.Add(new Run(tok));
            }
        }
        return span;
    }

    private static void AppendHighlightedCode(InlineCollection inlines, string code)
    {
        var lines = code.Split('\n');
        for (int idx = 0; idx < lines.Length; idx++)
        {
            var ln = lines[idx];
            var commentIdx = ln.IndexOf("//", StringComparison.Ordinal);
            var codePart = commentIdx >= 0 ? ln[..commentIdx] : ln;
            var commentPart = commentIdx >= 0 ? ln[commentIdx..] : null;

            int pos = 0;
            foreach (Match m in KeywordRegex.Matches(codePart))
            {
                if (m.Index > pos) inlines.Add(new Run(codePart[pos..m.Index]) { Foreground = ThemeManager.TextPrimary });
                inlines.Add(new Run(m.Value) { Foreground = ThemeManager.AccentBrush, FontWeight = FontWeights.Medium });
                pos = m.Index + m.Length;
            }
            if (pos < codePart.Length) inlines.Add(new Run(codePart[pos..]) { Foreground = ThemeManager.TextPrimary });
            if (commentPart is not null) inlines.Add(new Run(commentPart) { Foreground = ThemeManager.TextTertiary });
            if (idx < lines.Length - 1) inlines.Add(new LineBreak());
        }
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            e.Handled = true;
            Hide();
            return;
        }
        if ((Keyboard.Modifiers & ModifierKeys.Control) == 0) return;

        if (e.Key == Key.S)
        {
            e.Handled = true;
            SaveDocument(saveAs: (Keyboard.Modifiers & ModifierKeys.Shift) != 0);
        }
        else if (e.Key == Key.O)
        {
            e.Handled = true;
            OpenDocument();
        }
        else if (e.Key == Key.N)
        {
            e.Handled = true;
            NewDocument();
        }
    }

    private void OnWindowClosing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        PerformAutosave();
        if (_store.Current.MinimiseToBackground)
        {
            e.Cancel = true;
            Hide();
        }
    }

    private const string DefaultStarterMarkdown = """
        # Quick Notes

        Lightweight Markdown scratchpad built into **Unified Shell**.
        Drafts autosave locally without cloud sync or background bloat.

        ## Tasks
        - [x] Verify top dock & Explorer coexistence
        - [ ] Press `Alt + Space` to open universal search
        - [ ] Save important notes with `Ctrl + S`

        ```csharp
        public static bool IsLightweight(long workingSetBytes)
        {
            // Target idle memory: under 150 MB
            return workingSetBytes < 150L * 1024 * 1024;
        }
        ```
        """;
}
