using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;

namespace UnifiedShell.Search;

public static class FuzzyMatcher
{
    public static int? Score(string query, string candidate)
    {
        if (string.IsNullOrWhiteSpace(query)) return 0;
        if (string.IsNullOrEmpty(candidate)) return null;

        var q = query.Trim();
        var direct = candidate.IndexOf(q, StringComparison.OrdinalIgnoreCase);
        if (direct == 0) return 140 - Math.Min(25, candidate.Length - q.Length);
        if (direct > 0)
        {
            var prev = candidate[direct - 1];
            var wordStart = prev is ' ' or '-' or '_' or '.' or '\\' or '/';
            return (wordStart ? 110 : 84) - Math.Min(18, direct);
        }

        int score = 42;
        int ci = 0;
        int lastMatch = -2;
        for (int qi = 0; qi < q.Length; qi++)
        {
            char qc = char.ToLowerInvariant(q[qi]);
            int found = -1;
            for (int i = ci; i < candidate.Length; i++)
            {
                if (char.ToLowerInvariant(candidate[i]) == qc)
                {
                    found = i;
                    break;
                }
            }
            if (found < 0) return null;
            if (found == lastMatch + 1) score += 6;
            if (found == 0 || candidate[found - 1] is ' ' or '-' or '_' or '\\' or '/') score += 5;
            score -= Math.Min(4, found - ci);
            lastMatch = found;
            ci = found + 1;
        }
        return Math.Max(1, score);
    }

    public static int? Best(string query, params string?[] fields)
    {
        int? best = null;
        foreach (var field in fields)
        {
            if (string.IsNullOrEmpty(field)) continue;
            var s = Score(query, field);
            if (s is not null && (best is null || s > best)) best = s;
        }
        return best;
    }
}

public sealed class InstalledAppEntry
{
    public required string Name { get; init; }
    public required string TargetPath { get; init; }
    public required string Category { get; init; }
    private ImageSource? _cachedIcon;
    private bool _iconProbed;

    public ImageSource? GetIcon()
    {
        if (_iconProbed) return _cachedIcon;
        _iconProbed = true;
        _cachedIcon = NativeMethods.ExtractShellIcon(TargetPath);
        return _cachedIcon;
    }
}

/// <summary>
/// Discovers installed applications from the user and system Start Menu folders.
/// Indexes paths asynchronously once and caches shell icons lazily on render.
/// </summary>
public sealed class AppIndexer
{
    private readonly AppLog _log;
    private List<InstalledAppEntry> _apps = new();
    private readonly object _gate = new();

    public AppIndexer(AppLog log)
    {
        _log = log;
    }

    public IReadOnlyList<InstalledAppEntry> Snapshot()
    {
        lock (_gate) return _apps;
    }

    public void RefreshAsync()
    {
        _ = Task.Run(() =>
        {
            try
            {
                var found = new Dictionary<string, InstalledAppEntry>(StringComparer.OrdinalIgnoreCase);
                var roots = new[]
                {
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms),
                    Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                };

                foreach (var root in roots)
                {
                    if (string.IsNullOrWhiteSpace(root) || !Directory.Exists(root)) continue;
                    foreach (var file in Directory.EnumerateFiles(root, "*.*", SearchOption.AllDirectories))
                    {
                        var ext = Path.GetExtension(file);
                        if (!ext.Equals(".lnk", StringComparison.OrdinalIgnoreCase) &&
                            !ext.Equals(".appref-ms", StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        var name = Path.GetFileNameWithoutExtension(file);
                        if (string.IsNullOrWhiteSpace(name)) continue;
                        if (name.Contains("uninstall", StringComparison.OrdinalIgnoreCase)) continue;

                        var parent = Path.GetFileName(Path.GetDirectoryName(file)) ?? "Applications";
                        if (parent.Equals("Programs", StringComparison.OrdinalIgnoreCase)) parent = "Application";

                        found.TryAdd(name, new InstalledAppEntry
                        {
                            Name = name,
                            TargetPath = file,
                            Category = parent,
                        });
                    }
                }

                // Ensure core Windows tools are always discoverable even if hidden from Start Menu folders.
                AddBuiltIn(found, "File Explorer", "explorer.exe", "System");
                AddBuiltIn(found, "Windows Terminal", "wt.exe", "System");
                AddBuiltIn(found, "Task Manager", "taskmgr.exe", "System");
                AddBuiltIn(found, "PowerShell", "powershell.exe", "System");
                AddBuiltIn(found, "Command Prompt", "cmd.exe", "System");
                AddBuiltIn(found, "Control Panel", "control.exe", "System");
                AddBuiltIn(found, "Resource Monitor", "resmon.exe", "System");

                var ordered = found.Values.OrderBy(a => a.Name, StringComparer.OrdinalIgnoreCase).ToList();
                lock (_gate) _apps = ordered;
                _log.Info($"Indexed {ordered.Count} installed applications");
            }
            catch (Exception ex)
            {
                _log.Error("Application indexing failed", ex);
            }
        });
    }

    private static void AddBuiltIn(Dictionary<string, InstalledAppEntry> map, string name, string exe, string category)
    {
        map.TryAdd(name, new InstalledAppEntry { Name = name, TargetPath = exe, Category = category });
    }
}

public sealed record WindowsSettingEntry(string Name, string Uri, string Group, string Keywords);

public static class WindowsSettingsIndex
{
    public static readonly IReadOnlyList<WindowsSettingEntry> All = new List<WindowsSettingEntry>
    {
        new("Display", "ms-settings:display", "System", "resolution scaling hdr monitors brightness"),
        new("Night light", "ms-settings:nightlight", "System", "blue light warm colour comfort"),
        new("Sound", "ms-settings:sound", "System", "audio output input volume speakers microphone"),
        new("Notifications", "ms-settings:notifications", "System", "alerts banner focus do not disturb"),
        new("Power & battery", "ms-settings:powersleep", "System", "battery power sleep energy lid"),
        new("Storage", "ms-settings:storagesense", "System", "disk space cleanup storage sense"),
        new("Multitasking", "ms-settings:multitasking", "System", "snap layouts virtual desktops alt tab"),
        new("Clipboard", "ms-settings:clipboard", "System", "clipboard history sync copy paste"),
        new("About this PC", "ms-settings:about", "System", "specs processor ram windows version"),
        new("Bluetooth & devices", "ms-settings:bluetooth", "Bluetooth & devices", "bluetooth mouse keyboard headphones"),
        new("Printers & scanners", "ms-settings:printers", "Bluetooth & devices", "printer scanner"),
        new("Network & internet", "ms-settings:network-status", "Network & internet", "wifi ethernet vpn proxy ip"),
        new("Wi-Fi", "ms-settings:network-wifi", "Network & internet", "wireless wifi ssid"),
        new("Personalisation", "ms-settings:personalization", "Personalisation", "theme background colours"),
        new("Background", "ms-settings:personalization-background", "Personalisation", "wallpaper desktop picture"),
        new("Colours", "ms-settings:colors", "Personalisation", "accent dark mode light mode transparency"),
        new("Taskbar", "ms-settings:taskbar", "Personalisation", "taskbar system tray alignment"),
        new("Installed apps", "ms-settings:appsfeatures", "Apps", "uninstall applications programs"),
        new("Default apps", "ms-settings:defaultapps", "Apps", "default browser file associations"),
        new("Startup apps", "ms-settings:startupapps", "Apps", "startup boot sign in"),
        new("Date & time", "ms-settings:dateandtime", "Time & language", "clock timezone ntp"),
        new("Language & region", "ms-settings:regionformatting", "Time & language", "locale keyboard language"),
        new("Accessibility", "ms-settings:easeofaccess", "Accessibility", "contrast text size narrator"),
        new("Developer settings", "ms-settings:developers", "System", "developer mode terminal"),
        new("Windows Update", "ms-settings:windowsupdate", "Windows Update", "updates patches security"),
    };
}

public sealed record EverythingFileHit(string FullPath, bool IsDirectory)
{
    public string Name => Path.GetFileName(FullPath.TrimEnd(Path.DirectorySeparatorChar)) is { Length: > 0 } n ? n : FullPath;
    public string DirectoryName => Path.GetDirectoryName(FullPath) ?? FullPath;
}

public sealed record EverythingDetection(
    bool IsInstalled,
    bool IsRunning,
    string? ExecutablePath,
    string? CliPath,
    string? SdkDllPath,
    string Summary);

/// <summary>
/// Integrates with Everything Search by Voidtools without recreating its NTFS indexer.
/// Supports both Everything's official command-line client (es.exe) and Everything64.dll IPC.
/// Never silently downloads or installs Everything.
/// </summary>
public sealed class EverythingClient
{
    public const string OfficialDownloadUrl = "https://www.voidtools.com/downloads/";
    private readonly AppLog _log;
    private IntPtr _loadedSdkModule;

    public EverythingClient(AppLog log)
    {
        _log = log;
    }

    public EverythingDetection Detect(ShellConfig config)
    {
        var ipcWindow = NativeMethods.FindWindowW("EVERYTHING_TASKBAR_NOTIFICATION", null);
        if (ipcWindow == IntPtr.Zero)
        {
            // Everything 1.5a uses an instance suffix class name when running side-by-side.
            ipcWindow = NativeMethods.FindWindowW("EVERYTHING_TASKBAR_NOTIFICATION_(1.5a)", null);
        }
        var isRunning = ipcWindow != IntPtr.Zero;

        var candidateDirs = new List<string>();
        if (!string.IsNullOrWhiteSpace(config.CustomEverythingPath))
        {
            var custom = Environment.ExpandEnvironmentVariables(config.CustomEverythingPath);
            if (File.Exists(custom)) candidateDirs.Add(Path.GetDirectoryName(custom)!);
            else if (Directory.Exists(custom)) candidateDirs.Add(custom);
        }

        var pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var pfx86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        var localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var exeDir = AppContext.BaseDirectory;

        candidateDirs.Add(exeDir);
        if (!string.IsNullOrEmpty(pf))
        {
            candidateDirs.Add(Path.Combine(pf, "Everything"));
            candidateDirs.Add(Path.Combine(pf, "Everything 1.5a"));
        }
        if (!string.IsNullOrEmpty(localApp))
        {
            candidateDirs.Add(Path.Combine(localApp, "Programs", "Everything"));
            candidateDirs.Add(Path.Combine(localApp, "Microsoft", "WinGet", "Links"));
        }
        if (!string.IsNullOrEmpty(pfx86)) candidateDirs.Add(Path.Combine(pfx86, "Everything"));

        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var segment in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (Directory.Exists(segment)) candidateDirs.Add(segment);
        }

        string? exePath = null;
        string? cliPath = null;
        string? dllPath = null;

        foreach (var dir in candidateDirs.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            exePath ??= FirstExisting(Path.Combine(dir, "Everything.exe"), Path.Combine(dir, "Everything64.exe"));
            cliPath ??= FirstExisting(Path.Combine(dir, "es.exe"));
            dllPath ??= FirstExisting(Path.Combine(dir, "Everything64.dll"));
        }

        var installed = isRunning || exePath is not null || cliPath is not null;
        var summary = !installed
            ? "Everything by Voidtools is not installed."
            : !isRunning
                ? $"Everything is installed ({exePath ?? cliPath}) but its background index is not currently running."
                : cliPath is not null || dllPath is not null
                    ? "Everything IPC active and ready."
                    : "Everything is running. Place es.exe or Everything64.dll in Everything's folder (or on PATH) to return inline file results.";

        return new EverythingDetection(installed, isRunning, exePath, cliPath, dllPath, summary);
    }

    public IReadOnlyList<EverythingFileHit> Search(string query, int maxResults, ShellConfig config)
    {
        if (string.IsNullOrWhiteSpace(query) || query.Trim().Length < 2) return Array.Empty<EverythingFileHit>();
        var status = Detect(config);
        if (!status.IsInstalled || !status.IsRunning) return Array.Empty<EverythingFileHit>();

        // 1. Prefer Everything64.dll in-process IPC when present (zero process spawn, < 10 ms).
        if (status.SdkDllPath is not null)
        {
            var sdkHits = QueryViaSdkDll(status.SdkDllPath, query.Trim(), maxResults);
            if (sdkHits is not null) return sdkHits;
        }

        // 2. Official es.exe CLI fallback.
        if (status.CliPath is not null)
        {
            return QueryViaEsCli(status.CliPath, query.Trim(), maxResults);
        }

        return Array.Empty<EverythingFileHit>();
    }

    private IReadOnlyList<EverythingFileHit>? QueryViaSdkDll(string dllPath, string query, int maxResults)
    {
        try
        {
            if (_loadedSdkModule == IntPtr.Zero && !NativeLibrary.TryLoad(dllPath, out _loadedSdkModule))
            {
                return null;
            }

            var setSearch = Marshal.GetDelegateForFunctionPointer<SetSearchDelegate>(NativeLibrary.GetExport(_loadedSdkModule, "Everything_SetSearchW"));
            var setMax = Marshal.GetDelegateForFunctionPointer<SetMaxDelegate>(NativeLibrary.GetExport(_loadedSdkModule, "Everything_SetMax"));
            var execQuery = Marshal.GetDelegateForFunctionPointer<QueryDelegate>(NativeLibrary.GetExport(_loadedSdkModule, "Everything_QueryW"));
            var getCount = Marshal.GetDelegateForFunctionPointer<GetNumResultsDelegate>(NativeLibrary.GetExport(_loadedSdkModule, "Everything_GetNumResults"));
            var getPath = Marshal.GetDelegateForFunctionPointer<GetFullPathDelegate>(NativeLibrary.GetExport(_loadedSdkModule, "Everything_GetResultFullPathNameW"));
            var isFolder = Marshal.GetDelegateForFunctionPointer<IsFolderDelegate>(NativeLibrary.GetExport(_loadedSdkModule, "Everything_IsFolderResult"));

            setSearch(query);
            setMax((uint)Math.Clamp(maxResults, 1, 30));
            if (!execQuery(true)) return null;

            var count = Math.Min((int)getCount(), maxResults);
            var list = new List<EverythingFileHit>(count);
            var sb = new StringBuilder(1024);
            for (uint i = 0; i < count; i++)
            {
                sb.Clear();
                getPath(i, sb, (uint)sb.Capacity);
                var full = sb.ToString();
                if (!string.IsNullOrWhiteSpace(full))
                {
                    list.Add(new EverythingFileHit(full, isFolder(i)));
                }
            }
            return list;
        }
        catch (Exception ex)
        {
            _log.Warn($"Everything64.dll query fallback: {ex.Message}");
            return null;
        }
    }

    private IReadOnlyList<EverythingFileHit> QueryViaEsCli(string esExe, string query, int maxResults)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = esExe,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                StandardOutputEncoding = Encoding.UTF8,
            };
            psi.ArgumentList.Add("-n");
            psi.ArgumentList.Add(Math.Clamp(maxResults, 1, 25).ToString());
            psi.ArgumentList.Add(query);

            using var proc = Process.Start(psi);
            if (proc is null) return Array.Empty<EverythingFileHit>();
            var output = proc.StandardOutput.ReadToEnd();
            proc.WaitForExit(450);

            var results = new List<EverythingFileHit>();
            foreach (var rawLine in output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
            {
                var path = rawLine.Trim();
                if (path.Length == 0) continue;
                results.Add(new EverythingFileHit(path, Directory.Exists(path)));
                if (results.Count >= maxResults) break;
            }
            return results;
        }
        catch (Exception ex)
        {
            _log.Warn($"es.exe query failed: {ex.Message}");
            return Array.Empty<EverythingFileHit>();
        }
    }

    private static string? FirstExisting(params string[] paths) => paths.FirstOrDefault(File.Exists);

    [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
    private delegate void SetSearchDelegate(string search);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    private delegate void SetMaxDelegate(uint max);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    private delegate bool QueryDelegate(bool wait);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    private delegate uint GetNumResultsDelegate();
    [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
    private delegate void GetFullPathDelegate(uint index, StringBuilder buf, uint bufSize);
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    private delegate bool IsFolderDelegate(uint index);
}
