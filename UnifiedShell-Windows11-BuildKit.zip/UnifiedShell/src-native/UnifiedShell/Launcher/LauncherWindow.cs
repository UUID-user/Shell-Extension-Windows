using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Search;
using UnifiedShell.Themes;

namespace UnifiedShell.Launcher;

public sealed record SearchResultItem(
    string Title,
    string Subtitle,
    string Badge,
    string IconName,
    ImageSource? NativeIcon,
    int Score,
    Action Execute,
    Action? RevealInFolder = null);

/// <summary>
/// Unified Application Launcher, Universal Search and Command Palette (Alt + Space).
/// Inspired by PowerToys Run and Raycast: keyboard-first, instant fuzzy matching, zero web/AI providers.
/// </summary>
public sealed class LauncherWindow : Window
{
    private readonly ConfigStore _store;
    private readonly AppIndexer _appIndexer;
    private readonly EverythingClient _everything;
    private readonly AppLog _log;
    private readonly Action<string> _invokeShellCommand;

    private TextBox _searchBox = null!;
    private StackPanel _resultsHost = null!;
    private Border _everythingBanner = null!;
    private TextBlock _everythingText = null!;
    private StackPanel _recentPanel = null!;
    private WrapPanel _recentWrap = null!;

    private List<SearchResultItem> _currentResults = new();
    private int _selectedIndex;

    public LauncherWindow(
        ConfigStore store,
        AppIndexer appIndexer,
        EverythingClient everything,
        AppLog log,
        Action<string> invokeShellCommand)
    {
        _store = store;
        _appIndexer = appIndexer;
        _everything = everything;
        _log = log;
        _invokeShellCommand = invokeShellCommand;

        Title = "Unified Shell Search";
        Width = 620;
        SizeToContent = SizeToContent.Height;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        Topmost = true;
        ShowInTaskbar = false;

        BuildLayout();
        Deactivated += (_, _) => { if (IsVisible) Hide(); };
        PreviewKeyDown += OnWindowPreviewKeyDown;
        ThemeManager.ThemeChanged += BuildLayout;
    }

    public void Summon()
    {
        BuildLayout();
        var mon = DisplayManager.Resolve(_store.Current.DockMonitor);
        Left = mon.WorkDipLeft + (mon.WorkDipWidth - Width) / 2;
        Top = mon.WorkDipTop + Math.Min(136, mon.WorkDipHeight * 0.16);

        Show();
        NativeMethods.ApplyWindowChrome(this, ThemeManager.IsDark, toolWindow: true, roundCorners: true);
        Activate();
        _searchBox.Text = string.Empty;
        _searchBox.Focus();
        RefreshResults();
    }

    private void BuildLayout()
    {
        var previousQuery = _searchBox?.Text ?? string.Empty;

        var outer = new StackPanel();

        // Search input row
        var inputGrid = new Grid { Height = 50, Margin = new Thickness(14, 2, 14, 2) };
        inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var searchIcon = VectorIcons.Create("search", 16.5, ThemeManager.TextTertiary);
        searchIcon.Margin = new Thickness(0, 0, 10, 0);
        Grid.SetColumn(searchIcon, 0);
        inputGrid.Children.Add(searchIcon);

        _searchBox = new TextBox
        {
            Text = previousQuery,
            Background = Brushes.Transparent,
            BorderThickness = new Thickness(0),
            Foreground = ThemeManager.TextPrimary,
            CaretBrush = ThemeManager.AccentBrush,
            FontFamily = ThemeManager.UiFont,
            FontSize = 14,
            VerticalContentAlignment = VerticalAlignment.Center,
        };
        _searchBox.TextChanged += (_, _) => RefreshResults();
        Grid.SetColumn(_searchBox, 1);
        inputGrid.Children.Add(_searchBox);

        var escBadge = new Border
        {
            Background = ThemeManager.HoverBrush,
            BorderBrush = ThemeManager.BorderStrong,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(4),
            Padding = new Thickness(6, 2, 6, 2),
            VerticalAlignment = VerticalAlignment.Center,
            Child = new TextBlock { Text = "Esc", FontSize = 10.5, Foreground = ThemeManager.TextTertiary, FontFamily = ThemeManager.UiFont },
        };
        Grid.SetColumn(escBadge, 2);
        inputGrid.Children.Add(escBadge);
        outer.Children.Add(inputGrid);

        outer.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });

        // Recent searches strip
        _recentPanel = new StackPanel { Margin = new Thickness(14, 8, 14, 4), Visibility = Visibility.Collapsed };
        _recentPanel.Children.Add(new TextBlock
        {
            Text = "RECENT SEARCHES",
            FontSize = 10,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextTertiary,
            Margin = new Thickness(0, 0, 0, 5),
        });
        _recentWrap = new WrapPanel();
        _recentPanel.Children.Add(_recentWrap);
        outer.Children.Add(_recentPanel);

        // Results scroll viewer
        _resultsHost = new StackPanel { Margin = new Thickness(6, 6, 6, 6) };
        var scroller = new ScrollViewer
        {
            MaxHeight = 368,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = _resultsHost,
        };
        outer.Children.Add(scroller);

        // Everything Search status banner
        _everythingText = new TextBlock
        {
            FontSize = 11,
            Foreground = ThemeManager.TextSecondary,
            TextWrapping = TextWrapping.Wrap,
            VerticalAlignment = VerticalAlignment.Center,
        };
        var evLinkBtn = ThemeManager.CreateButton("Official Everything Download", "external", subtle: true, height: 24);
        evLinkBtn.Click += (_, _) =>
        {
            ShellLauncher.Open(EverythingClient.OfficialDownloadUrl, null, _log);
            Hide();
        };

        var evGrid = new Grid();
        evGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        evGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        Grid.SetColumn(_everythingText, 0);
        Grid.SetColumn(evLinkBtn, 1);
        evGrid.Children.Add(_everythingText);
        evGrid.Children.Add(evLinkBtn);

        _everythingBanner = new Border
        {
            Margin = new Thickness(10, 2, 10, 8),
            Padding = new Thickness(10, 7, 10, 7),
            CornerRadius = new CornerRadius(6),
            Background = ThemeManager.SurfaceSubtle,
            BorderBrush = ThemeManager.BorderSubtle,
            BorderThickness = new Thickness(1),
            Child = evGrid,
        };
        outer.Children.Add(_everythingBanner);

        // Footer hint bar
        outer.Children.Add(new Border { Height = 1, Background = ThemeManager.BorderSubtle });
        var footer = new DockPanel { Margin = new Thickness(14, 7, 14, 8), LastChildFill = false };
        footer.Children.Add(new TextBlock
        {
            Text = "↑↓ Navigate   ·   Enter Open   ·   Ctrl+Enter Open containing folder   ·   Esc Dismiss",
            FontSize = 10.5,
            Foreground = ThemeManager.TextTertiary,
            FontFamily = ThemeManager.UiFont,
        });
        outer.Children.Add(footer);

        Content = ThemeManager.CreatePanelShell(outer, cornerRadius: 11);
    }

    private void RefreshResults()
    {
        var cfg = _store.Current;
        var q = _searchBox.Text.Trim();
        var list = new List<SearchResultItem>();

        var evStatus = _everything.Detect(cfg);
        if (cfg.SearchFiles && (!evStatus.IsInstalled || !evStatus.IsRunning))
        {
            _everythingBanner.Visibility = Visibility.Visible;
            _everythingText.Text = evStatus.Summary;
        }
        else
        {
            _everythingBanner.Visibility = Visibility.Collapsed;
        }

        // Recent searches when input is empty
        if (string.IsNullOrEmpty(q) && cfg.ShowRecentSearches && cfg.RecentSearches.Count > 0)
        {
            _recentWrap.Children.Clear();
            foreach (var term in cfg.RecentSearches.Take(6))
            {
                var captured = term;
                var chip = ThemeManager.CreateButton(captured, "search", subtle: false, height: 23);
                chip.Margin = new Thickness(0, 0, 5, 4);
                chip.Click += (_, _) =>
                {
                    _searchBox.Text = captured;
                    _searchBox.CaretIndex = captured.Length;
                };
                _recentWrap.Children.Add(chip);
            }
            _recentPanel.Visibility = Visibility.Visible;
        }
        else
        {
            _recentPanel.Visibility = Visibility.Collapsed;
        }

        // 1. Built-in Unified Shell commands & utilities
        foreach (var cmd in GetBuiltInCommands())
        {
            if (string.IsNullOrEmpty(q))
            {
                list.Add(cmd with { Score = 50 });
                continue;
            }
            var s = FuzzyMatcher.Best(q, cmd.Title, cmd.Subtitle, cmd.Badge);
            if (s is not null) list.Add(cmd with { Score = s.Value + 8 });
        }

        if (!string.IsNullOrEmpty(q))
        {
            // 2. Installed Windows applications
            foreach (var app in _appIndexer.Snapshot())
            {
                var s = FuzzyMatcher.Best(q, app.Name, app.Category);
                if (s is null) continue;
                var captured = app;
                list.Add(new SearchResultItem(
                    Title: captured.Name,
                    Subtitle: captured.Category,
                    Badge: "Application",
                    IconName: "play",
                    NativeIcon: captured.GetIcon(),
                    Score: s.Value + 12,
                    Execute: () => ShellLauncher.Open(captured.TargetPath, null, _log),
                    RevealInFolder: () => ShellLauncher.RevealInExplorer(captured.TargetPath, _log)));
            }

            // 3. Windows 11 Settings URI pages
            if (cfg.SearchSettings)
            {
                foreach (var ws in WindowsSettingsIndex.All)
                {
                    var s = FuzzyMatcher.Best(q, ws.Name, ws.Keywords, ws.Group);
                    if (s is null) continue;
                    var captured = ws;
                    list.Add(new SearchResultItem(
                        Title: captured.Name,
                        Subtitle: $"Windows Settings · {captured.Group} ({captured.Uri})",
                        Badge: "Windows Settings",
                        IconName: "settings",
                        NativeIcon: null,
                        Score: s.Value,
                        Execute: () => ShellLauncher.Open(captured.Uri, null, _log)));
                }
            }

            // 4. Everything file & folder search
            if (cfg.SearchFiles && evStatus.IsInstalled && evStatus.IsRunning && q.Length >= 2)
            {
                foreach (var hit in _everything.Search(q, Math.Min(8, cfg.ResultLimit), cfg))
                {
                    var captured = hit;
                    list.Add(new SearchResultItem(
                        Title: captured.Name,
                        Subtitle: captured.DirectoryName,
                        Badge: captured.IsDirectory ? "Folder" : "File",
                        IconName: captured.IsDirectory ? "folder" : "notes",
                        NativeIcon: NativeMethods.ExtractShellIcon(captured.FullPath, captured.IsDirectory),
                        Score: 76,
                        Execute: () => ShellLauncher.Open(captured.FullPath, null, _log),
                        RevealInFolder: () => ShellLauncher.RevealInExplorer(captured.FullPath, _log)));
                }
            }
        }

        _currentResults = list
            .OrderByDescending(r => r.Score)
            .Take(string.IsNullOrEmpty(q) ? 7 : cfg.ResultLimit)
            .ToList();
        _selectedIndex = 0;
        RenderResultRows();
    }

    private IEnumerable<SearchResultItem> GetBuiltInCommands()
    {
        yield return new SearchResultItem("Calculator", "Compact arithmetic & percentage calculator", "Utility", "calculator", null, 0, () => _invokeShellCommand("calculator"));
        yield return new SearchResultItem("Markdown Notepad", "Open custom lightweight Markdown notepad", "Utility", "notes", null, 0, () => _invokeShellCommand("notes"));
        yield return new SearchResultItem("Clipboard History", "Browse, pin and copy local clipboard entries", "Utility", "clipboard", null, 0, () => _invokeShellCommand("clipboard"));
        yield return new SearchResultItem("Timer", "Start or inspect countdown timer", "Utility", "timer", null, 0, () => _invokeShellCommand("timer"));
        yield return new SearchResultItem("Stopwatch", "Elapsed time and lap recorder", "Utility", "stopwatch", null, 0, () => _invokeShellCommand("stopwatch"));
        yield return new SearchResultItem("Calendar", "Monthly calendar view", "Utility", "calendar", null, 0, () => _invokeShellCommand("calendar"));
        yield return new SearchResultItem("Toggle Performance Monitor", "Show or hide CPU, GPU and RAM widget", "Command", "gauge", null, 0, () => _invokeShellCommand("toggle-monitor"));
        yield return new SearchResultItem("Unified Shell Settings", "Configure appearance, dock, search and monitoring", "Command", "settings", null, 0, () => _invokeShellCommand("settings"));
    }

    private void RenderResultRows()
    {
        _resultsHost.Children.Clear();
        if (_currentResults.Count == 0)
        {
            _resultsHost.Children.Add(new TextBlock
            {
                Text = "No matching applications, settings or files.",
                FontSize = 12,
                Foreground = ThemeManager.TextTertiary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 22, 0, 22),
            });
            return;
        }

        for (int i = 0; i < _currentResults.Count; i++)
        {
            var idx = i;
            var item = _currentResults[i];
            var selected = i == _selectedIndex;

            var rowGrid = new Grid { Height = 42 };
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            FrameworkElement iconEl;
            if (item.NativeIcon is not null)
            {
                iconEl = new Image { Source = item.NativeIcon, Width = 22, Height = 22, VerticalAlignment = VerticalAlignment.Center };
            }
            else
            {
                iconEl = new Border
                {
                    Width = 26,
                    Height = 26,
                    CornerRadius = new CornerRadius(6),
                    Background = ThemeManager.HoverBrush,
                    Child = VectorIcons.Create(item.IconName, 14, ThemeManager.AccentBrush),
                };
            }
            Grid.SetColumn(iconEl, 0);
            rowGrid.Children.Add(iconEl);

            var textStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 8, 0) };
            textStack.Children.Add(new TextBlock
            {
                Text = item.Title,
                FontSize = 12.5,
                FontWeight = FontWeights.Medium,
                Foreground = ThemeManager.TextPrimary,
                TextTrimming = TextTrimming.CharacterEllipsis,
            });
            textStack.Children.Add(new TextBlock
            {
                Text = item.Subtitle,
                FontSize = 10.5,
                Foreground = ThemeManager.TextTertiary,
                TextTrimming = TextTrimming.CharacterEllipsis,
            });
            Grid.SetColumn(textStack, 1);
            rowGrid.Children.Add(textStack);

            var badge = new Border
            {
                Background = ThemeManager.HoverBrush,
                BorderBrush = ThemeManager.BorderSubtle,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(4),
                Padding = new Thickness(6, 2, 6, 2),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock { Text = item.Badge, FontSize = 10, Foreground = ThemeManager.TextSecondary },
            };
            Grid.SetColumn(badge, 2);
            rowGrid.Children.Add(badge);

            var rowBorder = new Border
            {
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(8, 0, 10, 0),
                Background = selected ? ThemeManager.AccentSoftBrush : Brushes.Transparent,
                BorderBrush = selected ? ThemeManager.AccentBrush : Brushes.Transparent,
                BorderThickness = new Thickness(selected ? 1 : 0),
                Cursor = Cursors.Hand,
                Child = rowGrid,
            };
            rowBorder.MouseEnter += (_, _) =>
            {
                if (_selectedIndex != idx)
                {
                    _selectedIndex = idx;
                    RenderResultRows();
                }
            };
            rowBorder.MouseLeftButtonUp += (_, _) => ExecuteCurrent(revealFolder: false);
            _resultsHost.Children.Add(rowBorder);
        }
    }

    private void OnWindowPreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            e.Handled = true;
            Hide();
        }
        else if (e.Key == Key.Down)
        {
            e.Handled = true;
            if (_currentResults.Count > 0)
            {
                _selectedIndex = (_selectedIndex + 1) % _currentResults.Count;
                RenderResultRows();
            }
        }
        else if (e.Key == Key.Up)
        {
            e.Handled = true;
            if (_currentResults.Count > 0)
            {
                _selectedIndex = (_selectedIndex - 1 + _currentResults.Count) % _currentResults.Count;
                RenderResultRows();
            }
        }
        else if (e.Key == Key.Enter)
        {
            e.Handled = true;
            var reveal = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
            ExecuteCurrent(reveal);
        }
    }

    private void ExecuteCurrent(bool revealFolder)
    {
        if (_selectedIndex < 0 || _selectedIndex >= _currentResults.Count) return;
        var chosen = _currentResults[_selectedIndex];
        var query = _searchBox.Text.Trim();
        if (query.Length >= 2 && _store.Current.ShowRecentSearches)
        {
            var recents = _store.Current.RecentSearches;
            recents.RemoveAll(r => r.Equals(query, StringComparison.OrdinalIgnoreCase));
            recents.Insert(0, query);
            if (recents.Count > 8) recents.RemoveRange(8, recents.Count - 8);
            _store.Save(raiseEvent: false);
        }

        Hide();
        if (revealFolder && chosen.RevealInFolder is not null) chosen.RevealInFolder();
        else chosen.Execute();
    }
}
