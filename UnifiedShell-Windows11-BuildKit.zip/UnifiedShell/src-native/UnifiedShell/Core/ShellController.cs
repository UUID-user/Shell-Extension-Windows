using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Microsoft.Win32;
using UnifiedShell.Configuration;
using UnifiedShell.Dock;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Launcher;
using UnifiedShell.Search;
using UnifiedShell.Settings;
using UnifiedShell.Themes;
using UnifiedShell.Utilities;
using UnifiedShell.Widgets;

namespace UnifiedShell.Core;

/// <summary>
/// Single-process application coordinator.
/// Owns Win32 global hotkey registration, WM_CLIPBOARDUPDATE listener, display change recovery,
/// Explorer restart compatibility ("TaskbarCreated") and fullscreen application suppression.
/// </summary>
public sealed class ShellController : IDisposable
{
    private const int HotkeyIdLauncher = 0x51A0;

    private readonly AppPaths _paths;
    private readonly ConfigStore _store;
    private readonly AppLog _log;
    private readonly MetricsProvider _metrics;
    private readonly AppIndexer _appIndexer;
    private readonly EverythingClient _everything;
    private readonly ClipboardService _clipboard;
    private readonly TimerController _timer;
    private readonly StopwatchController _stopwatch;

    private readonly TopDockWindow _dock;
    private readonly LauncherWindow _launcher;
    private readonly PerformanceWidgetWindow _perfWidget;
    private readonly NotepadWindow _notepad;
    private readonly SettingsWindow _settingsWindow;
    private readonly Dictionary<string, DockPopoverWindow> _popovers;

    private readonly DispatcherTimer _fullscreenCheckTimer;
    private HwndSource? _hwndSource;
    private uint _taskbarCreatedMsg;
    private string _registeredShortcut = string.Empty;
    private bool _clipboardRegistered;
    private bool _disposed;

    public ShellController(AppPaths paths, ConfigStore store, AppLog log)
    {
        _paths = paths;
        _store = store;
        _log = log;

        ThemeManager.Apply(_store.Current);

        _metrics = new MetricsProvider();
        _appIndexer = new AppIndexer(_log);
        _appIndexer.RefreshAsync();
        _everything = new EverythingClient(_log);
        _clipboard = new ClipboardService(_paths, _store, _log);
        _timer = new TimerController(_store);
        _stopwatch = new StopwatchController();

        _dock = new TopDockWindow(_store, _timer, _stopwatch, _log, DispatchAction);
        _launcher = new LauncherWindow(_store, _appIndexer, _everything, _log, DispatchAction);
        _perfWidget = new PerformanceWidgetWindow(_store, _metrics, () => OpenSettings("performance"));
        _notepad = new NotepadWindow(_paths, _store, _log);
        _settingsWindow = new SettingsWindow(_paths, _store, _everything, _clipboard, _log, Shutdown);

        _popovers = new Dictionary<string, DockPopoverWindow>(StringComparer.OrdinalIgnoreCase)
        {
            ["calculator"] = new CalculatorPopup(),
            ["calendar"] = new CalendarPopup(),
            ["timer"] = new TimerPopup(_timer),
            ["stopwatch"] = new StopwatchPopup(_stopwatch),
            ["clipboard"] = new ClipboardPopup(_clipboard, _store),
            ["tray"] = new TrayMirrorPopup(_log),
            ["add"] = new AddDockItemPopup(_store, _appIndexer),
        };

        _fullscreenCheckTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(1500),
        };
        _fullscreenCheckTimer.Tick += (_, _) => CheckFullscreenApplications();

        _store.Changed += OnConfigurationChanged;
        SystemEvents.DisplaySettingsChanged += OnDisplaySettingsChanged;
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
    }

    public void Start()
    {
        // Ensure a Win32 HWND exists for the dock even if DockEnabled starts false.
        _dock.Show();
        AttachWin32Hooks();
        _dock.ApplyPlacementAndBuild();
        _perfWidget.ApplyConfiguration();
        _fullscreenCheckTimer.Start();

        if (_store.Current.LaunchAtSignIn != StartupManager.IsEnabled())
        {
            StartupManager.SetEnabled(_store.Current.LaunchAtSignIn, _paths.Portable, _log);
        }

        if (_store.Current.StartupBehaviour.Equals("launcher", StringComparison.OrdinalIgnoreCase))
        {
            _launcher.Summon();
        }

        _log.Info("Unified Shell ready alongside Windows Explorer");
    }

    private void AttachWin32Hooks()
    {
        var hwnd = new WindowInteropHelper(_dock).EnsureHandle();
        _hwndSource = HwndSource.FromHwnd(hwnd);
        _hwndSource?.AddHook(WndProc);

        _taskbarCreatedMsg = NativeMethods.RegisterWindowMessageW("TaskbarCreated");
        _clipboardRegistered = NativeMethods.AddClipboardFormatListener(hwnd);
        RegisterConfiguredHotkey(hwnd, _store.Current.SearchShortcut);
    }

    private void RegisterConfiguredHotkey(IntPtr hwnd, string shortcut)
    {
        if (hwnd == IntPtr.Zero) return;
        if (!string.IsNullOrEmpty(_registeredShortcut))
        {
            NativeMethods.UnregisterHotKey(hwnd, HotkeyIdLauncher);
            _registeredShortcut = string.Empty;
        }

        if (!TryParseHotkey(shortcut, out var modifiers, out var vk))
        {
            modifiers = NativeMethods.MOD_ALT | NativeMethods.MOD_NOREPEAT;
            vk = 0x20; // VK_SPACE
        }

        if (NativeMethods.RegisterHotKey(hwnd, HotkeyIdLauncher, modifiers, vk))
        {
            _registeredShortcut = shortcut;
            _log.Info($"Registered global hotkey: {shortcut}");
        }
        else
        {
            _log.Warn($"Could not register global hotkey '{shortcut}' (already in use by another app).");
        }
    }

    private static bool TryParseHotkey(string text, out uint modifiers, out uint virtualKey)
    {
        modifiers = NativeMethods.MOD_NOREPEAT;
        virtualKey = 0;
        if (string.IsNullOrWhiteSpace(text)) return false;

        var tokens = text.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        foreach (var tok in tokens)
        {
            if (tok.Equals("Alt", StringComparison.OrdinalIgnoreCase)) modifiers |= NativeMethods.MOD_ALT;
            else if (tok.Equals("Ctrl", StringComparison.OrdinalIgnoreCase) || tok.Equals("Control", StringComparison.OrdinalIgnoreCase)) modifiers |= NativeMethods.MOD_CONTROL;
            else if (tok.Equals("Shift", StringComparison.OrdinalIgnoreCase)) modifiers |= NativeMethods.MOD_SHIFT;
            else if (tok.Equals("Win", StringComparison.OrdinalIgnoreCase)) modifiers |= NativeMethods.MOD_WIN;
            else if (tok.Equals("Space", StringComparison.OrdinalIgnoreCase)) virtualKey = 0x20;
            else if (Enum.TryParse<Key>(tok, ignoreCase: true, out var wpfKey))
            {
                virtualKey = (uint)KeyInterop.VirtualKeyFromKey(wpfKey);
            }
        }
        return virtualKey != 0;
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == NativeMethods.WM_HOTKEY && wParam.ToInt32() == HotkeyIdLauncher)
        {
            handled = true;
            ToggleLauncher();
        }
        else if (msg == NativeMethods.WM_CLIPBOARDUPDATE)
        {
            _clipboard.OnClipboardUpdated();
        }
        else if (msg == NativeMethods.WM_DISPLAYCHANGE || msg == NativeMethods.WM_DPICHANGED)
        {
            Dispatcher.CurrentDispatcher.InvokeAsync(RecoverDisplayLayout, DispatcherPriority.Background);
        }
        else if (msg == NativeMethods.WM_SETTINGCHANGE)
        {
            if (_store.Current.Theme.Equals("system", StringComparison.OrdinalIgnoreCase))
            {
                ThemeManager.Apply(_store.Current);
            }
        }
        else if (_taskbarCreatedMsg != 0 && (uint)msg == _taskbarCreatedMsg)
        {
            // explorer.exe restarted; refresh placement cleanly without interfering with Explorer.
            _log.Info("Explorer TaskbarCreated received; refreshing dock work-area placement");
            Dispatcher.CurrentDispatcher.InvokeAsync(RecoverDisplayLayout, DispatcherPriority.Background);
        }

        return IntPtr.Zero;
    }

    private void DispatchAction(string action)
    {
        switch (action)
        {
            case "launcher":
                ToggleLauncher();
                break;
            case "notes":
                HidePopovers();
                _notepad.ToggleOrFocus();
                break;
            case "toggle-monitor":
                _store.Current.MonitorVisible = !_store.Current.MonitorVisible;
                _store.Save();
                break;
            case "settings":
                HidePopovers();
                OpenSettings();
                break;
            case "quit":
                Shutdown();
                break;
            default:
                if (_popovers.TryGetValue(action, out var pop))
                {
                    if (pop.IsVisible)
                    {
                        pop.Hide();
                        return;
                    }
                    HidePopovers();
                    var align = action == "tray" ? "right" : action == "add" ? "left" : "center";
                    var mon = DisplayManager.Resolve(_store.Current.DockMonitor);
                    pop.ShowAnchored(mon, _store.Current, align);
                }
                break;
        }
    }

    private void ToggleLauncher()
    {
        HidePopovers();
        if (_launcher.IsVisible) _launcher.Hide();
        else _launcher.Summon();
    }

    private void OpenSettings(string? category = null)
    {
        _settingsWindow.OpenCategory(category);
    }

    private void HidePopovers()
    {
        foreach (var pop in _popovers.Values)
        {
            if (pop.IsVisible) pop.Hide();
        }
    }

    private void OnConfigurationChanged(ShellConfig cfg)
    {
        ThemeManager.Apply(cfg);
        var hwnd = _dock.Hwnd;
        if (hwnd != IntPtr.Zero && !string.Equals(_registeredShortcut, cfg.SearchShortcut, StringComparison.OrdinalIgnoreCase))
        {
            RegisterConfiguredHotkey(hwnd, cfg.SearchShortcut);
        }
        _dock.ApplyPlacementAndBuild();
        _perfWidget.ApplyConfiguration();
    }

    private void CheckFullscreenApplications()
    {
        var dockMon = DisplayManager.Resolve(_store.Current.DockMonitor);
        var fullscreenOnDockMon = NativeMethods.IsFullscreenApplicationActive(_dock.Hwnd, dockMon.Handle);
        _dock.SetFullscreenSuppressed(fullscreenOnDockMon);

        var perfMon = DisplayManager.Resolve(_store.Current.MetricsMonitor);
        var fullscreenOnPerfMon = perfMon.Handle == dockMon.Handle
            ? fullscreenOnDockMon
            : NativeMethods.IsFullscreenApplicationActive(_dock.Hwnd, perfMon.Handle);
        _perfWidget.ApplyConfiguration(suppressedByFullscreen: fullscreenOnPerfMon);
    }

    private void RecoverDisplayLayout()
    {
        _dock.ApplyPlacementAndBuild();
        _perfWidget.ApplyConfiguration();
    }

    private void OnDisplaySettingsChanged(object? sender, EventArgs e)
    {
        Application.Current?.Dispatcher.InvokeAsync(RecoverDisplayLayout);
    }

    private void OnPowerModeChanged(object sender, PowerModeChangedEventArgs e)
    {
        if (e.Mode == PowerModes.Resume)
        {
            _log.Info("System resumed from sleep; refreshing monitors and metrics");
            Application.Current?.Dispatcher.InvokeAsync(RecoverDisplayLayout);
        }
    }

    public void Shutdown()
    {
        Dispose();
        Application.Current?.Shutdown();
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        _fullscreenCheckTimer.Stop();
        SystemEvents.DisplaySettingsChanged -= OnDisplaySettingsChanged;
        SystemEvents.PowerModeChanged -= OnPowerModeChanged;

        var hwnd = _dock.Hwnd;
        if (hwnd != IntPtr.Zero)
        {
            if (!string.IsNullOrEmpty(_registeredShortcut)) NativeMethods.UnregisterHotKey(hwnd, HotkeyIdLauncher);
            if (_clipboardRegistered) NativeMethods.RemoveClipboardFormatListener(hwnd);
        }

        _hwndSource?.RemoveHook(WndProc);
        _metrics.Dispose();
    }
}
