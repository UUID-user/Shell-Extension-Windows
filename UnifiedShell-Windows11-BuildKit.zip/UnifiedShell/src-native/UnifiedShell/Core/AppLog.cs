using System;
using System.Collections.Concurrent;
using System.IO;
using System.Text;
using System.Threading;

namespace UnifiedShell.Core;

/// <summary>
/// Lightweight asynchronous file logger with 1 MB rotation.
/// Warnings and errors are always recorded; info entries are written only when verbose logging is enabled.
/// </summary>
public sealed class AppLog : IDisposable
{
    private readonly BlockingCollection<string> _queue = new(new ConcurrentQueue<string>(), 512);
    private readonly Thread _writer;
    private string _path;
    private volatile bool _verbose;
    private volatile bool _disposed;

    public string LogFile => _path;

    private AppLog(string path, bool verbose)
    {
        _path = path;
        _verbose = verbose;
        _writer = new Thread(WriteLoop) { IsBackground = true, Name = "UnifiedShell.Log" };
        _writer.Start();
    }

    public static AppLog Create(string? directoryOverride = null)
    {
        var directory = directoryOverride ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "UnifiedShell",
            "logs");
        try
        {
            Directory.CreateDirectory(directory);
        }
        catch
        {
            directory = Path.GetTempPath();
        }

        return new AppLog(Path.Combine(directory, "unified-shell.log"), verbose: false);
    }

    public void RedirectDirectory(string logDirectory)
    {
        try
        {
            Directory.CreateDirectory(logDirectory);
            _path = Path.Combine(logDirectory, "unified-shell.log");
        }
        catch
        {
            // Keep existing log path if redirection fails.
        }
    }

    public void SetVerbose(bool verbose) => _verbose = verbose;

    public void Info(string message) => Enqueue("INFO", message, always: false);
    public void Warn(string message) => Enqueue("WARN", message, always: true);
    public void Error(string message, Exception? exception = null) =>
        Enqueue("ERROR", exception is null ? message : $"{message}: {exception.GetType().Name}: {exception.Message}", always: true);

    private void Enqueue(string level, string message, bool always)
    {
        if (_disposed || (!_verbose && !always)) return;
        var line = $"{DateTimeOffset.Now:yyyy-MM-ddTHH:mm:ss.fffzzz} [{level}] {message}";
        _queue.TryAdd(line);
    }

    private void WriteLoop()
    {
        var builder = new StringBuilder();
        foreach (var line in _queue.GetConsumingEnumerable())
        {
            try
            {
                var info = new FileInfo(_path);
                if (info.Exists && info.Length > 1_048_576)
                {
                    var previous = _path + ".1";
                    if (File.Exists(previous)) File.Delete(previous);
                    File.Move(_path, previous);
                }

                builder.Clear();
                builder.AppendLine(line);
                File.AppendAllText(_path, builder.ToString(), Encoding.UTF8);
            }
            catch
            {
                // Logging must never crash the shell.
            }
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _queue.CompleteAdding();
        _writer.Join(TimeSpan.FromSeconds(1));
        _queue.Dispose();
    }
}
