using System;
using System.Runtime.InteropServices;
using UnifiedShell.Interop;

namespace UnifiedShell.Core;

public sealed record MetricsSnapshot(
    double CpuPercent,
    int LogicalProcessors,
    double? CpuTemperatureC,
    double? GpuPercent,
    string GpuAdapterName,
    ulong? GpuDedicatedUsedBytes,
    ulong? GpuDedicatedTotalBytes,
    double? GpuTemperatureC,
    ulong TotalMemoryBytes,
    ulong AvailableMemoryBytes,
    DateTimeOffset SampledAt)
{
    public ulong UsedMemoryBytes => TotalMemoryBytes > AvailableMemoryBytes ? TotalMemoryBytes - AvailableMemoryBytes : 0;
    public double MemoryPercent => TotalMemoryBytes > 0 ? Math.Clamp(Math.Round(100.0 * UsedMemoryBytes / TotalMemoryBytes, 1), 0, 100) : 0;
}

/// <summary>
/// Low-overhead Windows 11 performance monitor.
/// - CPU: GetSystemTimes kernel/user/idle tick deltas (zero WMI overhead).
/// - RAM: GlobalMemoryStatusEx (instantaneous struct read).
/// - GPU: PDH English wildcard counters for GPU Engine 3D utilisation and GPU Adapter Memory Dedicated Usage,
///        plus one-time DXGI adapter enumeration for adapter name and dedicated VRAM capacity.
/// - Temperatures: Windows user-mode exposes no reliable vendor-neutral CPU/GPU thermal sensor without a kernel
///        driver (WinRing0/PawnIO). Unified Shell intentionally avoids kernel drivers and never estimates temperatures.
/// </summary>
public sealed class MetricsProvider : IDisposable
{
    private readonly object _gate = new();
    private ulong _previousIdle;
    private ulong _previousKernel;
    private ulong _previousUser;
    private DateTime _previousSample = DateTime.MinValue;
    private double _lastCpu;
    private PdhGpuSampler? _gpuSampler;
    private readonly (string Name, ulong? DedicatedBytes) _adapterInfo;

    public MetricsProvider()
    {
        _adapterInfo = DxgiAdapterProbe.QueryPrimaryAdapter();
        _gpuSampler = PdhGpuSampler.TryCreate();
    }

    public MetricsSnapshot Sample(bool includeCpu = true, bool includeGpu = true, bool includeRam = true)
    {
        lock (_gate)
        {
            var cpu = includeCpu ? SampleCpu() : 0;
            var (totalMem, availMem) = includeRam ? SampleMemory() : (0UL, 0UL);
            double? gpuPct = null;
            ulong? vramUsed = null;
            if (includeGpu)
            {
                _gpuSampler ??= PdhGpuSampler.TryCreate();
                if (_gpuSampler is not null)
                {
                    (gpuPct, vramUsed) = _gpuSampler.Sample();
                }
            }

            return new MetricsSnapshot(
                CpuPercent: cpu,
                LogicalProcessors: Environment.ProcessorCount,
                CpuTemperatureC: null,
                GpuPercent: gpuPct,
                GpuAdapterName: _adapterInfo.Name,
                GpuDedicatedUsedBytes: vramUsed,
                GpuDedicatedTotalBytes: _adapterInfo.DedicatedBytes,
                GpuTemperatureC: null,
                TotalMemoryBytes: totalMem,
                AvailableMemoryBytes: availMem,
                SampledAt: DateTimeOffset.Now);
        }
    }

    private double SampleCpu()
    {
        if (!NativeMethods.GetSystemTimes(out var idle, out var kernel, out var user)) return _lastCpu;
        var idleTicks = idle.AsULong;
        var kernelTicks = kernel.AsULong;
        var userTicks = user.AsULong;

        var prevIdle = _previousIdle;
        var prevKernel = _previousKernel;
        var prevUser = _previousUser;
        var elapsedMs = (DateTime.UtcNow - _previousSample).TotalMilliseconds;

        _previousIdle = idleTicks;
        _previousKernel = kernelTicks;
        _previousUser = userTicks;
        _previousSample = DateTime.UtcNow;

        if (prevKernel == 0 && prevUser == 0) return 0;
        var idleDelta = idleTicks - prevIdle;
        var totalDelta = (kernelTicks - prevKernel) + (userTicks - prevUser);
        if (totalDelta == 0 || elapsedMs < 80) return _lastCpu;

        var busy = totalDelta > idleDelta ? totalDelta - idleDelta : 0;
        _lastCpu = Math.Clamp(Math.Round(100.0 * busy / totalDelta, 1), 0, 100);
        return _lastCpu;
    }

    private static (ulong Total, ulong Available) SampleMemory()
    {
        var status = new NativeMethods.MEMORYSTATUSEX
        {
            dwLength = (uint)Marshal.SizeOf<NativeMethods.MEMORYSTATUSEX>(),
        };
        return NativeMethods.GlobalMemoryStatusEx(ref status)
            ? (status.ullTotalPhys, status.ullAvailPhys)
            : (0UL, 0UL);
    }

    public void Dispose()
    {
        lock (_gate)
        {
            _gpuSampler?.Dispose();
            _gpuSampler = null;
        }
    }
}

internal static class DxgiAdapterProbe
{
    private static readonly Guid IidIDXGIFactory1 = new("770aae78-f26f-4dba-a829-253c83d1b387");

    [DllImport("dxgi.dll")]
    private static extern int CreateDXGIFactory1(ref Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object? ppFactory);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct DXGI_ADAPTER_DESC1
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string Description;
        public uint VendorId;
        public uint DeviceId;
        public uint SubSysId;
        public uint Revision;
        public nuint DedicatedVideoMemory;
        public nuint DedicatedSystemMemory;
        public nuint SharedSystemMemory;
        public long AdapterLuid;
        public uint Flags;
    }

    [ComImport, Guid("770aae78-f26f-4dba-a829-253c83d1b387"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IDXGIFactory1
    {
        // IDXGIObject (4) + IDXGIFactory (8) + EnumAdapters1
        void SetPrivateData();
        void SetPrivateDataInterface();
        void GetPrivateData();
        void GetParent();
        void EnumAdapters();
        void MakeWindowAssociation();
        void GetWindowAssociation();
        void CreateSwapChain();
        void CreateSoftwareAdapter();
        [PreserveSig] int EnumAdapters1(uint adapter, [MarshalAs(UnmanagedType.Interface)] out IDXGIAdapter1? ppAdapter);
    }

    [ComImport, Guid("29038f61-3839-4626-91fd-086879011a05"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IDXGIAdapter1
    {
        void SetPrivateData();
        void SetPrivateDataInterface();
        void GetPrivateData();
        void GetParent();
        void EnumOutputs();
        void GetDesc();
        void CheckInterfaceSupport();
        [PreserveSig] int GetDesc1(out DXGI_ADAPTER_DESC1 pDesc);
    }

    public static (string Name, ulong? DedicatedBytes) QueryPrimaryAdapter()
    {
        object? factoryObj = null;
        try
        {
            var iid = IidIDXGIFactory1;
            if (CreateDXGIFactory1(ref iid, out factoryObj) != 0 || factoryObj is not IDXGIFactory1 factory)
            {
                return ("Graphics Adapter", null);
            }

            string bestName = "Graphics Adapter";
            ulong bestVram = 0;

            for (uint i = 0; i < 6; i++)
            {
                if (factory.EnumAdapters1(i, out var adapter) != 0 || adapter is null) break;
                try
                {
                    if (adapter.GetDesc1(out var desc) == 0)
                    {
                        // Skip Microsoft Basic Render Driver (software flag 2) unless nothing else exists.
                        var isSoftware = (desc.Flags & 2) != 0;
                        var vram = (ulong)desc.DedicatedVideoMemory;
                        if (!isSoftware && (vram >= bestVram || bestName == "Graphics Adapter"))
                        {
                            bestName = string.IsNullOrWhiteSpace(desc.Description) ? "Graphics Adapter" : desc.Description.Trim();
                            bestVram = vram;
                        }
                    }
                }
                finally
                {
                    if (Marshal.IsComObject(adapter)) Marshal.ReleaseComObject(adapter);
                }
            }

            return (bestName, bestVram > 0 ? bestVram : null);
        }
        catch
        {
            return ("Graphics Adapter", null);
        }
        finally
        {
            if (factoryObj is not null && Marshal.IsComObject(factoryObj)) Marshal.ReleaseComObject(factoryObj);
        }
    }
}

internal sealed class PdhGpuSampler : IDisposable
{
    private IntPtr _query;
    private readonly IntPtr _engineCounter;
    private readonly IntPtr _vramCounter;

    private PdhGpuSampler(IntPtr query, IntPtr engineCounter, IntPtr vramCounter)
    {
        _query = query;
        _engineCounter = engineCounter;
        _vramCounter = vramCounter;
    }

    public static PdhGpuSampler? TryCreate()
    {
        try
        {
            if (PdhOpenQueryW(null, IntPtr.Zero, out var query) != 0) return null;
            _ = PdhAddEnglishCounterW(query, @"\GPU Engine(*)\Utilization Percentage", IntPtr.Zero, out var engineCounter);
            _ = PdhAddEnglishCounterW(query, @"\GPU Adapter Memory(*)\Dedicated Usage", IntPtr.Zero, out var vramCounter);
            if (engineCounter == IntPtr.Zero && vramCounter == IntPtr.Zero)
            {
                PdhCloseQuery(query);
                return null;
            }
            _ = PdhCollectQueryData(query);
            return new PdhGpuSampler(query, engineCounter, vramCounter);
        }
        catch
        {
            return null;
        }
    }

    public (double? GpuPercent, ulong? DedicatedBytes) Sample()
    {
        if (_query == IntPtr.Zero || PdhCollectQueryData(_query) != 0) return (null, null);
        var gpuPct = _engineCounter != IntPtr.Zero ? ReadCounterSum(_engineCounter, filterSubstring: "engtype_3D") : null;
        if (gpuPct is not null) gpuPct = Math.Clamp(Math.Round(gpuPct.Value, 1), 0, 100);

        ulong? vram = null;
        if (_vramCounter != IntPtr.Zero)
        {
            var bytes = ReadCounterMax(_vramCounter);
            if (bytes is > 0) vram = (ulong)bytes.Value;
        }
        return (gpuPct, vram);
    }

    private static double? ReadCounterSum(IntPtr counter, string? filterSubstring)
    {
        uint size = 0, count = 0;
        if (PdhGetFormattedCounterArrayW(counter, PdhFmtDouble, ref size, ref count, IntPtr.Zero) != PdhMoreData || size == 0) return null;
        var buffer = Marshal.AllocHGlobal((int)size);
        try
        {
            if (PdhGetFormattedCounterArrayW(counter, PdhFmtDouble, ref size, ref count, buffer) != 0 || count == 0) return null;
            var stride = Marshal.SizeOf<PdhItem>();
            double sum = 0;
            int hits = 0;
            for (int i = 0; i < count; i++)
            {
                var item = Marshal.PtrToStructure<PdhItem>(buffer + i * stride);
                if (item.Value.CStatus != 0) continue;
                if (filterSubstring is not null && (item.Name is null || !item.Name.Contains(filterSubstring, StringComparison.OrdinalIgnoreCase))) continue;
                sum += item.Value.DoubleValue;
                hits++;
            }
            return hits > 0 ? sum : null;
        }
        finally
        {
            Marshal.FreeHGlobal(buffer);
        }
    }

    private static double? ReadCounterMax(IntPtr counter)
    {
        uint size = 0, count = 0;
        if (PdhGetFormattedCounterArrayW(counter, PdhFmtDouble, ref size, ref count, IntPtr.Zero) != PdhMoreData || size == 0) return null;
        var buffer = Marshal.AllocHGlobal((int)size);
        try
        {
            if (PdhGetFormattedCounterArrayW(counter, PdhFmtDouble, ref size, ref count, buffer) != 0 || count == 0) return null;
            var stride = Marshal.SizeOf<PdhItem>();
            double max = 0;
            for (int i = 0; i < count; i++)
            {
                var item = Marshal.PtrToStructure<PdhItem>(buffer + i * stride);
                if (item.Value.CStatus == 0 && item.Value.DoubleValue > max) max = item.Value.DoubleValue;
            }
            return max > 0 ? max : null;
        }
        finally
        {
            Marshal.FreeHGlobal(buffer);
        }
    }

    public void Dispose()
    {
        if (_query != IntPtr.Zero)
        {
            PdhCloseQuery(_query);
            _query = IntPtr.Zero;
        }
    }

    private const uint PdhFmtDouble = 0x00000200;
    private const uint PdhMoreData = 0x800007D2;

    [StructLayout(LayoutKind.Sequential)]
    private struct PdhValue
    {
        public uint CStatus;
        public double DoubleValue;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct PdhItem
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string? Name;
        public PdhValue Value;
    }

    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhOpenQueryW(string? szDataSource, IntPtr dwUserData, out IntPtr phQuery);

    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhAddEnglishCounterW(IntPtr hQuery, string szFullCounterPath, IntPtr dwUserData, out IntPtr phCounter);

    [DllImport("pdh.dll")]
    private static extern uint PdhCollectQueryData(IntPtr hQuery);

    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhGetFormattedCounterArrayW(IntPtr hCounter, uint dwFormat, ref uint lpdwBufferSize, ref uint lpdwItemCount, IntPtr ItemBuffer);

    [DllImport("pdh.dll")]
    private static extern uint PdhCloseQuery(IntPtr hQuery);
}
