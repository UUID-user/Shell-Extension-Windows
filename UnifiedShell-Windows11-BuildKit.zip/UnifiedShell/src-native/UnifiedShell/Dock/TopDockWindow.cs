using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using UnifiedShell.Configuration;
using UnifiedShell.Core;
using UnifiedShell.Integration;
using UnifiedShell.Interop;
using UnifiedShell.Themes;
using UnifiedShell.Utilities;

namespace UnifiedShell.Dock;

/// <summary>
/// Primary Top Dock bar inspired by the macOS menu bar and Seelen UI.
/// Remains completely independent of the native Windows taskbar and system tray.
/// </summary>
public sealed class TopDockWindow : Window
{
    private readonly ConfigStore _store;
    private readonly TimerController _timer;
    private readonly StopwatchController _stopwatch;
    private readonly AppLog _log;
    private readonly Action<string> _dispatchAction;
    private readonly DispatcherTimer _clockTimer;

    private TextBlock? _dateText;
    private TextBlock? _clockText;
    private bool _pointerRevealed;
    private bool _suppressedByFullscreen;
    private string? _dragItemId;

    public IntPtr Hwnd => new WindowInteropHelper(this).Handle;

    public TopDockWindow(
        ConfigStore store,
        TimerController timer,
        StopwatchController stopwatch,
        AppLog log,
        Action<string> dispatchAction)
    {
        _store = store;
        _timer = timer;
        _stopwatch = stopwatch;
        _log = log;
        _dispatchAction = dispatchAction;

        Title = "Unified Shell Dock";
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        Topmost = true;
        ShowInTaskbar = false;
        ShowActivated = false;

        _clockTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromSeconds(10),
        };
        _clockTimer.Tick += (_, _) => UpdateClockText();

        MouseEnter += (_, _) =>
        {
            if (_store.Current.AutoHide && !_pointerRevealed)
            {
                _pointerRevealed = true;
                ApplyPlacementAndBuild();
            }
        };
        MouseLeave += (_, _) =>
        {
            if (_store.Current.AutoHide && _pointerRevealed)
            {
                _pointerRevealed = false;
                ApplyPlacementAndBuild();
            }
        };

        _timer.Updated += () => Dispatcher.InvokeAsync(RebuildBar);
        _stopwatch.Updated += () =>
        {
            // Rebuild only on running state transitions, not every 50 ms tick.
        };
        ThemeManager.ThemeChanged += ApplyPlacementAndBuild;
    }

    public void SetFullscreenSuppressed(bool suppressed)
    {
        if (_suppressedByFullscreen == suppressed) return;
        _suppressedByFullscreen = suppressed;
        ApplyPlacementAndBuild();
    }

    public void ApplyPlacementAndBuild()
    {
        var cfg = _store.Current;
        if (!cfg.DockEnabled || _suppressedByFullscreen)
        {
            _clockTimer.Stop();
            if (IsVisible) Hide();
            return;
        }

        var mon = DisplayManager.Resolve(cfg.DockMonitor);
        var collapsed = cfg.AutoHide && !_pointerRevealed;

        Left = mon.WorkDipLeft;
        Width = mon.WorkDipWidth;
        Height = collapsed ? 4 : cfg.DockHeight;

        if (cfg.DockPosition == "bottom")
        {
            Top = mon.WorkDipBottom - Height;
        }
        else
        {
            Top = mon.WorkDipTop;
        }

        if (collapsed)
        {
            Content = new Border
            {
                Background = ThemeManager.AccentSoftBrush,
                Opacity = 0.55,
            };
        }
        else
        {
            RebuildBar();
        }

        if (!IsVisible)
        {
            Show();
            NativeMethods.ApplyWindowChrome(this, ThemeManager.IsDark, toolWindow: true, roundCorners: false);
        }

        if (!_clockTimer.IsEnabled) _clockTimer.Start();
    }

    public void RebuildBar()
    {
        var cfg = _store.Current;
        if (cfg.AutoHide && !_pointerRevealed) return;

        var grid = new Grid { Margin = new Thickness(8, 0, 8, 0) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        // ---------------- LEFT SECTION: Launcher + Pinned Shortcuts + Add ----------------
        var leftPanel = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };

        var launcherBtn = CreateDockIconButton(
            VectorIcons.Create("logo", Math.Max(15, cfg.IconSize - 6), ThemeManager.AccentBrush),
            $"Universal Search ({cfg.SearchShortcut})",
            cfg.DockHeight - 8);
        launcherBtn.Click += (_, _) => _dispatchAction("launcher");
        launcherBtn.ContextMenu = BuildShellContextMenu();
        leftPanel.Children.Add(launcherBtn);
        leftPanel.Children.Add(CreateVerticalDivider());

        for (int i = 0; i < cfg.PinnedItems.Count; i++)
        {
            var idx = i;
            var item = cfg.PinnedItems[i];
            var isFolder = item.Kind.Equals("folder", StringComparison.OrdinalIgnoreCase) || Directory.Exists(item.Target);
            var nativeIcon = NativeMethods.ExtractShellIcon(Environment.ExpandEnvironmentVariables(item.Target), isFolder);

            FrameworkElement visual = nativeIcon is not null
                ? new Image
                {
                    Source = nativeIcon,
                    Width = cfg.IconSize - 2,
                    Height = cfg.IconSize - 2,
                    Stretch = Stretch.Uniform,
                }
                : VectorIcons.Create(item.IconGlyph ?? (isFolder ? "folder" : "play"), cfg.IconSize - 6, ThemeManager.TextPrimary);

            var pinBtn = CreateDockIconButton(visual, $"{item.Label}\n{item.Target}", cfg.DockHeight - 8);
            pinBtn.Margin = new Thickness(0, 0, cfg.ItemSpacing, 0);
            pinBtn.AllowDrop = true;
            pinBtn.Click += (_, _) => ShellLauncher.Open(item.Target, item.Arguments, _log);
            pinBtn.ContextMenu = BuildPinnedItemMenu(item, idx);

            pinBtn.PreviewMouseMove += (_, e) =>
            {
                if (e.LeftButton == MouseButtonState.Pressed && _dragItemId is null)
                {
                    _dragItemId = item.Id;
                    DragDrop.DoDragDrop(pinBtn, item.Id, DragDropEffects.Move);
                    _dragItemId = null;
                }
            };
            pinBtn.Drop += (_, e) =>
            {
                if (e.Data.GetData(typeof(string)) is string sourceId && sourceId != item.Id)
                {
                    var fromIdx = cfg.PinnedItems.FindIndex(p => p.Id == sourceId);
                    var toIdx = cfg.PinnedItems.FindIndex(p => p.Id == item.Id);
                    if (fromIdx >= 0 && toIdx >= 0)
                    {
                        var moved = cfg.PinnedItems[fromIdx];
                        cfg.PinnedItems.RemoveAt(fromIdx);
                        cfg.PinnedItems.Insert(toIdx, moved);
                        _store.Save();
                    }
                }
            };

            leftPanel.Children.Add(pinBtn);
        }

        var addBtn = CreateDockIconButton(VectorIcons.Create("plus", 13.5, ThemeManager.TextSecondary), "Add application or folder shortcut", cfg.DockHeight - 10);
        addBtn.Click += (_, _) => _dispatchAction("add");
        leftPanel.Children.Add(addBtn);

        Grid.SetColumn(leftPanel, 0);
        grid.Children.Add(leftPanel);

        // ---------------- MIDDLE SECTION: 6 Productivity Utilities ----------------
        var midCluster = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        var utilities = new (string Id, string Name, string Icon, bool Running)[]
        {
            ("calculator", "Calculator", "calculator", false),
            ("notes", "Markdown Notepad", "notes", false),
            ("calendar", "Calendar", "calendar", false),
            ("timer", "Timer", "timer", _timer.IsRunning),
            ("stopwatch", "Stopwatch", "stopwatch", _stopwatch.IsRunning),
            ("clipboard", "Clipboard History", "clipboard", false),
        };

        foreach (var util in utilities)
        {
            var captured = util.Id;
            var iconHolder = new Grid();
            iconHolder.Children.Add(VectorIcons.Create(util.Icon, 14.5, util.Running ? ThemeManager.AccentBrush : ThemeManager.TextSecondary));
            if (util.Running)
            {
                iconHolder.Children.Add(new Border
                {
                    Width = 4,
                    Height = 4,
                    CornerRadius = new CornerRadius(2),
                    Background = ThemeManager.WarningBrush,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Bottom,
                    Margin = new Thickness(0, 0, 0, -3),
                });
            }

            var b = CreateDockIconButton(iconHolder, util.Name, cfg.DockHeight - 10);
            b.Margin = new Thickness(1, 0, 1, 0);
            b.Click += (_, _) => _dispatchAction(captured);
            midCluster.Children.Add(b);
        }

        var clusterBorder = new Border
        {
            Background = ThemeManager.SurfaceSubtle,
            BorderBrush = ThemeManager.BorderSubtle,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(7),
            Padding = new Thickness(3, 2, 3, 2),
            VerticalAlignment = VerticalAlignment.Center,
            Child = midCluster,
        };
        Grid.SetColumn(clusterBorder, 1);
        grid.Children.Add(clusterBorder);

        // ---------------- RIGHT SECTION: Mirrored Tray + Clock/Date + Perf Toggle + Settings ----------------
        var rightPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
        };

        var status = SystemStatusService.Query();
        var trayRow = new StackPanel { Orientation = Orientation.Horizontal };
        trayRow.Children.Add(VectorIcons.Create(status.NetworkOnline ? "wifi" : "wifiOff", 13.5, status.NetworkOnline ? ThemeManager.TextSecondary : ThemeManager.WarningBrush));
        var volIcon = VectorIcons.Create(status.IsMuted || status.VolumePercent == 0 ? "volumeMute" : "volume", 13.5, ThemeManager.TextSecondary);
        volIcon.Margin = new Thickness(7, 0, 7, 0);
        trayRow.Children.Add(volIcon);
        trayRow.Children.Add(VectorIcons.Create(status.BatteryPercent is not null ? "battery" : "power", 13.5, ThemeManager.TextSecondary));

        var trayBtn = CreateDockIconButton(trayRow, $"Mirrored System Tray · Volume {status.VolumePercent}%", cfg.DockHeight - 10, minWidth: 66);
        trayBtn.Click += (_, _) => _dispatchAction("tray");
        rightPanel.Children.Add(trayBtn);
        rightPanel.Children.Add(CreateVerticalDivider());

        var clockRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 4, 0) };
        _dateText = new TextBlock
        {
            FontFamily = ThemeManager.UiFont,
            FontSize = 11.5,
            Foreground = ThemeManager.TextSecondary,
            Margin = new Thickness(0, 0, 6, 0),
            VerticalAlignment = VerticalAlignment.Center,
        };
        _clockText = new TextBlock
        {
            FontFamily = ThemeManager.UiFont,
            FontSize = 11.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = ThemeManager.TextPrimary,
            VerticalAlignment = VerticalAlignment.Center,
        };
        clockRow.Children.Add(_dateText);
        clockRow.Children.Add(_clockText);
        UpdateClockText();

        var clockBtn = CreateDockIconButton(clockRow, "Open calendar", cfg.DockHeight - 10, minWidth: 96);
        clockBtn.Click += (_, _) => _dispatchAction("calendar");
        rightPanel.Children.Add(clockBtn);
        rightPanel.Children.Add(CreateVerticalDivider());

        var perfBtn = CreateDockIconButton(
            VectorIcons.Create("gauge", 14.5, cfg.MonitorVisible ? ThemeManager.AccentBrush : ThemeManager.TextSecondary),
            cfg.MonitorVisible ? "Hide performance monitor" : "Show performance monitor",
            cfg.DockHeight - 10);
        perfBtn.Click += (_, _) => _dispatchAction("toggle-monitor");
        rightPanel.Children.Add(perfBtn);

        var settingsBtn = CreateDockIconButton(
            VectorIcons.Create("settings", 14.5, ThemeManager.TextSecondary),
            "Unified Shell Settings",
            cfg.DockHeight - 10);
        settingsBtn.Click += (_, _) => _dispatchAction("settings");
        rightPanel.Children.Add(settingsBtn);

        Grid.SetColumn(rightPanel, 2);
        grid.Children.Add(rightPanel);

        Content = new Border
        {
            Background = ThemeManager.DockBackground,
            BorderBrush = ThemeManager.BorderSubtle,
            BorderThickness = cfg.DockPosition == "bottom" ? new Thickness(0, 1, 0, 0) : new Thickness(0, 0, 0, 1),
            Child = grid,
        };
    }

    private void UpdateClockText()
    {
        if (_clockText is null || _dateText is null) return;
        var now = DateTime.Now;
        _dateText.Text = now.ToString("ddd d MMM", CultureInfo.InvariantCulture);
        _clockText.Text = now.ToString("HH:mm", CultureInfo.InvariantCulture);
    }

    private static Button CreateDockIconButton(UIElement content, string tooltip, double size, double? minWidth = null)
    {
        var border = new Border
        {
            Height = Math.Max(24, size),
            MinWidth = minWidth ?? Math.Max(26, size),
            Padding = new Thickness(5, 0, 5, 0),
            CornerRadius = new CornerRadius(6),
            Background = Brushes.Transparent,
            Child = content,
        };

        var btn = new Button
        {
            Content = border,
            ToolTip = tooltip,
            Cursor = Cursors.Hand,
            FocusVisualStyle = null,
            Template = ThemeManager.BareButtonTemplate(),
        };
        btn.MouseEnter += (_, _) => border.Background = ThemeManager.HoverBrush;
        btn.MouseLeave += (_, _) => border.Background = Brushes.Transparent;
        return btn;
    }

    private static Border CreateVerticalDivider()
    {
        return new Border
        {
            Width = 1,
            Height = 14,
            Background = ThemeManager.BorderStrong,
            Margin = new Thickness(5, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center,
        };
    }

    private ContextMenu BuildPinnedItemMenu(DockShortcutItem item, int index)
    {
        var cfg = _store.Current;
        var menu = ThemeManager.CreateStyledMenu();
        menu.Items.Add(ThemeManager.CreateMenuItem($"Open {item.Label}", () => ShellLauncher.Open(item.Target, item.Arguments, _log)));
        menu.Items.Add(ThemeManager.CreateMenuItem("Open Containing Folder", () => ShellLauncher.RevealInExplorer(item.Target, _log)));
        menu.Items.Add(new Separator());
        menu.Items.Add(ThemeManager.CreateMenuItem("Move Left", () =>
        {
            if (index <= 0) return;
            (cfg.PinnedItems[index - 1], cfg.PinnedItems[index]) = (cfg.PinnedItems[index], cfg.PinnedItems[index - 1]);
            _store.Save();
        }, isEnabled: index > 0));
        menu.Items.Add(ThemeManager.CreateMenuItem("Move Right", () =>
        {
            if (index >= cfg.PinnedItems.Count - 1) return;
            (cfg.PinnedItems[index + 1], cfg.PinnedItems[index]) = (cfg.PinnedItems[index], cfg.PinnedItems[index + 1]);
            _store.Save();
        }, isEnabled: index < cfg.PinnedItems.Count - 1));
        menu.Items.Add(new Separator());
        menu.Items.Add(ThemeManager.CreateMenuItem("Remove from Dock", () =>
        {
            cfg.PinnedItems.RemoveAll(p => p.Id == item.Id);
            _store.Save();
        }));
        return menu;
    }

    private ContextMenu BuildShellContextMenu()
    {
        var cfg = _store.Current;
        var menu = ThemeManager.CreateStyledMenu();
        menu.Items.Add(ThemeManager.CreateMenuItem("Universal Search", () => _dispatchAction("launcher"), cfg.SearchShortcut));
        menu.Items.Add(ThemeManager.CreateMenuItem("Markdown Notepad", () => _dispatchAction("notes")));
        menu.Items.Add(ThemeManager.CreateMenuItem(cfg.MonitorVisible ? "Hide Performance Monitor" : "Show Performance Monitor", () => _dispatchAction("toggle-monitor")));
        menu.Items.Add(ThemeManager.CreateMenuItem(cfg.AutoHide ? "Disable Auto-Hide" : "Enable Auto-Hide", () =>
        {
            cfg.AutoHide = !cfg.AutoHide;
            _store.Save();
        }));
        menu.Items.Add(new Separator());
        menu.Items.Add(ThemeManager.CreateMenuItem("Unified Shell Settings…", () => _dispatchAction("settings")));
        menu.Items.Add(ThemeManager.CreateMenuItem("Quit Unified Shell", () => _dispatchAction("quit")));
        return menu;
    }
}
