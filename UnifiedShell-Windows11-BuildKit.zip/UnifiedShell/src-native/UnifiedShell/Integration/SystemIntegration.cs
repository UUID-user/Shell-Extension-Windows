using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Windows.Media;
using Microsoft.Win32;
using UnifiedShell.Core;
using UnifiedShell.Interop;

namespace UnifiedShell.Integration;

/// <summary>
/// Manages per-user Windows sign-in registration under HKCU\Software\Microsoft\Windows\CurrentVersion\Run.
/// Never touches HKLM, Winlogon\Shell, or Explorer startup entries.
/// </summary>
public static class StartupManager
{
    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "UnifiedShell";

    public static bool IsEnabled()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, writable: false);
            var existing = key?.GetValue(ValueName) as string;
            return !string.IsNullOrWhiteSpace(existing);
        }
        catch
        {
            return false;
        }
    }

    public static bool SetEnabled(bool enabled, bool portable, AppLog log)
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey(RunKeyPath, writable: true);
            if (key is null) return false;

            if (!enabled)
            {
                if (key.GetValue(ValueName) is not null) key.DeleteValue(ValueName, throwOnMissingValue: false);
                log.Info("Removed HKCU Run startup entry");
                return true;
            }

            var exePath = Environment.ProcessPath;
            if (string.IsNullOrWhiteSpace(exePath)) return false;
            var command = portable ? $"\"{exePath}\" --portable" : $"\"{exePath}\"";
            key.SetValue(ValueName, command, RegistryValueKind.String);
            log.Info($"Registered HKCU Run startup entry: {command}");
            return true;
        }
        catch (Exception exception)
        {
            log.Error("Could not update HKCU Run startup entry", exception);
            return false;
        }
    }
}

public sealed record MonitorDescriptor(
    IntPtr Handle,
    string DeviceId,
    string Label,
    bool IsPrimary,
    double ScaleFactor,
    NativeMethods.RECT BoundsPx,
    NativeMethods.RECT WorkAreaPx)
{
    // Convert physical pixels to WPF device-independent units (1/96 inch) for this monitor.
    public double DipLeft => BoundsPx.Left / ScaleFactor;
    public double DipTop => BoundsPx.Top / ScaleFactor;
    public double DipWidth => BoundsPx.Width / ScaleFactor;
    public double DipHeight => BoundsPx.Height / ScaleFactor;
    public double WorkDipLeft => WorkAreaPx.Left / ScaleFactor;
    public double WorkDipTop => WorkAreaPx.Top / ScaleFactor;
    public double WorkDipWidth => WorkAreaPx.Width / ScaleFactor;
    public double WorkDipHeight => WorkAreaPx.Height / ScaleFactor;
    public double WorkDipBottom => WorkAreaPx.Bottom / ScaleFactor;
}

/// <summary>
/// Enumerates connected displays with per-monitor DPI scaling and recovers gracefully when monitors change.
/// </summary>
public static class DisplayManager
{
    public static IReadOnlyList<MonitorDescriptor> GetMonitors()
    {
        var list = new List<MonitorDescriptor>();
        var index = 1;
        NativeMethods.EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, (IntPtr hMonitor, IntPtr _, ref NativeMethods.RECT _, IntPtr _) =>
        {
            var info = new NativeMethods.MONITORINFOEX { cbSize = Marshal.SizeOf<NativeMethods.MONITORINFOEX>() };
            if (!NativeMethods.GetMonitorInfoW(hMonitor, ref info)) return true;

            double scale = 1.0;
            if (NativeMethods.GetDpiForMonitor(hMonitor, NativeMethods.MDT_EFFECTIVE_DPI, out var dpiX, out _) == 0 && dpiX > 0)
            {
                scale = dpiX / 96.0;
            }

            var primary = (info.dwFlags & NativeMethods.MONITORINFOF_PRIMARY) != 0;
            var cleanDevice = string.IsNullOrWhiteSpace(info.szDevice) ? $"DISPLAY{index}" : info.szDevice.Replace(@"\\.\", "");
            var label = $"{(primary ? "Primary" : $"Display {index}")} ({cleanDevice}) · {info.rcMonitor.Width}×{info.rcMonitor.Height} @ {Math.Round(scale * 100)}%";
            list.Add(new MonitorDescriptor(hMonitor, cleanDevice, label, primary, scale, info.rcMonitor, info.rcWork));
            index++;
            return true;
        }, IntPtr.Zero);

        if (list.Count == 0)
        {
            var width = (int)System.Windows.SystemParameters.PrimaryScreenWidth;
            var height = (int)System.Windows.SystemParameters.PrimaryScreenHeight;
            var rect = new NativeMethods.RECT { Left = 0, Top = 0, Right = Math.Max(1280, width), Bottom = Math.Max(720, height) };
            list.Add(new MonitorDescriptor(IntPtr.Zero, "DISPLAY1", $"Primary · {rect.Width}×{rect.Height}", true, 1.0, rect, rect));
        }

        return list.OrderByDescending(m => m.IsPrimary).ThenBy(m => m.DeviceId).ToList();
    }

    public static MonitorDescriptor Resolve(string? requestedDeviceOrPrimary)
    {
        var monitors = GetMonitors();
        if (!string.IsNullOrWhiteSpace(requestedDeviceOrPrimary) &&
            !requestedDeviceOrPrimary.Equals("primary", StringComparison.OrdinalIgnoreCase))
        {
            var match = monitors.FirstOrDefault(m => m.DeviceId.Equals(requestedDeviceOrPrimary, StringComparison.OrdinalIgnoreCase));
            if (match is not null) return match;
        }

        return monitors.FirstOrDefault(m => m.IsPrimary) ?? monitors[0];
    }
}

public sealed record SystemStatusSnapshot(
    bool NetworkOnline,
    string NetworkDescription,
    int? BatteryPercent,
    bool OnAcPower,
    bool IsCharging,
    int VolumePercent,
    bool IsMuted);

/// <summary>
/// Reads real Windows network, battery/power and Core Audio master volume without polling loops.
/// </summary>
public static class SystemStatusService
{
    public static SystemStatusSnapshot Query()
    {
        var online = NetworkInterface.GetIsNetworkAvailable();
        var netName = "Disconnected";
        if (online)
        {
            try
            {
                var active = NetworkInterface.GetAllNetworkInterfaces()
                    .FirstOrDefault(n => n.OperationalStatus == OperationalStatus.Up &&
                                         n.NetworkInterfaceType != NetworkInterfaceType.Loopback &&
                                         n.NetworkInterfaceType != NetworkInterfaceType.Tunnel);
                netName = active is not null ? $"{active.Name} ({active.NetworkInterfaceType})" : "Connected";
            }
            catch
            {
                netName = "Connected";
            }
        }

        int? batteryPct = null;
        var onAc = true;
        var charging = false;
        if (NativeMethods.GetSystemPowerStatus(out var power))
        {
            onAc = power.ACLineStatus == 1;
            var hasBattery = (power.BatteryFlag & 128) == 0 && power.BatteryFlag != 255;
            if (hasBattery && power.BatteryLifePercent <= 100)
            {
                batteryPct = power.BatteryLifePercent;
                charging = (power.BatteryFlag & 8) != 0 || (onAc && power.BatteryLifePercent < 100);
            }
        }

        var (vol, muted) = CoreAudioMasterVolume.TryGetVolume() ?? (65, false);
        return new SystemStatusSnapshot(online, netName, batteryPct, onAc, charging, vol, muted);
    }

    public static void SetMasterVolume(int percent) => CoreAudioMasterVolume.TrySetVolume(Math.Clamp(percent, 0, 100) / 100f);
    public static void ToggleMute() => CoreAudioMasterVolume.TryToggleMute();
}

/// <summary>
/// Minimal COM interop for Windows Core Audio endpoint volume (IMMDeviceEnumerator -> IAudioEndpointVolume).
/// Documented in endpointvolume.h / mmdeviceapi.h.
/// </summary>
internal static class CoreAudioMasterVolume
{
    private static readonly Guid ClsidMMDeviceEnumerator = new("BCDE0395-E52F-467C-8E3D-C4579291692E");
    private static readonly Guid IidIAudioEndpointVolume = new("5CDF2C82-841E-4546-9722-0CF74078229A");

    public static (int Volume, bool Muted)? TryGetVolume()
    {
        return WithEndpoint(ep =>
        {
            ep.GetMasterVolumeLevelScalar(out var level);
            ep.GetMute(out var mute);
            return ((int)Math.Round(level * 100), mute);
        });
    }

    public static void TrySetVolume(float scalar)
    {
        _ = WithEndpoint(ep =>
        {
            var ctx = Guid.Empty;
            ep.SetMasterVolumeLevelScalar(Math.Clamp(scalar, 0f, 1f), ref ctx);
            if (scalar > 0f) ep.SetMute(false, ref ctx);
            return true;
        });
    }

    public static void TryToggleMute()
    {
        _ = WithEndpoint(ep =>
        {
            ep.GetMute(out var muted);
            var ctx = Guid.Empty;
            ep.SetMute(!muted, ref ctx);
            return true;
        });
    }

    private static T? WithEndpoint<T>(Func<IAudioEndpointVolume, T> action)
    {
        object? enumeratorObj = null;
        IMMDevice? device = null;
        object? endpointObj = null;
        try
        {
            var type = Type.GetTypeFromCLSID(ClsidMMDeviceEnumerator);
            if (type is null) return default;
            enumeratorObj = Activator.CreateInstance(type);
            if (enumeratorObj is not IMMDeviceEnumerator enumerator) return default;
            // eRender = 0, eMultimedia = 1
            if (enumerator.GetDefaultAudioEndpoint(0, 1, out device) != 0 || device is null) return default;
            var iid = IidIAudioEndpointVolume;
            if (device.Activate(ref iid, 23, IntPtr.Zero, out endpointObj) != 0 || endpointObj is not IAudioEndpointVolume endpoint)
            {
                return default;
            }
            return action(endpoint);
        }
        catch
        {
            return default;
        }
        finally
        {
            if (endpointObj is not null && Marshal.IsComObject(endpointObj)) Marshal.ReleaseComObject(endpointObj);
            if (device is not null && Marshal.IsComObject(device)) Marshal.ReleaseComObject(device);
            if (enumeratorObj is not null && Marshal.IsComObject(enumeratorObj)) Marshal.ReleaseComObject(enumeratorObj);
        }
    }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(int dataFlow, int dwStateMask, out IntPtr ppDevices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice? ppEndpoint);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object? ppInterface);
    }

    [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioEndpointVolume
    {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out uint pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, ref Guid pguidEventContext);
        int SetMasterVolumeLevelScalar(float fLevel, ref Guid pguidEventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float pfLevel);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, ref Guid pguidEventContext);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool pbMute);
    }
}

public sealed record MirroredTrayApp(int ProcessId, string Name, string ExecutablePath, IntPtr MainWindowHandle, ImageSource? Icon);

/// <summary>
/// Non-invasively mirrors active user background/resident tray applications and Windows system indicators.
/// Windows 11 22H2+ removed legacy ToolbarWindow32 tray button scraping in favour of an isolated XAML Island
/// owned by Explorer. Rather than injecting a DLL into explorer.exe (which violates Explorer stability rules),
/// Unified Shell combines real Core Audio / Power / Network status, native Windows flyout URI launchers, and
/// active user-session tray/resident process discovery with real shell icons and window activation.
/// </summary>
public static class SystemTrayMirrorService
{
    private static readonly HashSet<string> KnownTrayResidentNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "Everything", "PowerToys", "PowerToys.Runner", "OneDrive", "Teams", "ms-teams", "Slack",
        "Discord", "Spotify", "Steam", "obs64", "ShareX", "AutoHotkey64", "Docker Desktop",
        "1Password", "Bitwarden", "Telegram", "Signal", "KeePassXC", "Nvidia Share", "RadeonSoftware",
        "SecurityHealthSystray", "earTrumpet", "Flow.Launcher"
    };

    public static IReadOnlyList<MirroredTrayApp> QueryActiveItems()
    {
        var items = new List<MirroredTrayApp>();
        var ownPid = Environment.ProcessId;
        var seenNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var proc in Process.GetProcesses())
        {
            try
            {
                if (proc.Id == ownPid || proc.SessionId == 0) continue;
                var name = proc.ProcessName;
                var hasWindow = proc.MainWindowHandle != IntPtr.Zero;
                if (!hasWindow && !KnownTrayResidentNames.Contains(name)) continue;
                if (name.Equals("explorer", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("TextInputHost", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("ApplicationFrameHost", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("ShellExperienceHost", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("SearchHost", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("StartMenuExperienceHost", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (!seenNames.Add(name)) continue;

                string? exe = null;
                try { exe = proc.MainModule?.FileName; } catch { /* Protected processes do not expose MainModule without elevation */ }
                if (string.IsNullOrWhiteSpace(exe)) continue;

                var title = !string.IsNullOrWhiteSpace(proc.MainWindowTitle) ? proc.MainWindowTitle : Path.GetFileNameWithoutExtension(exe);
                var icon = NativeMethods.ExtractShellIcon(exe);
                items.Add(new MirroredTrayApp(proc.Id, title, exe, proc.MainWindowHandle, icon));
                if (items.Count >= 10) break;
            }
            catch
            {
                // Process may exit during enumeration.
            }
            finally
            {
                proc.Dispose();
            }
        }

        return items;
    }

    public static void ActivateOrLaunch(MirroredTrayApp app, AppLog log)
    {
        try
        {
            if (app.MainWindowHandle != IntPtr.Zero)
            {
                NativeMethods.ShowWindow(app.MainWindowHandle, NativeMethods.SW_RESTORE);
                NativeMethods.SetForegroundWindow(app.MainWindowHandle);
                return;
            }

            if (!string.IsNullOrWhiteSpace(app.ExecutablePath))
            {
                ShellLauncher.Open(app.ExecutablePath, null, log);
            }
        }
        catch (Exception ex)
        {
            log.Warn($"Could not activate tray application {app.Name}: {ex.Message}");
        }
    }
}

public static class ShellLauncher
{
    public static bool Open(string target, string? arguments, AppLog log)
    {
        if (string.IsNullOrWhiteSpace(target)) return false;
        try
        {
            var expanded = Environment.ExpandEnvironmentVariables(target.Trim());
            var psi = new ProcessStartInfo
            {
                FileName = expanded,
                Arguments = arguments ?? string.Empty,
                UseShellExecute = true,
            };
            Process.Start(psi);
            log.Info($"ShellExecute: {expanded} {arguments}");
            return true;
        }
        catch (Exception exception)
        {
            log.Error($"ShellExecute failed for '{target}'", exception);
            return false;
        }
    }

    public static bool RevealInExplorer(string path, AppLog log)
    {
        if (string.IsNullOrWhiteSpace(path)) return false;
        try
        {
            var expanded = Environment.ExpandEnvironmentVariables(path);
            if (Directory.Exists(expanded))
            {
                return Open("explorer.exe", $"\"{expanded}\"", log);
            }
            return Open("explorer.exe", $"/select,\"{expanded}\"", log);
        }
        catch (Exception exception)
        {
            log.Error($"Could not reveal '{path}' in Explorer", exception);
            return false;
        }
    }
}
