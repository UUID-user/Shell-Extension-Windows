@echo off
rem ============================================================================
rem Unified Shell - Self-Sufficient Windows 11 x64 Build Wrapper
rem Produces: dist\UnifiedShell.exe (Self-Contained, Single-File, Release)
rem Usage:    build.bat [-Clean] [-ForceSdkDownload] [-SkipSelfTest]
rem ============================================================================
setlocal
cd /d "%~dp0"

where powershell >nul 2>nul
if errorlevel 1 (
    echo.
    echo [FAIL] Windows PowerShell was not found on PATH.
    echo        Unified Shell requires PowerShell 5.1+ ^(included in Windows 11^).
    echo.
    exit /b 1
)

powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo Unified Shell build exited with error code %EXIT_CODE%.
    exit /b %EXIT_CODE%
)

exit /b 0
