# Unified Shell

**Unified Shell** is a lightweight, productivity-oriented desktop companion for **Windows 11 25H2 (x64)**.  
It adds a compact top dock, an `Alt + Space` universal search & command palette, six focused utilities, and a low-overhead hardware monitor **alongside** Windows Explorer — never replacing `explorer.exe`, the native Windows taskbar, the Start Menu, or the original system tray.

---

## 1. Supported Platform

| Requirement | Specification |
|---|---|
| Operating System | **Windows 11 25H2** (Windows 11 build 22000+ enforced; Windows 10 is not supported) |
| Architecture | **Windows x64 (`win-x64`)** |
| Runtime Deployment | **Self-contained, single-file native executable** (`dist\UnifiedShell.exe`) |
| Privileges | **Standard user (`asInvoker`)** — no administrator rights required to build or run |
| Process Model | Single primary `.NET 8` WPF + Win32 process (zero WebView2 / Electron child processes) |

---

## 2. Features & Components

- **Top Dock** (`TopDockWindow`)
  - Permanently visible horizontal bar at the top (or bottom, above the Windows taskbar) of the selected monitor, with optional 3 px edge **auto-hide** and automatic suppression whenever a fullscreen game, video, or presentation is active (`SHQueryUserNotificationState` + foreground monitor bounds check).
  - **Left section**: Unified Shell launcher button, pinned application shortcuts, custom `.exe` shortcuts, and custom folder shortcuts (drag-and-drop reordering, native `SHGetFileInfo` icons, right-click context menu).
  - **Middle section**: Dedicated popover utilities — **Calculator**, **Custom Markdown Notepad**, **Calendar**, **Timer**, **Stopwatch**, and **Clipboard History**.
  - **Right section**: Mirrored system tray status & audio flyout, Clock & Date, Performance Monitor toggle, and Unified Shell Settings shortcut.
- **Universal Search & Application Launcher (`Alt + Space`)** (`LauncherWindow`)
  - Searches installed Start Menu applications (fuzzy matching + native icons), **Windows 11 Settings** pages (`ms-settings:` URIs), built-in Unified Shell commands, and local files/folders via **Everything Search by Voidtools**.
- **Performance Monitor Widget** (`PerformanceWidgetWindow`)
  - Displays **CPU** (`GetSystemTimes` kernel/user deltas + logical processor count), **GPU** (PDH `\GPU Engine(*)\Utilization Percentage` + `\GPU Adapter Memory(*)\Dedicated Usage` + DXGI dedicated VRAM capacity), and **RAM** (`GlobalMemoryStatusEx`).
  - Completely stops its sampling timer when hidden (`0%` background polling overhead).
- **Productivity Utilities**
  - **Calculator**: Recursive-descent arithmetic (`+ − × ÷`), parentheses, decimals, additive percentages (`1200 + 15% = 1380`), keyboard input, history, one-click copy.
  - **Custom Markdown Notepad**: Independent editor (never opens Windows Notepad or Sticky Notes) with Edit / Split / Rich Markdown Preview modes, fenced code block syntax highlighting, Open / Save / Save As, `Ctrl+S` / `Ctrl+O` / `Ctrl+N`, and automatic draft recovery.
  - **Calendar**: Monthly calendar grid, Monday-first ISO week numbers, Today jump, date selection.
  - **Timer & Stopwatch**: Monotonic timestamp-based countdown timer (with presets, custom duration, and completion chime) and high-resolution stopwatch with split/total lap recording.
  - **Clipboard History**: Event-driven `WM_CLIPBOARDUPDATE` listener (no polling) supporting text and PNG image thumbnails, pinning, filtering, deleting, clearing unpinned items, and password-manager exclusion flags (`ExcludeClipboardContentFromMonitorProcessing` / `CanIncludeInClipboardHistory`).

---

## 3. How to Build (`dist\UnifiedShell.exe`)

From the project root on **Windows 11 x64**, run either:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

or double-click / run from Command Prompt:

```bat
.\build.bat
```

### What `build.ps1` handles automatically
1. Checks that the OS is **Windows 11 (build ≥ 22000)** and **64-bit (`x64`)**.
2. Detects whether the **.NET 8.0+ SDK** is already installed (`PATH`, `Program Files\dotnet`, `%LOCALAPPDATA%\Microsoft\dotnet`, or `.build\dotnet`).
3. If missing, downloads Microsoft's official `https://dot.net/v1/dotnet-install.ps1` over HTTPS, logs its SHA-256 hash, and provisions a **portable user-local `.NET 8 SDK`** inside `.build\dotnet\` — **no administrator elevation required** and cached across subsequent builds.
4. Restores the `.NET 8` Windows Desktop runtime pack (`win-x64`).
5. Publishes `src-native\UnifiedShell\UnifiedShell.csproj` in `Release` configuration as a **single-file, self-contained, compressed `win-x64` executable**.
6. Validates the PE32+ (`0x8664`) binary header and executes `UnifiedShell.exe --self-test`.
7. Outputs **`dist\UnifiedShell.exe`** and **`dist\UnifiedShell.exe.sha256`**.

Optional script flags:
- `.\build.ps1 -Clean` — cleans `bin/`, `obj/`, and temporary publish directories before building.
- `.\build.ps1 -ForceSdkDownload` — re-downloads a fresh portable `.NET 8 SDK` into `.build\dotnet\`.
- `.\build.ps1 -SkipSelfTest` — skips running `--self-test` after publishing.

---

## 4. Running & Configuration

### Standard Per-User Mode
Run `dist\UnifiedShell.exe`. Configuration and local data are stored in:
- `%LOCALAPPDATA%\UnifiedShell\config.json`
- `%LOCALAPPDATA%\UnifiedShell\clipboard.json`
- `%LOCALAPPDATA%\UnifiedShell\notes\autosave.md`
- `%LOCALAPPDATA%\UnifiedShell\logs\unified-shell.log`

### Portable Mode
Create an empty file named `portable.flag` next to `UnifiedShell.exe` (for example `dist\portable.flag`) **or** launch with:

```powershell
.\dist\UnifiedShell.exe --portable
```

When portable mode is active (and the directory is writable), all configuration, notes, clipboard history, and logs stay inside `.\data\` beside `UnifiedShell.exe`.

### Configuring Unified Shell
Click the **gear icon** on the right side of the Top Dock (or open Search with `Alt + Space` and choose **Unified Shell Settings**). Every setting applies immediately and persists atomically without manual JSON editing. Configuration can also be exported/imported or reset under **Settings → Advanced**.

### Enabling Windows Startup
Open **Settings → General → Start Unified Shell with Windows**.  
Unified Shell registers a standard per-user value under `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` (`UnifiedShell`). It never modifies `Winlogon\Shell` or replaces `explorer.exe`.

---

## 5. Everything Search Integration (Voidtools)

Unified Shell integrates directly with **Everything** for instant NTFS file and folder search without running a second disk indexer:

1. Install and run Everything from the official website: <https://www.voidtools.com/downloads/>
2. Unified Shell automatically detects Everything's running IPC window (`EVERYTHING_TASKBAR_NOTIFICATION`) and queries it via `Everything64.dll` (in-process IPC) or `es.exe` (official Voidtools command-line client) when present in Everything's directory or on `PATH`.
3. You can also specify a custom path in **Settings → Search → Locate Everything…**.
4. In search results, press **Enter** to open a file/folder or **Ctrl + Enter** to reveal it in File Explorer (`explorer.exe /select,...`).
5. If Everything is not installed, Unified Shell displays a clear notice and official download link — it never silently downloads or installs Everything.

---

## 6. Dependencies

### Native Windows Application (`src-native/UnifiedShell`)
- **Zero third-party NuGet packages** — built solely on `.NET 8` (`Microsoft.NETCore.App` + `Microsoft.WindowsDesktop.App.WPF`) and documented Windows 11 Win32 / DWM / Shell32 / Shcore / Kernel32 / PDH / DXGI / Core Audio APIs.

### Interactive Browser Preview (`src/`)
- React 19, Vite 7, Tailwind CSS 4 (used only for the interactive web preview surface `dist/index.html`; **not** loaded by `UnifiedShell.exe` at runtime, keeping native RAM consumption minimal).

---

## 7. Resource Consumption & Testing

| Metric | Target | Native Architecture Design |
|---|---:|---|
| Idle RAM | < 150 MB | Single `.NET 8` WPF process (~55–80 MB typical working set; zero WebView2 processes) |
| Normal RAM | < 250 MB | Lazy icon extraction (`SHGetFileInfo` frozen bitmaps) & bounded histories |
| Heavy RAM | < 400 MB | Capped result sets (`4–20`), bounded clipboard (`≤ 100`) & 360 px PNG thumbnails |
| Idle CPU | ~0% | Event-driven `WM_HOTKEY` & `WM_CLIPBOARDUPDATE`; metrics timer halted when hidden |

Run built-in automated functional verification at any time:

```powershell
.\dist\UnifiedShell.exe --self-test
```

Verifies `CalculatorEngine` precedence/percentages/error handling, `FuzzyMatcher` ranking, `WindowsSettingsIndex` `ms-settings:` URI integrity, and `ConfigStore` atomic save, range clamping, portable export sanitisation, and corrupt-JSON recovery.

---

## 8. Known Limitations

1. **Hardware Temperatures**: Windows 11 user-mode provides no reliable vendor-neutral CPU/GPU temperature API without loading a kernel-mode hardware driver (such as WinRing0 or PawnIO). To preserve system stability and run strictly without administrator privileges, Unified Shell never installs kernel drivers and displays `Temp —` rather than estimating or inventing temperatures.
2. **System Tray Mirroring on Windows 11 25H2**: Windows 11 22H2+ replaced the legacy `ToolbarWindow32` notification area with an in-process XAML Island inside `explorer.exe`. Full third-party tray icon context-menu forwarding requires DLL injection into `explorer.exe`, which Unified Shell deliberately avoids to guarantee Explorer stability. Instead, Unified Shell mirrors real Core Audio master volume/mute, power/battery status, network state, native Windows flyout launchers, and active user-session tray/resident applications while keeping the native Windows system tray 100% operational.
3. **Whole-Disk File Search**: Delegated exclusively to Everything by Voidtools when installed and running; Unified Shell does not build a duplicate background file-indexing service.
